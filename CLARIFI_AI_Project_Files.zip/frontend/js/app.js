/**
 * CLARIFI AI — App Core (app.js)
 * Manages: language state, section routing, toasts, loading overlay.
 * No external libraries — pure vanilla JS.
 */

'use strict';

// ---------------------------------------------------------------------------
// Language Configuration
// ---------------------------------------------------------------------------
const LANGUAGES = {
  'en-IN': { label: 'English',  name: 'English',  nativeLabel: 'English' },
  'hi-IN': { label: 'हिंदी',    name: 'Hindi',    nativeLabel: 'हिंदी' },
  'kn-IN': { label: 'ಕನ್ನಡ',   name: 'Kannada',  nativeLabel: 'ಕನ್ನಡ' },
  'te-IN': { label: 'తెలుగు',  name: 'Telugu',   nativeLabel: 'తెలుగు' },
};

// ---------------------------------------------------------------------------
// App State  (single source of truth)
// ---------------------------------------------------------------------------
const AppState = {
  // Active language code — drives STT, LLM prompt language, TTS
  currentLanguage: localStorage.getItem('clarifi_lang') || 'en-IN',
  // Active section id (without the "section-" prefix) — Dashboard is now front page!
  currentSection: 'dashboard',
  // Transcript waiting for user confirmation
  pendingTranscript: null,
};

// ---------------------------------------------------------------------------
// Initialise the app
// ---------------------------------------------------------------------------
function initApp() {
  // 1. Build language selector buttons
  renderLangButtons();

  // 2. Setup bottom nav clicks immediately so section routing is always responsive
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const section = item.dataset.section;
      if (section) showSection(section);
    });
  });

  // 3. Apply initial localization translations
  try {
    if (typeof window.applyLanguage === 'function') {
      window.applyLanguage(AppState.currentLanguage);
    }
  } catch (err) {
    console.warn('[App] Localization init error:', err);
  }

  // 4. Initialize Auth gate & welcome modal safely
  try {
    if (typeof window.initAuth === 'function') {
      window.initAuth();
    }
  } catch (err) {
    console.error('[App] Auth initialization error:', err);
  }

  // 5. Activate Dashboard as the front page
  showSection(AppState.currentSection || 'dashboard');

  // 6. Pre-initialize modules
  try {
    if (typeof initDashboard === 'function') initDashboard();
  } catch (err) {
    console.warn('[App] Dashboard init error:', err);
  }

  try {
    if (typeof initVoice === 'function') initVoice();
  } catch (err) {
    console.warn('[App] Voice module init error:', err);
  }

  console.log('[CLARIFI AI] App initialised with Dashboard as front page. Language:', AppState.currentLanguage);
}

// ---------------------------------------------------------------------------
// Language Selector
// ---------------------------------------------------------------------------
function renderLangButtons() {
  const container = document.getElementById('lang-selector');
  if (!container) return;
  container.innerHTML = '';

  Object.entries(LANGUAGES).forEach(([code, lang]) => {
    const btn = document.createElement('button');
    btn.className = 'lang-btn' + (code === AppState.currentLanguage ? ' active' : '');
    btn.textContent = lang.nativeLabel;
    btn.title = lang.name;
    btn.dataset.code = code;
    btn.addEventListener('click', () => setLanguage(code));
    container.appendChild(btn);
  });
}

function setLanguage(code) {
  if (!LANGUAGES[code]) return;
  AppState.currentLanguage = code;
  localStorage.setItem('clarifi_lang', code);

  // Update active button across both header and auth modal
  document.querySelectorAll('.lang-btn, .auth-lang-btn').forEach(btn => {
    btn.classList.toggle('active', (btn.dataset.code || btn.dataset.lang) === code);
  });

  // Dynamically translate the entire UI
  if (typeof window.applyLanguage === 'function') {
    window.applyLanguage(code);
  }

  // Refresh topic pills on Learn tab
  if (typeof window.loadTopicButtons === 'function') {
    window.loadTopicButtons();
  }

  // Instantly re-render Goal Plan in newly selected language if visible
  if (window.currentGoalPlan && document.getElementById('goal-plan-section')) {
    if (typeof renderPlan === 'function') {
      renderPlan(document.getElementById('goal-plan-section'), window.currentGoalPlan);
    }
  }

  // Instantly re-explain current Learn topic in newly selected language
  if (typeof runExplain === 'function' && window.LearnState?.currentTopicKey) {
    runExplain(window.LearnState.currentTopicKey, window.LearnState.currentTopicKey);
  }

  // Notify TTS engine of language switch
  if (typeof window.onLanguageChange === 'function') {
    window.onLanguageChange(code);
  }

  showToast(`Language: ${LANGUAGES[code].nativeLabel} (${LANGUAGES[code].name})`, 'info', 2000);
  console.log('[CLARIFI AI] Language set to:', code);
}

// ---------------------------------------------------------------------------
// Section Routing
// ---------------------------------------------------------------------------
function showSection(name) {
  AppState.currentSection = name;

  // Show/hide sections
  document.querySelectorAll('.section').forEach(el => {
    el.classList.toggle('active', el.id === `section-${name}`);
  });

  // Update nav active state
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.toggle('active', item.dataset.section === name);
  });

  // Voice section
  if (name === 'voice' && typeof initVoice === 'function') {
    if (!AppState._voiceInitialised) {
      AppState._voiceInitialised = true;
      initVoice();
    }
  }

  // Phase 2: lazy-init Expenses section on first visit
  if (name === 'expenses' && typeof initExpenses === 'function') {
    // Only init once — guard with a flag
    if (!AppState._expensesInitialised) {
      AppState._expensesInitialised = true;
      initExpenses();
    } else {
      // Reload list on every visit so it stays fresh
      if (typeof loadTransactions === 'function') loadTransactions();
    }
  }

  // Phase 3: lazy-init Dashboard section on first visit; reload on return
  if (name === 'dashboard' && typeof initDashboard === 'function') {
    if (!AppState._dashboardInitialised) {
      AppState._dashboardInitialised = true;
      initDashboard();
    } else {
      if (typeof loadDashboard === 'function') loadDashboard();
    }
  }

  // Phase 4: lazy-init Learn/Explainer section on first visit
  if (name === 'learn' && typeof initLearn === 'function') {
    if (!AppState._learnInitialised) {
      AppState._learnInitialised = true;
      initLearn();
    }
  }

  // Phase 5: lazy-init Goals section on first visit; reload list on return
  if (name === 'goals' && typeof initGoals === 'function') {
    if (!AppState._goalsInitialised) {
      AppState._goalsInitialised = true;
      initGoals();
    } else {
      if (typeof loadGoals === 'function') loadGoals();
    }
  }
}

// ---------------------------------------------------------------------------
// Toast Notifications (Auto-dismiss in 2 seconds & click to dismiss)
// ---------------------------------------------------------------------------
/**
 * Show a temporary toast message.
 * Strictly auto-dismisses within 2 seconds.
 *
 * @param {string} message
 * @param {'success'|'error'|'info'|'warning'} type
 * @param {number} duration  ms before auto-dismiss (capped at 2000ms / 2s max)
 */
function showToast(message, type = 'info', duration = 2000) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const autoCloseMs = Math.min(duration || 2000, 2000);

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || 'ℹ️'}</span>
    <span class="toast-msg">${message}</span>
    <button class="toast-close" type="button" aria-label="Close">✕</button>
  `;
  
  // Instant dismissal on close button or toast click
  toast.querySelector('.toast-close')?.addEventListener('click', (e) => {
    e.stopPropagation();
    dismissToast(toast);
  });
  toast.addEventListener('click', () => dismissToast(toast));
  
  container.appendChild(toast);

  // Auto-dismiss within at most 2 seconds
  setTimeout(() => dismissToast(toast), autoCloseMs);

  return toast;
}

function dismissToast(toast) {
  if (!toast || !toast.parentNode || toast._isDismissing) return;
  toast._isDismissing = true;
  toast.classList.add('hiding');
  setTimeout(() => {
    if (toast.parentNode) {
      toast.remove();
    }
  }, 200);
}

// ---------------------------------------------------------------------------
// Loading Overlay
// ---------------------------------------------------------------------------
function showLoading(visible, message = 'Processing…') {
  const overlay = document.getElementById('loading-overlay');
  if (!overlay) return;
  overlay.classList.toggle('visible', visible);
  const p = overlay.querySelector('p');
  if (p) p.textContent = message;
}

function getAuthHeaders(extra = {}) {
  let userId = 1;
  try {
    if (window.AuthState?.user?.id) {
      userId = window.AuthState.user.id;
    } else {
      const stored = localStorage.getItem('clarifi_user');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed?.id) userId = parsed.id;
      }
    }
  } catch (e) {}
  return {
    ...extra,
    'X-User-Id': String(userId),
  };
}

// ---------------------------------------------------------------------------
// Expose globals needed by voice.js and future modules
// ---------------------------------------------------------------------------
window.AppState       = AppState;
window.LANGUAGES      = LANGUAGES;
window.showToast      = showToast;
window.showLoading    = showLoading;
window.showSection    = showSection;
window.setLanguage    = setLanguage;
window.getAuthHeaders = getAuthHeaders;

// ---------------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------------
document.addEventListener('DOMContentLoaded', initApp);
