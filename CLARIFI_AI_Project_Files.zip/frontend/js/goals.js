/**
 * CLARIFI AI — Goal Planner Module  (Phase 5)
 *
 * UI for:
 *  - Creating a savings goal (name, target ₹, months)
 *  - Fetching the deterministic plan from /api/goals/{id}/plan
 *  - Rendering: required saving, current surplus, feasibility verdict,
 *    shortfall/buffer, estimated target date, horizon instruments (educational)
 *  - Listing all goals with quick "View Plan" action
 *  - Deleting goals
 *
 * All numbers come from pure Python maths on the backend — no LLM.
 */

'use strict';

// ---------------------------------------------------------------------------
// Init — called by app.js when Goals tab is first opened
// ---------------------------------------------------------------------------
function initGoals() {
  bindGoalForm();
  loadGoals();
}

// ---------------------------------------------------------------------------
// Create goal form
// ---------------------------------------------------------------------------
function bindGoalForm() {
  const form = document.getElementById('goal-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const name   = document.getElementById('goal-name').value.trim();
    const amount = parseFloat(document.getElementById('goal-amount').value);
    const months = parseInt(document.getElementById('goal-months').value);

    if (!name)              { showToast('Please enter a goal name.',     'warning'); return; }
    if (!amount || amount <= 0) { showToast('Please enter a valid amount.', 'warning'); return; }
    if (!months || months < 1)  { showToast('Please enter valid months.',   'warning'); return; }

    try {
      showLoading(true, 'Saving goal…');
      const res = await fetch('/api/goals', {
        method:  'POST',
        headers: (window.getAuthHeaders ? window.getAuthHeaders({ 'Content-Type': 'application/json' }) : { 'Content-Type': 'application/json' }),
        body: JSON.stringify({ name, target_amount: amount, months }),
      });
      if (!res.ok) throw new Error(await res.text());
      const goal = await res.json();

      showToast(`Goal "${name}" saved!`, 'success');
      form.reset();

      // Immediately compute and show its plan
      await showGoalPlan(goal.id, name);
      await loadGoals();     // refresh list

    } catch (err) {
      console.error('[Goals] create error:', err);
      showToast('Could not save goal. Please try again.', 'error');
    } finally {
      showLoading(false);
    }
  });

  // Live preview: update "per month" estimate as user types
  ['goal-amount','goal-months'].forEach(id => {
    document.getElementById(id)?.addEventListener('input', updateLivePreview);
  });
}

function updateLivePreview() {
  const amount  = parseFloat(document.getElementById('goal-amount')?.value) || 0;
  const months  = parseInt(document.getElementById('goal-months')?.value)   || 0;
  const preview = document.getElementById('goal-preview');
  if (!preview) return;

  if (amount > 0 && months > 0) {
    const perMonth = Math.ceil(amount / months);
    preview.textContent = `≈ ₹${perMonth.toLocaleString('en-IN')} / month needed`;
    preview.style.color = 'var(--color-accent)';
  } else {
    preview.textContent = '';
  }
}

// ---------------------------------------------------------------------------
// Load all goals list
// ---------------------------------------------------------------------------
async function loadGoals() {
  const list = document.getElementById('goals-list');
  if (!list) return;

  try {
    const res = await fetch('/api/goals', {
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (!res.ok) throw new Error(res.status);
    const goals = await res.json();
    renderGoalsList(list, goals);
  } catch (err) {
    console.error('[Goals] loadGoals error:', err);
    list.innerHTML = '<p class="goals-empty">Could not load goals.</p>';
  }
}

function renderGoalsList(container, goals) {
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const dict = window.TRANSLATIONS?.[lang] || window.TRANSLATIONS?.['en-IN'] || {};

  if (!goals || goals.length === 0) {
    container.innerHTML = `
      <div class="goals-empty">
        <div style="font-size:2rem;margin-bottom:8px">🎯</div>
        <p>${dict['goals_empty_title'] || 'No goals yet. Create your first one above!'}</p>
      </div>`;
    return;
  }

  container.innerHTML = goals.map(g => `
    <div class="goal-card" data-id="${g.id}">
      <div class="goal-card-info">
        <div class="goal-card-name">${escHtml(g.name)}</div>
        <div class="goal-card-meta">
          ₹${Number(g.target_amount).toLocaleString('en-IN')} in ${g.months} ${dict['dash_ef_months'] || 'months'}
        </div>
      </div>
      <div class="goal-card-actions">
        <button class="btn btn-secondary btn-sm btn-view-plan" data-id="${g.id}" data-name="${escHtml(g.name)}">
          ${dict['btn_plan'] || '📊 Plan'}
        </button>
        <button class="btn btn-ghost btn-sm btn-del-goal" data-id="${g.id}">🗑️</button>
      </div>
    </div>`).join('');

  // Bind buttons
  container.querySelectorAll('.btn-view-plan').forEach(btn => {
    btn.addEventListener('click', () => showGoalPlan(parseInt(btn.dataset.id), btn.dataset.name));
  });
  container.querySelectorAll('.btn-del-goal').forEach(btn => {
    btn.addEventListener('click', () => deleteGoal(parseInt(btn.dataset.id)));
  });
}

// ---------------------------------------------------------------------------
// Fetch and render a goal's plan
// ---------------------------------------------------------------------------
async function showGoalPlan(goalId, goalName) {
  const planSection = document.getElementById('goal-plan-section');
  if (!planSection) return;

  planSection.style.display = 'block';
  planSection.innerHTML = `
    <div class="plan-loading">
      <div class="spinner" style="width:24px;height:24px;border-width:3px"></div>
      <span>Computing plan…</span>
    </div>`;

  // Scroll to plan
  planSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

  try {
    const res = await fetch(`/api/goals/${goalId}/plan`, {
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (!res.ok) throw new Error(res.status);
    const plan = await res.json();
    renderPlan(planSection, plan);
  } catch (err) {
    console.error('[Goals] plan fetch error:', err);
    planSection.innerHTML = '<p style="color:var(--color-danger)">Could not load plan.</p>';
  }
}

// ---------------------------------------------------------------------------
// Render plan result (Detailed Terminology Explanations & Fully Localized)
// ---------------------------------------------------------------------------
function renderPlan(container, p) {
  if (!container || !p) return;
  window.currentGoalPlan = p;

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const feasible   = p.is_feasible;
  const diff       = p.shortfall_or_buffer;
  const diffAbs    = Math.abs(diff).toLocaleString('en-IN', { maximumFractionDigits: 0 });

  // Localization Dictionaries for Plan
  const planI18n = {
    'en-IN': {
      title: '📊 Savings Plan',
      verdictFeasible: '✅ Achievable with your current monthly surplus!',
      verdictInfeasible: '⚠️ Requires more monthly savings than your current surplus.',
      lblTarget: '🎯 Target',
      lblTimeline: '📅 Timeline',
      lblNeed: '💸 Need / month',
      lblSurplus: '💰 Your surplus',
      lblDiff: '📊 Difference',
      lblEstDate: '🗓️ Est. completion',
      monthsUnit: 'months',
      bufText: `✅ ₹${diffAbs}/mo buffer`,
      shortText: `⚠️ ₹${diffAbs}/mo shortfall`,
      listenBtn: '<span class="speaker-icon-lg">🔊</span> <span>Listen to this plan</span>',
      instrumentsHeader: '📚 What instruments to consider for this timeline',
      termsHeader: '📖 Suggested Financial Terminology Decoded',
      termsSubtitle: 'Clear, plain-language explanations of financial products suggested above:',
      tipPrefix: '💡 Tip: To reach this goal faster, consider extending your timeline to',
      disclaimer: '⚠️ General educational information only — not personalized investment advice. Consult a certified financial advisor before investing.'
    },
    'hi-IN': {
      title: '📊 बचत योजना',
      verdictFeasible: '✅ आपकी वर्तमान मासिक बचत के साथ यह लक्ष्य पूरी तरह संभव है!',
      verdictInfeasible: '⚠️ इस लक्ष्य के लिए आपकी वर्तमान बचत से अधिक पैसे बचाने होंगे।',
      lblTarget: '🎯 लक्ष्य राशि',
      lblTimeline: '📅 समय सीमा',
      lblNeed: '💸 मासिक आवश्यकता',
      lblSurplus: '💰 आपकी बचत',
      lblDiff: '📊 अंतर / बचत',
      lblEstDate: '🗓️ अनुमानित समाप्ति',
      monthsUnit: 'महीने',
      bufText: `✅ ₹${diffAbs}/माह अतिरिक्त`,
      shortText: `⚠️ ₹${diffAbs}/माह की कमी`,
      listenBtn: '<span class="speaker-icon-lg">🔊</span> <span>इस योजना को सुनें</span>',
      instrumentsHeader: '📚 इस समय सीमा के लिए वित्तीय विकल्प',
      termsHeader: '📖 सुझाई गई वित्तीय शब्दावली का सरल अर्थ (डीकोड)',
      termsSubtitle: 'ऊपर सुझाए गए सभी वित्तीय उत्पादों की आसान और स्पष्ट व्याख्या:',
      tipPrefix: '💡 सुझाव: इस लक्ष्य को सहज बनाने के लिए समय सीमा बढ़ाकर',
      disclaimer: '⚠️ केवल सामान्य शैक्षणिक जानकारी — कोई निवेश सलाह नहीं। निवेश से पहले प्रमाणित वित्तीय सलाहकार से परामर्श लें।'
    },
    'kn-IN': {
      title: '📊 ಉಳಿತಾಯ ಯೋಜನೆ',
      verdictFeasible: '✅ ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಉಳಿತಾಯದಿಂದ ಈ ಗುರಿಯನ್ನು ಸಾಧಿಸಬಹುದು!',
      verdictInfeasible: '⚠️ ಈ ಗುರಿಗೆ ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಉಳಿತಾಯಕ್ಕಿಂತ ಹೆಚ್ಚಿನ ಹಣ ಬೇಕು.',
      lblTarget: '🎯 ಗುರಿ ಮೊತ್ತ',
      lblTimeline: '📅 ಕಾಲಾವಧಿ',
      lblNeed: '💸 ತಿಂಗಳ ಉಳಿತಾಯ',
      lblSurplus: '💰 ನಿಮ್ಮ ಉಳಿತಾಯ',
      lblDiff: '📊 ವ್ಯತ್ಯಾಸ',
      lblEstDate: '🗓️ ಅಂದಾಜು ದಿನಾಂಕ',
      monthsUnit: 'ತಿಂಗಳುಗಳು',
      bufText: `✅ ₹${diffAbs}/ತಿಂಗಳು ಮಿಗುಲು`,
      shortText: `⚠️ ₹${diffAbs}/ತಿಂಗಳು ಕೊರತೆ`,
      listenBtn: '<span class="speaker-icon-lg">🔊</span> <span>ಈ ಯೋಜನೆಯನ್ನು ಆಲಿಸಿ</span>',
      instrumentsHeader: '📚 ಈ ಅವಧಿಗೆ ಪರಿಗಣಿಸಬೇಕಾದ ಹಣಕಾಸು ಆಯ್ಕೆಗಳು',
      termsHeader: '📖 ಸೂಚಿಸಲಾದ ಆರ್ಥಿಕ ಪರಿಭಾಷೆಗಳ ಸರಳ ವಿವರಣೆ',
      termsSubtitle: 'ಮೇಲೆ ಸೂಚಿಸಲಾದ ಹಣಕಾಸು ಉತ್ಪನ್ನಗಳ ಸ್ಪಷ್ಟ ಮತ್ತು ವಿವರವಾದ ಮಾಹಿತಿ:',
      tipPrefix: '💡 ಸಲಹೆ: ಈ ಗುರಿಯನ್ನು ಸುಲಭವಾಗಿ ತಲುಪಲು ಕಾಲಾವಧಿಯನ್ನು ಹೆಚ್ಚಿಸಿ',
      disclaimer: '⚠️ ಸಾಮಾನ್ಯ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ ಮಾತ್ರ — ಯಾವುದೇ ವೈಯಕ್ತಿಕ ಹೂಡಿಕೆ ಸಲಹೆಯಲ್ಲ. ಹೂಡಿಕೆ ಮಾಡುವ ಮುನ್ನ ಪ್ರಮಾಣೀಕೃತ ಹಣಕಾಸು ಸಲಹೆಗಾರರನ್ನು ಸಂಪರ್ಕಿಸಿ.'
    },
    'te-IN': {
      title: '📊 పొదుపు ప్రణాళిక',
      verdictFeasible: '✅ మీ ప్రస్తుత నెలవారీ పొదుపుతో ఈ లక్ష్యాన్ని సులభంగా సాధించవచ్చు!',
      verdictInfeasible: '⚠️ ఈ లక్ష్యానికి మీ ప్రస్తుత మిగులు కంటే ఎక్కువ పొదుపు అవసరం.',
      lblTarget: '🎯 లక్ష్యం మొత్తం',
      lblTimeline: '📅 కాలవ్యవధి',
      lblNeed: '💸 నెలకు అవసరం',
      lblSurplus: '💰 మీ మిగులు',
      lblDiff: '📊 వ్యత్యాసం',
      lblEstDate: '🗓️ అంచనా తేదీ',
      monthsUnit: 'నెలలు',
      bufText: `✅ ₹${diffAbs}/నెలకు మిగులు`,
      shortText: `⚠️ ₹${diffAbs}/నెలకు కొరత`,
      listenBtn: '<span class="speaker-icon-lg">🔊</span> <span>ఈ ప్రణాళికను వినండి</span>',
      instrumentsHeader: '📚 ఈ సమయానికి తగిన ఆర్థిక సాధనాలు',
      termsHeader: '📖 సూచించిన ఆర్థిక పరిభాషల సమగ్ర వివరణ',
      termsSubtitle: 'పైన సూచించిన పొదుపు ఉత్పత్తుల గురించిన సులభమైన వివరణ:',
      tipPrefix: '💡 చిట్కా: ఈ లక్ష్యాన్ని చేరుకోవడానికి మీ గడువును పెంచండి',
      disclaimer: '⚠️ సాధారణ విద్యా సమాచారం మాత్రమే — వ్యక్తిగత పెట్టుబడి సలహా కాదు. పెట్టుబడి పెట్టే ముందు ధృవీకరించబడిన ఆర్థిక సలహాదారుని సంప్రదించండి.'
    }
  };

  const dict = planI18n[lang] || planI18n['en-IN'];
  const diffLabel = diff >= 0
    ? `<span class="plan-ok">${dict.bufText}</span>`
    : `<span class="plan-warn">${dict.shortText}</span>`;

  const verdictClass = feasible ? 'verdict-feasible' : 'verdict-infeasible';
  const verdictText  = feasible ? dict.verdictFeasible : dict.verdictInfeasible;

  // Month date formatting
  const targetDate = p.target_date_estimate
    ? new Date(p.target_date_estimate + 'T00:00:00').toLocaleDateString(lang, { month: 'long', year: 'numeric' })
    : '—';

  // Detailed Terminology Explanations by Horizon & Language
  const termExplanations = {
    short: {
      'en-IN': [
        {
          term: '💳 Liquid Mutual Fund / Overnight Fund',
          tag: 'High Safety • 24h Withdrawal',
          desc: 'A debt mutual fund that invests in short-term government treasury bills and safe corporate papers (1 to 91 days). It yields ~6–7% p.a. (indicative historical) without any lock-in period. You can withdraw your money back to your bank within 24 hours.'
        },
        {
          term: '📅 Recurring Deposit (RD)',
          tag: '100% Bank Guaranteed • Disciplined',
          desc: 'A scheduled bank deposit where you deposit a fixed monthly installment at a guaranteed interest rate. Protected up to ₹5,00,000 per bank by the RBI’s DICGC insurance.'
        },
        {
          term: '🛡️ Capital Preservation & Liquidity',
          tag: 'Core Financial Rule',
          desc: 'For goals under 12 months, avoiding market drops is rule #1. Never risk money you need soon in volatile equities; stability and quick access matter most.'
        }
      ],
      'hi-IN': [
        {
          term: '💳 लिक्विड म्यूचुअल फंड / ओवरनाइट फंड',
          tag: 'उच्च सुरक्षा • 24 घंटे में निकासी',
          desc: 'सरकारी और कॉर्पोरेट प्रतिभूतियों (1 से 91 दिन) में निवेश करने वाला फंड। इसमें कोई लॉक-इन नहीं होता, पैसा 24 घंटे में बैंक खाते में वापस आ सकता है और सामान्यतः बचत खाते से बेहतर रिटर्न मिलता है।'
        },
        {
          term: '📅 आवर्ती जमा (Recurring Deposit / RD)',
          tag: '100% बैंक गारंटी • अनुशासित बचत',
          desc: 'निश्चित ब्याज दर के साथ बैंक में हर महीने एक निश्चित राशि जमा करने की योजना। आरबीआई के डीआईसीजीसी बीमा के तहत ₹5 लाख तक पूरी तरह सुरक्षित।'
        },
        {
          term: '🛡️ पूंजी सुरक्षा (Capital Preservation)',
          tag: 'मूल वित्तीय सिद्धांत',
          desc: '1 साल से कम के लक्ष्यों के लिए मूलधन की सुरक्षा सबसे महत्वपूर्ण है। शेयर बाजार के उतार-चढ़ाव से दूर रहकर केवल स्थिर और सुरक्षित विकल्पों का चुनाव करें।'
        }
      ],
      'kn-IN': [
        {
          term: '💳 ಲಿಕ್ವಿಡ್ ಮ್ಯೂಚುಯಲ್ ಫಂಡ್ (Liquid Fund)',
          tag: 'ಹೆಚ್ಚಿನ ಭದ್ರತೆ • 24 ಗಂಟೆಗಳಲ್ಲಿ ಹಿಂಪಡೆಯುವಿಕೆ',
          desc: '1 ರಿಂದ 91 ದಿನಗಳ ಅಲ್ಪಾವಧಿಯ ಸರ್ಕಾರಿ ಭದ್ರತಾ ಪತ್ರಗಳಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡುವ ಫಂಡ್. ಯಾವುದೇ ಲಾಕ್-ಇನ್ ಇರುವುದಿಲ್ಲ, 24 ಗಂಟೆಗಳಲ್ಲಿ ಹಣವನ್ನು ನಿಮ್ಮ ಬ್ಯಾಂಕ್ ಖಾತೆಗೆ ಜಮಾ ಮಾಡಿಕೊಳ್ಳಬಹುದು.'
        },
        {
          term: '📅 ರಿಕರಿಂಗ್ ಡೆಪಾಸಿಟ್ (RD)',
          tag: 'ಬ್ಯಾಂಕ್ ಗ್ಯಾರಂಟಿ • ನಿಗದಿತ ಉಳಿತಾಯ',
          desc: 'ಖಾತರಿಪಡಿಸಿದ ಬಡ್ಡಿ ದರದೊಂದಿಗೆ ಪ್ರತಿ ತಿಂಗಳು ನಿಗದಿತ ಮೊತ್ತವನ್ನು ಉಳಿಸುವ ಬ್ಯಾಂಕ್ ಯೋಜನೆ. ಆರ್‌ಬಿಐ ನಿಯಮಗಳ ಅನ್ವಯ ₹5 ಲಕ್ಷದವರೆಗೆ ಸುರಕ್ಷಿತ.'
        },
        {
          term: '🛡️ ಬಂಡವಾಳ ಸಂರಕ್ಷಣೆ (Capital Safety)',
          tag: 'ಮೂಲ ಆರ್ಥಿಕ ನಿಯಮ',
          desc: '12 ತಿಂಗಳುಗಳ ಒಳಗಿನ ಗುರಿಗಳಿಗೆ ನಷ್ಟದ ಅಪಾಯವಿಲ್ಲದ ಭದ್ರತೆ ಮುಖ್ಯ. ಶಾರ್ಟ್ ಟರ್ಮ್ ಹಣವನ್ನು ಷೇರು ಮಾರುಕಟ್ಟೆಯಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಬಾರದು.'
        }
      ],
      'te-IN': [
        {
          term: '💳 లిక్విడ్ మ్యూచువల్ ఫండ్ (Liquid Fund)',
          tag: 'అత్యధిక భద్రత • 24 గంటల్లో నగదు',
          desc: '1 నుండి 91 రోజుల స్వల్పకాలిక ప్రభుత్వ సెక్యూరిటీలలో పెట్టుబడి పెట్టే ఫండ్. ఎలాంటి లాక్-ఇన్ ఉండదు, 24 గంటల్లో మీ డబ్బును బ్యాంకుకు బదిలీ చేసుకోవచ్చు.'
        },
        {
          term: '📅 రికరింగ్ డిపాజిట్ (RD)',
          tag: 'బ్యాంక్ గ్యారెంటీ • క్రమశిక్షణతో కూడిన పొదుపు',
          desc: 'ఖచ్చితమైన వడ్డీ రేటుతో ప్రతి నెలా నిర్దిష్ట మొత్తాన్ని పొదుపు చేసే విధానం. ఆర్బీఐ డిపాజిట్ ఇన్సూరెన్స్ ద్వారా ₹5 లక్షల వరకు పూర్తి భద్రత.'
        },
        {
          term: '🛡️ అసలు భద్రత (Capital Preservation)',
          tag: 'ముఖ్యమైన ఆర్థిక సూత్రం',
          desc: '1 సంవత్సరం లోపు గడువు ఉన్న లక్ష్యాలకు మార్కెట్ ఒడిదుడుకుల నుండి దూరంగా ఉండటం ముఖ్యం. తక్కువ రిస్క్ ఉన్న స్థిరమైన సాధనాలనే ఎంచుకోవాలి.'
        }
      ]
    },
    medium: {
      'en-IN': [
        {
          term: '🏦 Fixed Deposit (FD)',
          tag: 'Predictable Returns • DICGC Insured',
          desc: 'A lump-sum bank deposit where your interest rate is locked for the entire tenure (1 to 5 years). Zero market fluctuation and sovereign bank safety up to ₹5 Lakhs.'
        },
        {
          term: '📈 Debt Mutual Funds (Short Duration)',
          tag: 'Tax-Efficient • Moderate Yield',
          desc: 'Funds that pool money into high-rated corporate bonds and government securities, offering predictable yields with lower volatility than stocks.'
        },
        {
          term: '💰 Hybrid Mutual Funds',
          tag: 'Growth + Stability Blend',
          desc: 'Combines 65% equity for growth with 35% debt for cushioning against market dips. Well-suited for 3–5 year timeframes.'
        }
      ],
      'hi-IN': [
        {
          term: '🏦 सावधि जमा (Fixed Deposit / FD)',
          tag: 'निश्चित ब्याज • बैंक गारंटी',
          desc: 'एकमुश्त बैंक जमा जहां आपकी ब्याज दर 1 से 5 साल की अवधि के लिए तय रहती है। बाजार के जोखिम से पूरी तरह सुरक्षित।'
        },
        {
          term: '📈 डेट म्यूचुअल फंड (Debt Mutual Funds)',
          tag: 'टैक्स दक्षता • स्थिर प्रतिफल',
          desc: 'सरकारी प्रतिभूतियों और उच्च-रेटेड कॉर्पोरेट बॉन्ड्स में निवेश करने वाले फंड, जो शेयर बाजार की तुलना में बहुत कम अस्थिर होते हैं।'
        },
        {
          term: '💰 हाइब्रिड फंड (Hybrid Funds)',
          tag: 'ग्रोथ + सुरक्षा का संतुलन',
          desc: 'इक्विटी (शेयर) और डेट (बॉन्ड) का संतुलित मिश्रण। 3 से 5 साल के लक्ष्यों के लिए आदर्श संतुलन प्रदान करता है।'
        }
      ],
      'kn-IN': [
        {
          term: '🏦 ಫಿಕ್ಸ್ಡ್ ಡೆಪಾಸಿಟ್ (FD)',
          tag: 'ಖಾತರಿ ಲಾಭ • ಸುರಕ್ಷಿತ',
          desc: '1 ರಿಂದ 5 ವರ್ಷಗಳವರೆಗೆ ನಿಗದಿತ ಬಡ್ಡಿದರದಲ್ಲಿ ಹಣವನ್ನು ಠೇವಣಿ ಇಡುವ ಸಾಂಪ್ರದಾಯಿಕ ಬ್ಯಾಂಕ್ ಯೋಜನೆ.'
        },
        {
          term: '📈 ಡೆಟ್ ಮ್ಯೂಚುಯಲ್ ಫಂಡ್‌ಗಳು (Debt Funds)',
          tag: 'ಸ್ಥಿರ ಆದಾಯ • ಕಡಿಮೆ ಅಪಾಯ',
          desc: 'ಕಾರ್ಪೊರೇಟ್ ಬಾಂಡ್‌ಗಳು ಮತ್ತು ಸರ್ಕಾರಿ ಪತ್ರಗಳಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡುವ ಫಂಡ್‌ಗಳು, ಷೇರು ಮಾರುಕಟ್ಟೆಗಿಂತ ಹೆಚ್ಚು ಸ್ಥಿರವಾಗಿರುತ್ತವೆ.'
        },
        {
          term: '💰 ಹೈಬ್ರಿಡ್ ಮ್ಯೂಚುಯಲ್ ಫಂಡ್ (Hybrid Fund)',
          tag: 'ಬೆಳವಣಿಗೆ ಮತ್ತು ಭದ್ರತೆಯ ಸಮ್ಮಿಲನ',
          desc: 'ಷೇರುಗಳು ಮತ್ತು ಬಾಂಡ್‌ಗಳ ಸಮತೋಲಿತ ಮಿಶ್ರಣ. 3-5 ವರ್ಷಗಳ ಅವಧಿಯ ಗುರಿಗಳಿಗೆ ಸೂಕ್ತ.'
        }
      ],
      'te-IN': [
        {
          term: '🏦 ఫిక్స్‌డ్ డిపాజిట్ (FD)',
          tag: 'ఖచ్చితమైన రాబడి • సురక్షితం',
          desc: '1 నుండి 5 సంవత్సరాల కాలానికి ఖచ్చితమైన వడ్డీ రేటుతో బ్యాంకులో చేసే ఒకేసారి డిపాజిట్.'
        },
        {
          term: '📈 డెట్ మ్యూచువల్ ఫండ్స్ (Debt Funds)',
          tag: 'తక్కువ రిస్క్ • స్థిర రాబడి',
          desc: 'ప్రభుత్వ బాండ్లు, కార్పొరేట్ సెక్యూరిటీలలో పెట్టుబడి పెట్టే ఫండ్‌లు, ఈక్విటీ కంటే చాలా తక్కువ ఒడిదుడుకులు ఉంటాయి.'
        },
        {
          term: '💰 హైబ్రిడ్ ఫండ్స్ (Hybrid Funds)',
          tag: 'ఈక్విటీ + డెట్ కలయిక',
          desc: 'వృద్ధి కోసం ఈక్విటీ మరియు రక్షణ కోసం డెట్ కలయికతో కూడిన పెట్టుబడి సాధనం.'
        }
      ]
    },
    long: {
      'en-IN': [
        {
          term: '📈 Equity SIP (Systematic Investment Plan)',
          tag: 'Rupee Cost Averaging • Compounding',
          desc: 'Investing a disciplined sum every month into diversified equity funds. It buys more units when the market is low and fewer when high, harnessing long-term compounding.'
        },
        {
          term: '🌱 Index Funds (Nifty 50 / Sensex)',
          tag: 'Ultra-low Cost (<0.2%) • Pure Market Growth',
          desc: 'Low-cost passive mutual funds that automatically track India’s top 50 bluechip companies without active manager fees.'
        },
        {
          term: '🏛️ Public Provident Fund (PPF)',
          tag: 'Sovereign Guarantee • EEE Tax Free',
          desc: 'A 15-year central government savings scheme offering completely tax-free interest under Section 80C and sovereign capital guarantee.'
        }
      ],
      'hi-IN': [
        {
          term: '📈 इक्विटी एसआईपी (Equity SIP)',
          tag: 'चक्रवृद्धि लाभ • अनुशासित निवेश',
          desc: 'हर महीने निश्चित राशि इक्विटी फंडों में निवेश करने का तरीका। यह बाजार के उतार-चढ़ाव में औसत लागत का लाभ देकर दीर्घकालिक संपत्ति बनाता है।'
        },
        {
          term: '🌱 इंडेक्स फंड (Index Funds)',
          tag: 'न्यूनतम खर्च (<0.2%) • शीर्ष 50 कंपनियां',
          desc: 'भारत की शीर्ष 50 ब्लूचिप कंपनियों के प्रदर्शन को ट्रैक करने वाले पारदर्शी और बेहद कम लागत वाले फंड।'
        },
        {
          term: '🏛️ पब्लिक प्रोविडेंट फंड (PPF)',
          tag: '100% सरकारी गारंटी • कर मुक्त (EEE)',
          desc: '15 साल की लोकप्रिय सरकारी योजना, जिसमें ब्याज और मैच्योरिटी राशि दोनों पूरी तरह से कर-मुक्त होते हैं।'
        }
      ],
      'kn-IN': [
        {
          term: '📈 ಈಕ್ವಿಟಿ ಎಸ್ಐಪಿ (Equity SIP)',
          tag: 'ಕಂಪೌಂಡಿಂಗ್ ಲಾಭ • ನಿಯಮಿತ ಉಳಿತಾಯ',
          desc: 'ಪ್ರತಿ ತಿಂಗಳು ನಿಗದಿತ ಮೊತ್ತವನ್ನು ಷೇರು ಮ್ಯೂಚುಯಲ್ ಫಂಡ್‌ಗಳಲ್ಲಿ ತೊಡಗಿಸುವ ವಿಧಾನ. ದೀರ್ಘಾವಧಿಯಲ್ಲಿ ಹೆಚ್ಚಿನ ಸಂಪತ್ತು ಸೃಷ್ಟಿಗೆ ಸಹಕಾರಿ.'
        },
        {
          term: '🌱 ಇಂಡೆಕ್ಸ್ ಫಂಡ್‌ಗಳು (Index Funds)',
          tag: 'ಕಡಿಮೆ ವೆಚ್ಚ • ಭಾರತದ ಟಾಪ್ 50 ಕಂಪನಿಗಳು',
          desc: 'ನಿಫ್ಟಿ 50 ಕಂಪನಿಗಳಲ್ಲಿ ಕಡಿಮೆ ನಿರ್ವಹಣಾ ವೆಚ್ಚದಲ್ಲಿ ನೇರವಾಗಿ ಹೂಡಿಕೆ ಮಾಡುವ ಸುಲಭ ವಿಧಾನ.'
        },
        {
          term: '🏛️ ಪಿಪಿಎಫ್ (Public Provident Fund)',
          tag: 'ಸರ್ಕಾರಿ ಖಾತರಿ • ಸಂಪೂರ್ಣ ತೆರಿಗೆ ಮುಕ್ತ',
          desc: '15 ವರ್ಷಗಳ ಕೇಂದ್ರ ಸರ್ಕಾರದ ಉಳಿತಾಯ ಯೋಜನೆ, ಬಂಡವಾಳ ಮತ್ತು ಬಡ್ಡಿಗೆ ಪೂರ್ಣ ತೆರಿಗೆ ವಿನಾಯಿತಿ.'
        }
      ],
      'te-IN': [
        {
          term: '📈 ఈక్విటీ ఎస్ఐపీ (Equity SIP)',
          tag: 'చక్రవడ్డీ ప్రయోజనం • క్రమశిక్షణతో కూడిన పెట్టుబడి',
          desc: 'ప్రతి నెలా క్రమం తప్పకుండా ఈక్విటీ ఫండ్లలో పెట్టుబడి పెట్టే విధానం. దీర్ఘకాలంలో సంపద సృష్టికి దోహదపడుతుంది.'
        },
        {
          term: '🌱 ఇండెక్స్ ఫండ్స్ (Index Funds)',
          tag: 'అత్యల్ప ఖర్చు • టాప్ 50 కంపెనీలు',
          desc: 'భారతదేశ అగ్రశ్రేణి 50 కంపెనీలలో పారదర్శకంగా పెట్టుబడి పెట్టే తక్కువ ఖర్చుతో కూడిన ఫండ్‌లు.'
        },
        {
          term: '🏛️ పీపీఎఫ్ (PPF)',
          tag: 'ప్రభుత్వ హామీ • పన్ను మినహాయింపు',
          desc: '15 సంవత్సరాల కేంద్ర ప్రభుత్వ పథకం, వడ్డీ మరియు రాబడి రెండింటిపై పూర్తి పన్ను మినహాయింపు.'
        }
      ]
    }
  };

  const currentHorizon = p.horizon || (p.months <= 12 ? 'short' : p.months <= 60 ? 'medium' : 'long');
  const horizonTerms = (termExplanations[currentHorizon] && termExplanations[currentHorizon][lang])
    || termExplanations[currentHorizon]['en-IN'];

  const termsCardsHtml = horizonTerms.map(t => `
    <div class="plan-term-card">
      <div class="term-card-header">
        <span class="term-name">${escHtml(t.term)}</span>
        <span class="term-tag">${escHtml(t.tag)}</span>
      </div>
      <p class="term-desc">${escHtml(t.desc)}</p>
    </div>
  `).join('');

  // Localized Horizon Rationale & Instruments (ensures NO English leaks in Hindi/Kannada/Telugu)
  const horizonLocalizations = {
    short: {
      'en-IN': {
        rationale: p.horizon_rationale || 'For goals under 1 year, capital safety and liquidity matter most. Market-linked instruments can fluctuate over short periods, so low-risk, stable options are generally preferred.',
        instruments: [
          '💳 Savings Account / Liquid Fund — instant access, low risk',
          '📅 Recurring Deposit (RD) — fixed monthly savings, bank-guaranteed',
          '🏦 Short-term Fixed Deposit (FD) — slightly higher interest, low risk'
        ]
      },
      'hi-IN': {
        rationale: '1 साल से कम के लक्ष्यों के लिए मूलधन की सुरक्षा और तुरंत निकासी (लिक्विडिटी) सबसे जरूरी है। अल्पकाल में शेयर बाजार के उतार-चढ़ाव से बचने के लिए कम जोखिम वाले सुरक्षित विकल्प ही चुने जाते हैं।',
        instruments: [
          '💳 बचत खाता / लिक्विड म्यूचुअल फंड — कभी भी निकासी, सबसे कम जोखिम',
          '📅 आवर्ती जमा (RD) — निश्चित मासिक बचत, सरकारी बैंक गारंटी',
          '🏦 अल्पकालिक सावधि जमा (FD) — सुरक्षित और गारंटीड ब्याज'
        ]
      },
      'kn-IN': {
        rationale: '1 ವರ್ಷಕ್ಕಿಂತ ಕಡಿಮೆ ಅವಧಿಯ ಗುರಿಗಳಿಗೆ ಬಂಡವಾಳ ಸುರಕ್ಷತೆ ಮತ್ತು ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಹಣ ಹಿಂಪಡೆಯುವಿಕೆ ಅತ್ಯಂತ ಮುಖ್ಯ. ಮಾರುಕಟ್ಟೆ ಏರಿಳಿತಗಳಿಂದ ದೂರವಿರಲು ಕಡಿಮೆ ಅಪಾಯವಿರುವ ಸ್ಥಿರ ಉಳಿತಾಯ ಉತ್ತಮ.',
        instruments: [
          '💳 ಉಳಿತಾಯ ಖಾತೆ / ಲಿಕ್ವಿಡ್ ಫಂಡ್ — ಸುಲಭ ಹಿಂಪಡೆಯುವಿಕೆ, ಅತ್ಯಂತ ಕಡಿಮೆ ರಿಸ್ಕ್',
          '📅 ರಿಕರಿಂಗ್ ಡೆಪಾಸಿಟ್ (RD) — ಪ್ರತಿ ತಿಂಗಳು ನಿಶ್ಚಿತ ಉಳಿತಾಯ, ಬ್ಯಾಂಕ್ ಗ್ಯಾರಂಟಿ',
          '🏦 ಅಲ್ಪಾವಧಿ ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ (FD) — ಖಾತರಿಪಡಿಸಿದ ಸುರಕ್ಷಿತ ಬಡ್ಡಿ'
        ]
      },
      'te-IN': {
        rationale: '1 సంవత్సరం కంటే తక్కువ వ్యవధి గల లక్ష్యాలకు పెట్టుబడి భద్రత మరియు సులభంగా నగదు పొందే సౌలభ్యం ముఖ్యం. మార్కెట్ ఒడిదుడుకుల వల్ల నష్టం జరగకుండా స్థిరమైన, తక్కువ రిస్క్ ఉన్న మార్గాలు శ్రేయస్కరం.',
        instruments: [
          '💳 పొదుపు ఖాతా / లిక్విడ్ ఫండ్ — ఎప్పుడైనా విత్‌డ్రా చేసుకునే వెసులుబాటు, తక్కువ రిస్క్',
          '📅 రికరింగ్ డిపాజిట్ (RD) — ప్రతి నెలా క్రమం తప్పకుండా పొదుపు, బ్యాంకు హామీ',
          '🏦 స్వల్పకాలిక ఫిక్స్‌డ్ డిపాజిట్ (FD) — సురక్షితమైన రాబడి, తక్కువ రిస్క్'
        ]
      }
    },
    medium: {
      'en-IN': {
        rationale: p.horizon_rationale || 'Medium-term goals (1–5 years) can tolerate moderate risk for potentially better returns. A balanced mix of stable deposits and low-to-medium risk debt options is commonly used.',
        instruments: [
          '🏦 Fixed Deposit (FD) — predictable returns, bank-guaranteed',
          '📈 Short to Medium Duration Debt Funds — tax efficiency, low risk',
          '🏛️ PPF (partial) — tax-free sovereign guarantee',
          '💰 ELSS Mutual Funds — 3-year lock-in with Sec 80C tax benefits'
        ]
      },
      'hi-IN': {
        rationale: 'मध्यम अवधि (1 से 5 वर्ष) के लक्ष्यों के लिए थोड़े बेहतर रिटर्न के लिए संतुलित जोखिम लिया जा सकता है। इसमें स्थिर सावधि जमा और कम जोखिम वाले डेट फंडों का मिश्रण सबसे उपयुक्त होता है।',
        instruments: [
          '🏦 सावधि जमा (FD) — गारंटीड और सुरक्षित रिटर्न',
          '📈 डेट म्यूचुअल फंड — बैंक से बेहतर संभावित रिटर्न, नियंत्रित जोखिम',
          '🏛️ पीपीएफ (PPF) — सरकारी सुरक्षा और पूरी तरह कर-मुक्त रिटर्न',
          '💰 ईएलएसएस (ELSS) — 3 साल की न्यूनतम लॉक-इन अवधि और धारा 80सी कर छूट'
        ]
      },
      'kn-IN': {
        rationale: 'ಮಧ್ಯಮಾವಧಿ (1 ರಿಂದ 5 ವರ್ಷ) ಗುರಿಗಳಿಗೆ ಉತ್ತಮ ಆದಾಯಕ್ಕಾಗಿ ಸಮತೋಲಿತ ರಿಸ್ಕ್ ತೆಗೆದುಕೊಳ್ಳಬಹುದು. ಬ್ಯಾಂಕ್ ಠೇವಣಿ ಮತ್ತು ಕಡಿಮೆ ಅಪಾಯದ ಡೆಟ್ ಫಂಡ್‌ಗಳ ಸಂಯೋಜನೆ ಸೂಕ್ತ.',
        instruments: [
          '🏦 ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ (FD) — ನಿಶ್ಚಿತ ಮತ್ತು ಸುರಕ್ಷಿತ ಆದಾಯ',
          '📈 ಡೆಟ್ ಮ್ಯೂಚುಯಲ್ ಫಂಡ್ — ತೆರಿಗೆ ಉಳಿತಾಯ, ಕಡಿಮೆ ಅಪಾಯ',
          '🏛️ ಪಿಪಿಎಫ್ (PPF) — ಸಂಪೂರ್ಣ ತೆರಿಗೆ ರಹಿತ ಸರ್ಕಾರಿ ಭದ್ರತೆ',
          '💰 ಇಎಲ್‌ಎಸ್‌ಎಸ್ (ELSS) — 3 ವರ್ಷಗಳ ಲಾಕ್-ಇನ್ ಮತ್ತು ಸೆಕ್ಷನ್ 80C ತೆರಿಗೆ ವಿನಾಯಿತಿ'
        ]
      },
      'te-IN': {
        rationale: 'మధ్యస్థ కాలవ్యవధి (1 నుండి 5 సంవత్సరాలు) లక్ష్యాలకు మెరుగైన రాబడి కోసం కొంత సమతుల్య రిస్క్ తీసుకోవచ్చు. స్థిరమైన డిపాజిట్లు మరియు తక్కువ రిస్క్ ఉన్న డెట్ ఫండ్స్ సరైన ఎంపిక.',
        instruments: [
          '🏦 ఫిక్స్‌డ్ డిపాజిట్ (FD) — హామీతో కూడిన నిశ్చిత రాబడి',
          '📈 డెట్ మ్యూచువల్ ఫండ్స్ — పన్ను ఆదా మరియు స్థిరమైన రాబడి',
          '🏛️ పీపీఎఫ్ (PPF) — పూర్తి పన్ను మినహాయింపు మరియు ప్రభుత్వ రక్షణ',
          '💰 ఈఎల్ఎస్ఎస్ (ELSS) — 3 సంవత్సరాల లాక్-ఇన్ మరియు సెక్షన్ 80C పన్ను ప్రయోజనం'
        ]
      }
    },
    long: {
      'en-IN': {
        rationale: p.horizon_rationale || 'Long-term goals (5+ years) allow ample time to ride out short-term market cycles. Equity-oriented instruments have historically beaten inflation and offered high wealth growth over time.',
        instruments: [
          '📈 Equity Mutual Funds / SIP — high growth compounding over long periods',
          '🏛️ PPF — 15-year sovereign tax-free compounding',
          '👴 National Pension System (NPS) — retirement wealth & dedicated tax deduction',
          '🌱 Low-cost Index Funds — broad market diversification'
        ]
      },
      'hi-IN': {
        rationale: 'दीर्घकालिक लक्ष्यों (5 वर्ष से अधिक) में बाजार के उतार-चढ़ाव को मात देने का पर्याप्त समय मिलता है। मुद्रास्फीति को हराने और धन निर्माण के लिए इक्विटी और सरकारी योजनाओं का संयोजन सर्वोत्तम है।',
        instruments: [
          '📈 इक्विटी म्यूचुअल फंड / एसआईपी (SIP) — लंबी अवधि में चक्रवृद्धि ब्याज से बड़ा कोष',
          '🏛️ पब्लिक प्रोविडेंट फंड (PPF) — 15 साल की संप्रभु गारंटी और कर-मुक्त रिटर्न',
          '👴 राष्ट्रीय पेंशन प्रणाली (NPS) — सेवानिवृत्ति के लिए अतिरिक्त कर लाभ',
          '🌱 इंडेक्स फंड — देश की शीर्ष कंपनियों में सबसे कम खर्च पर निवेश'
        ]
      },
      'kn-IN': {
        rationale: 'ದೀರ್ಘಾವಧಿಯ (5+ ವರ್ಷಗಳು) ಗುರಿಗಳಿಗೆ ಮಾರುಕಟ್ಟೆ ಚಕ್ರಗಳನ್ನು ಸಮರ್ಥವಾಗಿ ಎದುರಿಸಲು ಸಮಯಾವಕಾಶವಿದೆ. ಹಣದುಬ್ಬರವನ್ನು ಮೀರಿ ಸಂಪತ್ತು ಗಳಿಸಲು ಇಕ್ವಿಟಿ ಮತ್ತು ದೀರ್ಘಾವಧಿ ಸರ್ಕಾರಿ ಉಳಿತಾಯ ಯೋಜನೆಗಳು ಸೂಕ್ತ.',
        instruments: [
          '📈 ಇಕ್ವಿಟಿ ಮ್ಯೂಚುಯಲ್ ಫಂಡ್ / ಎಸ್ಐಪಿ (SIP) — ದೀರ್ಘಾವಧಿಯಲ್ಲಿ ಗರಿಷ್ಠ ಬೆಳವಣಿಗೆ',
          '🏛️ ಸಾರ್ವಜನಿಕ ಭವಿಷ್ಯ ನಿಧಿ (PPF) — 15 ವರ್ಷಗಳ ಸಂಪೂರ್ಣ ತೆರಿಗೆ ರಹಿತ ಭದ್ರತೆ',
          '👴 ರಾಷ್ಟ್ರೀಯ ಪಿಂಚಣಿ ಯೋಜನೆ (NPS) — ನಿವೃತ್ತಿ ಯೋಜನೆ ಮತ್ತು ವಿಶೇಷ ತೆರಿಗೆ ವಿನಾಯಿತಿ',
          '🌱 ಇಂಡೆಕ್ಸ್ ಫಂಡ್‌ಗಳು — ಭಾರತದ ಪ್ರಮುಖ ಕಂಪನಿಗಳಲ್ಲಿ ಕಡಿಮೆ ವೆಚ್ಚದ ಹೂಡಿಕೆ'
        ]
      },
      'te-IN': {
        rationale: 'దీర్ఘకాలిక లక్ష్యాలకు (5+ సంవత్సరాలు) మార్కెట్ హెచ్చుతగ్గులను తట్టుకుని దీర్ఘకాలంలో ద్రవ్యోల్బణాన్ని అధిగమించేందుకు ఈక్విటీ ఆధారిత పొదుపు సాధనాలు అత్యుత్తమ రాబడిని అందిస్తాయి.',
        instruments: [
          '📈 ఈక్విటీ మ్యూచువల్ ఫండ్స్ / సిప్ (SIP) — దీర్ఘకాలంలో చక్రవడ్డీతో సంపద సృష్టి',
          '🏛️ పబ్లిక్ ప్రావిడెంట్ ఫండ్ (PPF) — 15 సంవత్సరాల కాలపరిమితి, పన్ను రహిత ప్రభుత్వ హామీ',
          '👴 నేషనల్ పెన్షన్ సిస్టమ్ (NPS) — రిటైర్మెంట్ కోసం ప్రత్యేక పన్ను ఆదా',
          '🌱 ఇండెక్స్ ఫండ్స్ — అత్యల్ప ఖర్చుతో దేశంలోని అగ్రశ్రేణి కంపెనీలలో పెట్టుబడి'
        ]
      }
    }
  };

  const hLocData = (horizonLocalizations[currentHorizon] && horizonLocalizations[currentHorizon][lang])
    || horizonLocalizations[currentHorizon]['en-IN'];
  const localizedRationale = hLocData.rationale;
  const instruments = hLocData.instruments
    .map(i => `<li class="instrument-item">${escHtml(i)}</li>`).join('');

  container.innerHTML = `
    <div class="plan-card">

      <!-- Goal title bar -->
      <div class="plan-title">${dict.title}: ${escHtml(p.goal_name)}</div>

      <!-- Verdict -->
      <div class="plan-verdict ${verdictClass}">${verdictText}</div>

      <!-- Numbers grid -->
      <div class="plan-numbers-grid">
        <div class="plan-number-cell">
          <div class="plan-number-label">${dict.lblTarget}</div>
          <div class="plan-number-value">₹${Number(p.target_amount).toLocaleString('en-IN')}</div>
        </div>
        <div class="plan-number-cell">
          <div class="plan-number-label">${dict.lblTimeline}</div>
          <div class="plan-number-value">${p.months} ${dict.monthsUnit}</div>
        </div>
        <div class="plan-number-cell">
          <div class="plan-number-label">${dict.lblNeed}</div>
          <div class="plan-number-value accent">₹${Number(p.required_monthly_saving).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</div>
        </div>
        <div class="plan-number-cell">
          <div class="plan-number-label">${dict.lblSurplus}</div>
          <div class="plan-number-value ${p.current_monthly_surplus > 0 ? 'ok' : 'warn'}">
            ₹${Number(p.current_monthly_surplus).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </div>
        </div>
        <div class="plan-number-cell">
          <div class="plan-number-label">${dict.lblDiff}</div>
          <div class="plan-number-value">${diffLabel}</div>
        </div>
        <div class="plan-number-cell">
          <div class="plan-number-label">${dict.lblEstDate}</div>
          <div class="plan-number-value">${targetDate}</div>
        </div>
      </div>

      ${!feasible ? `
      <div class="plan-tip">
        ${dict.tipPrefix} <strong>${Math.ceil(p.target_amount / Math.max(p.current_monthly_surplus, 1))} ${dict.monthsUnit}</strong>.
      </div>` : ''}

      <!-- Horizon & Instruments (educational) -->
      <div class="plan-section">
        <div class="plan-section-label">${dict.instrumentsHeader}</div>
        <p class="plan-rationale">${escHtml(localizedRationale)}</p>
        <ul class="instruments-list">${instruments}</ul>
      </div>

      <!-- DETAILED TERMINOLOGY EXPLAINED -->
      <div class="plan-section plan-terms-section">
        <div class="plan-section-label">${dict.termsHeader}</div>
        <p class="plan-terms-sub">${dict.termsSubtitle}</p>
        <div class="plan-terms-grid">
          ${termsCardsHtml}
        </div>
      </div>

      <!-- Listen button (with browser speech fallback) -->
      <button class="btn btn-secondary btn-sm" id="btn-listen-plan" style="align-self:flex-start">
        ${dict.listenBtn}
      </button>

      <!-- Disclaimer -->
      <div class="plan-disclaimer">${dict.disclaimer}</div>

    </div>`;

  // Bind Listen button safely
  const listenBtn = container.querySelector('#btn-listen-plan');
  if (listenBtn) {
    listenBtn.addEventListener('click', () => {
      listenToPlan(p, listenBtn);
    });
  }
}

// ---------------------------------------------------------------------------
// Delete goal
// ---------------------------------------------------------------------------
async function deleteGoal(goalId) {
  if (!confirm('Delete this goal?')) return;
  try {
    const res = await fetch(`/api/goals/${goalId}`, {
      method: 'DELETE',
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (res.ok || res.status === 204) {
      showToast('Goal deleted.', 'info', 2000);
      // Clear plan if it was showing this goal
      const planSection = document.getElementById('goal-plan-section');
      if (planSection) planSection.style.display = 'none';
      loadGoals();
    } else {
      showToast('Could not delete goal.', 'error');
    }
  } catch { showToast('Could not delete goal.', 'error'); }
}

// ---------------------------------------------------------------------------
// Listen (Phase 6 TTS — fully wired & localized)
// ---------------------------------------------------------------------------
function listenToPlan(plan, btn) {
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const target = Math.round(plan.target_amount).toLocaleString('en-IN');
  const needed = Math.ceil(plan.required_monthly_saving).toLocaleString('en-IN');
  const surplus = Math.ceil(plan.current_monthly_surplus).toLocaleString('en-IN');
  const shortfall = Math.ceil(Math.abs(plan.shortfall_or_buffer)).toLocaleString('en-IN');

  let spoken = '';

  if (lang === 'hi-IN') {
    spoken = [
      `बचत लक्ष्य: ${plan.goal_name}।`,
      `लक्ष्य राशि ₹${target}, ${plan.months} महीनों में।`,
      `आपको हर महीने ₹${needed} बचाने होंगे।`,
      `आपकी वर्तमान मासिक बचत ₹${surplus} है।`,
      plan.is_feasible
        ? 'बधाई हो! आपकी वर्तमान मासिक बचत के साथ यह लक्ष्य पूरी तरह संभव है।'
        : `इस लक्ष्य के लिए आपको हर महीने ₹${shortfall} की कमी है। कृपया समय सीमा बढ़ाएं या खर्च कम करें।`
    ].join(' ');
  } else if (lang === 'kn-IN') {
    spoken = [
      `ಉಳಿತಾಯ ಗುರಿ: ${plan.goal_name}.`,
      `ಗುರಿ ಮೊತ್ತ ₹${target}, ${plan.months} ತಿಂಗಳುಗಳಲ್ಲಿ.`,
      `ನೀವು ತಿಂಗಳಿಗೆ ₹${needed} ಉಳಿಸಬೇಕು.`,
      `ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಮಾಸಿಕ ಉಳಿತಾಯ ₹${surplus}.`,
      plan.is_feasible
        ? 'ಶುಭ ಸುದ್ದಿ! ನಿಮ್ಮ ಪ್ರಸ್ತುತ ಉಳಿತಾಯದಿಂದ ಈ ಗುರಿಯನ್ನು ಸಾಧಿಸಬಹುದು.'
        : `ನಿಮಗೆ ತಿಂಗಳಿಗೆ ₹${shortfall} ಕೊರತೆಯಿದೆ. ದಯವಿಟ್ಟು ಕಾಲಾವಧಿ ಹೆಚ್ಚಿಸಿ.`
    ].join(' ');
  } else if (lang === 'te-IN') {
    spoken = [
      `పొదుపు లక్ష్యం: ${plan.goal_name}.`,
      `లక్ష్య మొత్తం ₹${target}, ${plan.months} నెలల్లో.`,
      `మీరు నెలకు ₹${needed} పొదుపు చేయాలి.`,
      `మీ ప్రస్తుత నెలవారీ మిగులు ₹${surplus}.`,
      plan.is_feasible
        ? 'శుభవార్త! మీ ప్రస్తుత పొదుపుతో ఈ లక్ష్యాన్ని సాధించవచ్చు.'
        : `మీకు నెలకు ₹${shortfall} కొరత ఉంది. దయచేసి గడువు పెంచండి.`
    ].join(' ');
  } else {
    spoken = [
      `Goal: ${plan.goal_name}.`,
      `Target: ₹${target} in ${plan.months} months.`,
      `You need to save ₹${needed} per month.`,
      `Your current monthly surplus is ₹${surplus}.`,
      plan.is_feasible
        ? 'Great news — this goal is fully achievable with your current savings!'
        : `You have a shortfall of ₹${shortfall} per month. Consider extending your timeline or reducing expenses.`,
      plan.horizon_rationale || ''
    ].join(' ');
  }

  const targetBtn = btn || document.getElementById('btn-listen-plan');

  if (typeof window.speakText === 'function') {
    window.speakText(spoken, lang, targetBtn);
  } else {
    showToast('🔊 Audio unavailable right now.', 'info', 3000);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ---------------------------------------------------------------------------
// Expose
// ---------------------------------------------------------------------------
window.initGoals     = initGoals;
window.loadGoals     = loadGoals;
window.renderPlan    = renderPlan;
window.listenToPlan  = listenToPlan;
