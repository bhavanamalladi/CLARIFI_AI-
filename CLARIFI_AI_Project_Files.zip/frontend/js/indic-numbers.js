/**
 * CLARIFI AI — Indic Number Conversion Engine (indic-numbers.js)
 * 
 * Automatically detects native numerals (Devanagari ०-९, Kannada ೦-೯, Telugu ౦-౯)
 * and native spoken number words in Hindi, Kannada, Telugu, and English,
 * converting them into standard digits/figures (e.g. 450, 500, 2000)
 * so that users in any language see the clear numeric figure written in text.
 */

'use strict';

(function(window) {
  // 1. Script digit maps
  const SCRIPT_DIGITS = {
    // Devanagari (Hindi)
    '०': '0', '१': '1', '२': '2', '३': '3', '४': '4', '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
    // Kannada
    '೦': '0', '೧': '1', '೨': '2', '೩': '3', '೪': '4', '೫': '5', '೬': '6', '೭': '7', '೮': '8', '೯': '9',
    // Telugu
    '౦': '0', '౧': '1', '౨': '2', '౩': '3', '౪': '4', '౫': '5', '౬': '6', '౭': '7', '౮': '8', '౯': '9'
  };

  // 2. Hindi number words
  const HINDI_WORDS = {
    'एक': 1, 'दो': 2, 'तीन': 3, 'चार': 4, 'पांच': 5, 'पाँच': 5, 'छह': 6, 'छः': 6, 'सात': 7, 'आठ': 8, 'नौ': 9, 'दस': 10,
    'ग्यारह': 11, 'बारह': 12, 'तेरह': 13, 'चौदह': 14, 'पंद्रह': 15, 'सोलह': 16, 'सत्रह': 17, 'अठारह': 18, 'उन्नीस': 19, 'बीस': 20,
    'इक्कीस': 21, 'बाईस': 22, 'तेईस': 23, 'चौबीस': 24, 'पच्चीस': 25, 'छब्बीस': 26, 'सत्ताईस': 27, 'अट्ठाईस': 28, 'उनतीस': 29, 'तीस': 30,
    'इकत्तीस': 31, 'बत्तीस': 32, 'तैंतीस': 33, 'चौंतीस': 34, 'पैंतीस': 35, 'छत्तीस': 36, 'सैंतीस': 37, 'अड़तीस': 38, 'उनतालीस': 39, 'चालीस': 40,
    'इकतालीस': 41, 'बयालीस': 42, 'तैंतालीस': 43, 'चवालीस': 44, 'पैंतालीस': 45, 'छियालीस': 46, 'सैंतालीस': 47, 'अड़तालीस': 48, 'उनचास': 49, 'पचास': 50,
    'इक्यावन': 51, 'बावन': 52, 'तिरेपन': 53, 'चौवन': 54, 'पचपन': 55, 'छप्पन': 56, 'सत्तावन': 57, 'अट्ठावन': 58, 'उनसठ': 59, 'साठ': 60,
    'इकसठ': 61, 'बासठ': 62, 'तिरसठ': 63, 'चौंसठ': 64, 'पैंसठ': 65, 'छियासठ': 66, 'सरसठ': 67, 'अड़सठ': 68, 'उनहत्तर': 69, 'सत्तर': 70,
    'इकहत्तर': 71, 'बहत्तर': 72, 'तिहत्तर': 73, 'चौहत्तर': 74, 'पचहत्तर': 75, 'छिहत्तर': 76, 'सतहत्तर': 77, 'अठहत्तर': 78, 'उन्नासी': 79, 'अस्सी': 80,
    'इक्यासी': 81, 'बयासी': 82, 'तिरासी': 83, 'चौरासी': 84, 'पचासी': 85, 'छियासी': 86, 'सतासी': 87, 'अट्ठासी': 88, 'नवासी': 89, 'नब्बे': 90,
    'इक्यानवे': 91, 'बानवे': 92, 'तिरानवे': 93, 'चौरानवे': 94, 'पंचानवे': 95, 'पिचानवे': 95, 'छियानवे': 96, 'सत्तानवे': 97, 'अट्ठानवे': 98, 'निन्यानवे': 99,
    'सौ': 100, 'हज़ार': 1000, 'हजार': 1000, 'लाख': 100000, 'करोड़': 10000000
  };

  // 3. Kannada number words
  const KANNADA_WORDS = {
    'ಒಂದು': 1, 'ಎರಡು': 2, 'ಮೂರು': 3, 'ನಾಲ್ಕು': 4, 'ಐದು': 5, 'ಆರು': 6, 'ಏಳು': 7, 'ಎಂಟು': 8, 'ಒಂಬತ್ತು': 9, 'ಹತ್ತು': 10,
    'ಹನ್ನೊಂದು': 11, 'ಹನ್ನೆರಡು': 12, 'ಹದಿಮೂರು': 13, 'ಹದಿನಾಲ್ಕು': 14, 'ಹದಿನೈದು': 15, 'ಹದಿನಾರು': 16, 'ಹದಿನೇಳು': 17, 'ಹದಿನೆಂಟು': 18, 'ಹತ್ತೊಂಬತ್ತು': 19, 'ಇಪ್ಪತ್ತು': 20,
    'ಇಪ್ಪತ್ತೊಂದು': 21, 'ಇಪ್ಪತ್ತೆರಡು': 22, 'ಇಪ್ಪತ್ತೂರು': 23, 'ಇಪ್ಪತ್ನಾಲ್ಕು': 24, 'ಇಪ್ಪತ್ತೈದು': 25, 'ಮೂವತ್ತು': 30, 'ಮೂವತ್ತೈದು': 35,
    'ನಲವತ್ತು': 40, 'ನಲವತ್ತೈದು': 45, 'ಐವತ್ತು': 50, 'ಐವತ್ತೈದು': 55, 'ಅರವತ್ತು': 60, 'ಎಪ್ಪತ್ತು': 70, 'ಎಂಬತ್ತು': 80, 'ತೊಂಬತ್ತು': 90,
    'ನೂರು': 100, 'ಇನ್ನೂರು': 200, 'ಮುನ್ನೂರು': 300, 'ನಾನೂರು': 400, 'ಐನೂರು': 500, 'ಆರುನೂರು': 600, 'ಏಳುನೂರು': 700, 'ಎಂಟುನೂರು': 800, 'ಒಂಬೈನೂರು': 900,
    'ನೂರ': 100, 'ಇನ್ನೂರ': 200, 'ಮುನ್ನೂರ': 300, 'ನಾನೂರ': 400, 'ಐನೂರ': 500, 'ಆರುನೂರ': 600,
    'ಸಾವಿರ': 1000, 'ಲಕ್ಷ': 100000, 'ಕೋಟಿ': 10000000
  };

  // 4. Telugu number words
  const TELUGU_WORDS = {
    'ఒకటి': 1, 'రెండు': 2, 'మూడు': 3, 'నాలుగు': 4, 'ఐదు': 5, 'ఆరు': 6, 'ఏడు': 7, 'ఎనిమిది': 8, 'తొమ్మిది': 9, 'పది': 10,
    'పదకొండు': 11, 'పన్నెండు': 12, 'పదమూడు': 13, 'పద్నాలుగు': 14, 'పదిహేను': 15, 'పదహారు': 16, 'పదిహేడు': 17, 'పద్దెనిమిది': 18, 'పంతొమ్మిది': 19, 'ఇరవై': 20,
    'ఇరవై ఒకటి': 21, 'ఇరవై రెండు': 22, 'ఇరవై ఐదు': 25, 'ముప్పై': 30, 'ముప్పై ఐదు': 35,
    'నలభై': 40, 'నలబై': 40, 'నలభై ఐదు': 45, 'యాభై': 50, 'యాభై ఐదు': 55, 'అరవై': 60, 'డెబ్బై': 70, 'ఎనభై': 80, 'తొంభై': 90,
    'వంద': 100, 'వందలు': 100, 'నూరు': 100, 'వందల': 100,
    'వెయ్యి': 1000, 'వేయి': 1000, 'వేలు': 1000, 'లక్ష': 100000, 'కోటి': 10000000
  };

  // 5. English & Romanized Indic
  const ENGLISH_AND_ROMAN = {
    'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7, 'eight': 8, 'nine': 9, 'ten': 10,
    'eleven': 11, 'twelve': 12, 'thirteen': 13, 'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18, 'nineteen': 19, 'twenty': 20,
    'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70, 'eighty': 80, 'ninety': 90,
    'hundred': 100, 'thousand': 1000, 'lakh': 100000, 'crore': 10000000,
    // Hinglish
    'ek': 1, 'do': 2, 'teen': 3, 'char': 4, 'chaar': 4, 'panch': 5, 'paanch': 5, 'chhe': 6, 'saat': 7, 'aath': 8, 'nau': 9, 'das': 10,
    'gyarah': 11, 'barah': 12, 'pandrah': 15, 'bees': 20, 'pachees': 25, 'pachis': 25, 'tees': 30, 'chalis': 40, 'pachas': 50, 'saath': 60, 'sattar': 70, 'assi': 80, 'nabbe': 90,
    'sau': 100, 'hazar': 1000, 'hazaar': 1000,
    // Kanglish
    'ondu': 1, 'eradu': 2, 'mooru': 3, 'naalku': 4, 'aidu': 5, 'aaru': 6, 'yelu': 7, 'entu': 8, 'ombattu': 9, 'hattu': 10,
    'ippattu': 20, 'ippattaidu': 25, 'moovattu': 30, 'nalavattu': 40, 'aivattu': 50, 'aravattu': 60, 'eppattu': 70, 'embattu': 80, 'tombattu': 90,
    'nooru': 100, 'innooru': 200, 'munnooru': 300, 'naanooru': 400, 'ainooru': 500, 'naanoora': 400, 'ainoora': 500, 'saavira': 1000, 'laksha': 100000,
    // Tenglish
    'okati': 1, 'rendu': 2, 'moodu': 3, 'naalugu': 4, 'vanda': 100, 'vandalu': 100, 'vandala': 100,
    'iravai': 20, 'muppai': 30, 'nalabhai': 40, 'yaabhai': 50, 'veyyi': 1000, 'veelu': 1000
  };

  const ALL_WORDS = Object.assign({}, HINDI_WORDS, KANNADA_WORDS, TELUGU_WORDS, ENGLISH_AND_ROMAN);

  const MULTI_WORD_COLLOQUIAL = {
    'डेढ़ सौ': 150, 'ढाई सौ': 250, 'डेढ़ हजार': 1500, 'ढाई हजार': 2500,
    'डेढ़ हज़ार': 1500, 'ढाई हज़ार': 2500, 'साढ़े तीन सौ': 350, 'साढ़े चार सौ': 450, 'साढ़े पांच सौ': 550,
    'ಒಂದೂವರೆ ಸಾವಿರ': 1500, 'ಎರಡುವರೆ ಸಾವಿರ': 2500,
    'ఒకటిన్నర వేయి': 1500, 'రెండున్నర వేలు': 2500
  };

  const PUNCT_REGEX = /^([.,!?;:()"'।—–-]*)(.*?)([.,!?;:()"'।—–-]*)$/;

  function parseNumberSequence(tokens) {
    let total = 0;
    let current = 0;
    for (const tok of tokens) {
      const val = ALL_WORDS[tok];
      if (val === undefined) continue;
      if (val === 100 || val === 1000 || val === 100000 || val === 10000000) {
        if (current === 0) current = 1;
        if (val === 100) {
          current *= 100;
        } else {
          total += current * val;
          current = 0;
        }
      } else if (val >= 100 && val % 100 === 0) {
        current += val;
      } else {
        current += val;
      }
    }
    return total + current;
  }

  function convertIndicNumbersInText(text) {
    if (!text || typeof text !== 'string') return text;

    // 1. Convert script numerals (०-९, ೦-೯, ౦-౯) to 0-9
    let normalized = '';
    for (let k = 0; k < text.length; k++) {
      const ch = text[k];
      normalized += SCRIPT_DIGITS[ch] !== undefined ? SCRIPT_DIGITS[ch] : ch;
    }

    // 2. Multi-word colloquial phrases
    for (const [phrase, val] of Object.entries(MULTI_WORD_COLLOQUIAL)) {
      if (normalized.includes(phrase)) {
        normalized = normalized.split(phrase).join(String(val));
      }
    }

    // 3. Word-by-word tokenization
    const words = normalized.split(/\s+/);
    const newWords = [];
    let i = 0;
    const n = words.length;

    while (i < n) {
      const rawWord = words[i];
      const match = rawWord.match(PUNCT_REGEX);
      const prefix = match ? match[1] : '';
      const cleanWord = match ? match[2] : rawWord;
      const suffix = match ? match[3] : '';
      const cleanLower = cleanWord.toLowerCase();

      if (ALL_WORDS[cleanLower] !== undefined) {
        const numSeq = [cleanLower];
        const origPrefixes = [prefix];
        const origSuffixes = [suffix];
        let j = i + 1;

        while (j < n) {
          const mNext = words[j].match(PUNCT_REGEX);
          const pNext = mNext ? mNext[1] : '';
          const cNext = mNext ? mNext[2] : words[j];
          const sNext = mNext ? mNext[3] : '';

          if (ALL_WORDS[cNext.toLowerCase()] !== undefined) {
            numSeq.push(cNext.toLowerCase());
            origPrefixes.push(pNext);
            origSuffixes.push(sNext);
            j++;
          } else {
            break;
          }
        }

        const numVal = parseNumberSequence(numSeq);
        if (numVal > 0) {
          const finalWord = origPrefixes[0] + numVal + origSuffixes[origSuffixes.length - 1];
          newWords.push(finalWord);
        } else {
          for (let idx = i; idx < j; idx++) {
            newWords.push(words[idx]);
          }
        }
        i = j;
      } else {
        newWords.push(rawWord);
        i++;
      }
    }

    return newWords.join(' ');
  }

  // Expose globally
  window.convertIndicNumbersInText = convertIndicNumbersInText;

})(window);
