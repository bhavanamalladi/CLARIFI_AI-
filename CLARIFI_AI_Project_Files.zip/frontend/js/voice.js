/**
 * CLARIFI AI — Voice Module (voice.js)
 *
 * Handles:
 *  - Mic button click → MediaRecorder → audio chunks
 *  - Canvas audio visualiser via AnalyserNode
 *  - POST audio blob to /api/voice/stt
 *  - Display editable transcript for user confirmation
 *  - Fallback to typed input on STT failure
 *
 * Reads: AppState.currentLanguage (from app.js)
 * Calls: showToast(), showLoading() (from app.js)
 */

'use strict';

// ---------------------------------------------------------------------------
// Module state — Web Audio Direct PCM Recorder & Visualizer
// ---------------------------------------------------------------------------
let isRecording         = false;
let audioContext        = null;
let mediaStream         = null;
let sourceNode          = null;
let scriptProcessorNode = null;
let analyserNode        = null;
let animationId         = null;
let pcmChunks           = [];
let recordTimerId       = null;
let recordStartTime     = 0;
let browserRecognitionTranscript = '';

// ZERO-DOWNLOAD AUDIO STREAMING:
// Pure in-memory direct PCM capture downsampled to 16kHz 16-bit Mono WAV.
// Prevents Chromium's 130MB on-device model download while ensuring 100% genuine WAV for Gnani STT.
function startBrowserSpeechRecognition() {}
function stopBrowserSpeechRecognition() {}

// ---------------------------------------------------------------------------
// Init — called by app.js after DOM ready
// ---------------------------------------------------------------------------
function initVoice() {
  const micBtn          = document.getElementById('mic-btn');
  const confirmBtn      = document.getElementById('btn-confirm');
  const rerecordBtn     = document.getElementById('btn-rerecord');
  const submitTypedBtn  = document.getElementById('btn-submit-typed');

  if (!micBtn) { console.warn('[Voice] #mic-btn not found'); return; }

  // Check browser support
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    showTypedInputOnly('Your browser does not support voice recording. Please type your input.');
    return;
  }

  // Mic button: toggle recording
  micBtn.addEventListener('click', async () => {
    if (!isRecording) {
      await startRecording();
    } else {
      await stopRecording();
    }
  });

  // Confirm transcript → Phase 2: send to parser
  if (confirmBtn) {
    confirmBtn.addEventListener('click', () => {
      const text = document.getElementById('transcript-text')?.value?.trim();
      if (!text) { showToast('Transcript is empty. Please re-record or type.', 'warning'); return; }
      window.AppState.pendingTranscript = text;
      // Phase 2: send to LLM parser → save to DB
      if (typeof parseAndSave === 'function') {
        parseAndSave(text);
        resetRecorder();  // Clear mic UI after sending
      } else {
        showToast('Got it! Transcript confirmed ✓', 'success');
        console.log('[Voice] Confirmed transcript:', text);
      }
    });
  }

  // Re-record
  if (rerecordBtn) {
    rerecordBtn.addEventListener('click', resetRecorder);
  }

  // Submit typed input
  if (submitTypedBtn) {
    submitTypedBtn.addEventListener('click', () => {
      const textarea = document.getElementById('typed-input');
      const text = textarea?.value?.trim();
      if (!text) { showToast('Please type something first.', 'warning'); return; }
      window.AppState.pendingTranscript = text;
      // Phase 2: parse typed input just like voice
      if (typeof parseAndSave === 'function') {
        parseAndSave(text);
        if (textarea) textarea.value = '';
      } else {
        showTranscript(text);
        showToast('Input received ✓', 'success');
      }
    });
  }

  // Enter key on typed input submits
  document.getElementById('typed-input')?.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submitTypedBtn?.click();
    }
  });
}

// ---------------------------------------------------------------------------
// startRecording — Direct Float32 PCM Capture via Web Audio
// ---------------------------------------------------------------------------
async function startRecording() {
  if (isRecording) {
    await stopRecording();
    return;
  }

  // Request mic permission
  try {
    mediaStream = await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
        channelCount: 1,
      },
      video: false
    });
  } catch (err) {
    console.error('[Voice] getUserMedia error:', err);
    if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
      showToast('Microphone access denied. Please allow mic permissions in your browser or type.', 'error', 5000);
    } else {
      showToast('Could not access microphone: ' + (err.message || 'Check audio hardware'), 'error', 5000);
    }
    showTypedInputOnly();
    return;
  }

  try {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (!AudioContextClass) {
      throw new Error('AudioContext not supported in this browser.');
    }

    audioContext = new AudioContextClass();
    if (audioContext.state === 'suspended') {
      await audioContext.resume();
    }

    pcmChunks = [];
    sourceNode = audioContext.createMediaStreamSource(mediaStream);

    // Setup Analyser for real-time visualizer canvas
    analyserNode = audioContext.createAnalyser();
    analyserNode.fftSize = 64;
    sourceNode.connect(analyserNode);

    // Setup ScriptProcessor for zero-loss float32 PCM sampling (4096 buffer, 1 channel)
    scriptProcessorNode = audioContext.createScriptProcessor(4096, 1, 1);
    scriptProcessorNode.onaudioprocess = (e) => {
      if (!isRecording) return;
      const inputBuffer = e.inputBuffer.getChannelData(0);
      pcmChunks.push(new Float32Array(inputBuffer));
    };

    sourceNode.connect(scriptProcessorNode);
    scriptProcessorNode.connect(audioContext.destination);

    isRecording = true;
    recordStartTime = Date.now();
    startRecordTimer();

    // Auto-stop safety after 15 seconds so recording does not run indefinitely
    if (window._autoStopTimer) clearTimeout(window._autoStopTimer);
    window._autoStopTimer = setTimeout(async () => {
      if (isRecording) {
        console.log('[Voice] 15s auto-stop reached, stopping recording and processing');
        await stopRecording();
      }
    }, 15000);

    // Start Visualizer Canvas
    const canvas = document.getElementById('visualizer-canvas');
    if (canvas) drawVisualizer(canvas);

    // Update UI
    setMicState('recording');
    console.log(`[Voice] Audio recording started at sampleRate: ${audioContext.sampleRate} Hz`);
  } catch (err) {
    console.error('[Voice] Recording initialization failed:', err);
    mediaStream?.getTracks().forEach(t => t.stop());
    mediaStream = null;
    showToast('Failed to initialize audio recorder. Please type your query.', 'error');
    setMicState('idle');
  }
}

// ---------------------------------------------------------------------------
// stopRecording — Merge Float32, Downsample to 16kHz, Encode WAV, Send to STT
// ---------------------------------------------------------------------------
async function stopRecording() {
  if (window._autoStopTimer) {
    clearTimeout(window._autoStopTimer);
    window._autoStopTimer = null;
  }
  if (!isRecording) return;
  isRecording = false;
  stopRecordTimer();
  setMicState('processing');

  // Disconnect ScriptProcessor and Source
  try {
    if (scriptProcessorNode) {
      scriptProcessorNode.disconnect();
      scriptProcessorNode.onaudioprocess = null;
      scriptProcessorNode = null;
    }
    if (sourceNode) {
      sourceNode.disconnect();
      sourceNode = null;
    }
  } catch (_) {}

  // Stop visualizer animation
  stopVisualizer();

  // Release microphone tracks immediately
  if (mediaStream) {
    mediaStream.getTracks().forEach(t => t.stop());
    mediaStream = null;
  }

  // Calculate total captured samples
  const totalSamples = pcmChunks.reduce((acc, c) => acc + c.length, 0);
  const inputRate = audioContext ? audioContext.sampleRate : 44100;
  if (audioContext) {
    try { await audioContext.close(); } catch (_) {}
    audioContext = null;
  }

  if (totalSamples === 0 || pcmChunks.length === 0) {
    showToast("No audio detected. Please tap mic and speak clearly.", "warning", 3000);
    setMicState('idle');
    return;
  }

  // Merge all float32 chunks into one contiguous buffer
  const mergedFloat32 = new Float32Array(totalSamples);
  let offset = 0;
  for (const chunk of pcmChunks) {
    mergedFloat32.set(chunk, offset);
    offset += chunk.length;
  }
  pcmChunks = [];

  // Downsample to 16,000 Hz for Gnani Prisma STT
  const downsampled = downsampleBuffer(mergedFloat32, inputRate, 16000);

  // Encode to 16kHz 16-bit Mono WAV with valid 44-byte RIFF header
  const wavBytes = encodeWavPcm16(downsampled, 16000);
  const wavBlob = new Blob([wavBytes], { type: 'audio/wav' });

  showLoading(true, 'Transcribing your speech with Gnani AI…');
  await sendToSTT(wavBlob, 'audio/wav');
}

// ---------------------------------------------------------------------------
// Linear Interpolation Downsampling to 16kHz
// ---------------------------------------------------------------------------
function downsampleBuffer(buffer, inputSampleRate, outputSampleRate) {
  if (inputSampleRate === outputSampleRate) {
    return buffer;
  }
  const ratio = inputSampleRate / outputSampleRate;
  const newLength = Math.round(buffer.length / ratio);
  const result = new Float32Array(newLength);
  let offsetResult = 0;
  let offsetBuffer = 0;
  while (offsetResult < result.length) {
    const nextOffsetBuffer = Math.round((offsetResult + 1) * ratio);
    let accum = 0;
    let count = 0;
    for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
      accum += buffer[i];
      count++;
    }
    result[offsetResult] = count > 0 ? (accum / count) : 0;
    offsetResult++;
    offsetBuffer = nextOffsetBuffer;
  }
  return result;
}

// ---------------------------------------------------------------------------
// 16-Bit Mono PCM WAV Encoder (44-byte standard RIFF header)
// ---------------------------------------------------------------------------
function encodeWavPcm16(samples, sampleRate) {
  const buffer = new ArrayBuffer(44 + samples.length * 2);
  const view = new DataView(buffer);

  function writeStr(offset, str) {
    for (let i = 0; i < str.length; i++) view.setUint8(offset + i, str.charCodeAt(i));
  }

  writeStr(0, 'RIFF');
  view.setUint32(4, 36 + samples.length * 2, true);
  writeStr(8, 'WAVE');
  writeStr(12, 'fmt ');
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM format
  view.setUint16(22, 1, true); // 1 channel (mono)
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, sampleRate * 2, true); // byte rate (sampleRate * 1 channel * 2 bytes/sample)
  view.setUint16(32, 2, true); // block align
  view.setUint16(34, 16, true); // 16-bit
  writeStr(36, 'data');
  view.setUint32(40, samples.length * 2, true);

  let offset = 44;
  for (let i = 0; i < samples.length; i++, offset += 2) {
    const s = Math.max(-1, Math.min(1, samples[i]));
    view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
  }
  return buffer;
}

// ---------------------------------------------------------------------------
// Elapsed Record Timer
// ---------------------------------------------------------------------------
function startRecordTimer() {
  stopRecordTimer();
  recordTimerId = setInterval(() => {
    if (!isRecording) {
      stopRecordTimer();
      return;
    }
    const elapsedSec = Math.floor((Date.now() - recordStartTime) / 1000);
    const mm = String(Math.floor(elapsedSec / 60)).padStart(2, '0');
    const ss = String(elapsedSec % 60).padStart(2, '0');
    const timeStr = `Listening… (${mm}:${ss}) Click Stop when done`;

    const micStatus = document.getElementById('mic-status');
    if (micStatus) micStatus.textContent = timeStr;
    const expMicStatus = document.getElementById('expenses-mic-status');
    if (expMicStatus) expMicStatus.textContent = timeStr;
    const dashMicStatus = document.getElementById('dash-mic-status');
    if (dashMicStatus) dashMicStatus.textContent = timeStr;
  }, 500);
}

function stopRecordTimer() {
  if (recordTimerId) {
    clearInterval(recordTimerId);
    recordTimerId = null;
  }
}

// ---------------------------------------------------------------------------
// sendToSTT
// ---------------------------------------------------------------------------
async function sendToSTT(blob, mimeType) {
  showLoading(true, 'Transcribing your speech with Gnani AI…');

  const isWav = (mimeType && mimeType.includes('wav')) || blob.type === 'audio/wav';
  const filename = isWav ? 'recording.wav' : 'recording.webm';

  const formData = new FormData();
  formData.append('audio', blob, filename);
  formData.append('language_code', window.AppState?.currentLanguage || 'indic-auto');

  try {
    const response = await fetch('/api/voice/stt', {
      method: 'POST',
      body: formData,
    });

    if (!response.ok) {
      throw new Error(`Server error: ${response.status}`);
    }

    const data = await response.json();

    if (data.success && data.transcript) {
      showTranscript(data.transcript, data.detected_language);
    } else if (browserRecognitionTranscript) {
      showTranscript(browserRecognitionTranscript);
      showToast('Transcript captured ✓', 'success', 2000);
    } else {
      const msg = data.error || 'Could not detect clear speech. Please speak into the mic or type below.';
      showToast(msg, 'info', 2500);
      showTypedInputOnly();
      setMicState('idle');
    }

  } catch (err) {
    if (browserRecognitionTranscript) {
      showTranscript(browserRecognitionTranscript);
      showToast('Transcript captured ✓', 'success', 2000);
    } else {
      console.error('[Voice] STT error:', err);
      showToast('Please speak clearly into the microphone or type below.', 'info', 2500);
      showTypedInputOnly();
      setMicState('idle');
    }
  } finally {
    showLoading(false);
  }
}

// ---------------------------------------------------------------------------
// showTranscript — display editable result, hide mic
// ---------------------------------------------------------------------------
function showTranscript(text, detectedLang) {
  const transcriptCard = document.getElementById('transcript-card');
  const transcriptText = document.getElementById('transcript-text');
  const micSection     = document.getElementById('mic-section');

  // Convert native Indic numerals (Devanagari, Kannada, Telugu) and number words to digits
  const normalized = window.convertIndicNumbersInText ? window.convertIndicNumbersInText(text) : text;

  if (transcriptText) transcriptText.value = normalized;
  if (transcriptCard) transcriptCard.classList.add('visible');
  if (micSection)     micSection.style.display = 'none';

  if (detectedLang) {
    console.log('[Voice] Detected language:', detectedLang);
  }

  // If invoked from Expenses Co-Pilot right panel or on expenses page:
  const isExp = document.getElementById('section-expenses')?.classList.contains('active');
  const expInput = document.getElementById('expenses-quick-input');
  if (isExp || window._recordingFromExpenses) {
    if (expInput) expInput.value = normalized;
    window._recordingFromExpenses = false;
    if (typeof parseAndSave === 'function') {
      parseAndSave(normalized);
    }
  }

  // If invoked from Dashboard Co-Pilot right panel or on dashboard page:
  const isDash = document.getElementById('section-dashboard')?.classList.contains('active');
  const dashInput = document.getElementById('dash-quick-input');
  if (isDash || window._recordingFromDashboard) {
    if (dashInput) dashInput.value = normalized;
    window._recordingFromDashboard = false;
    if (typeof parseAndSave === 'function') {
      parseAndSave(normalized);
    }
  }

  setMicState('idle');
}

// ---------------------------------------------------------------------------
// resetRecorder — go back to mic
// ---------------------------------------------------------------------------
function resetRecorder() {
  audioChunks     = [];
  mediaRecorder   = null;
  isRecording     = false;

  // Hide transcript, show mic
  document.getElementById('transcript-card')?.classList.remove('visible');
  document.getElementById('mic-section')?.style.removeProperty('display');
  document.getElementById('transcript-text') && (document.getElementById('transcript-text').value = '');
  document.getElementById('typed-input') && (document.getElementById('typed-input').value = '');

  // Hide "type or" section's forced-only mode
  document.getElementById('typed-input-wrap')?.classList.remove('forced');

  window.AppState.pendingTranscript = null;
  setMicState('idle');
}

// ---------------------------------------------------------------------------
// showTypedInputOnly — called on mic permission denied or repeated STT fail
// ---------------------------------------------------------------------------
function showTypedInputOnly(message) {
  document.getElementById('transcript-card')?.classList.remove('visible');
  if (message) {
    const hint = document.getElementById('typed-input-hint');
    if (hint) {
      hint.textContent = message;
      hint.style.color = 'var(--color-warning)';
      hint.style.fontWeight = '600';
    }
  }
  // Keep mic accessible and scroll gently into view
  document.getElementById('typed-input')?.focus();
}

// ---------------------------------------------------------------------------
// setMicState — update mic button + status text
// ---------------------------------------------------------------------------
function setMicState(state) {
  const currentLang = window.AppState?.currentLanguage || 'en-IN';
  const dict = (window.TRANSLATIONS && window.TRANSLATIONS[currentLang]) || {};

  const startLabel = dict['mic_btn_start'] || 'Start Speaking';
  const stopLabel = dict['mic_btn_stop'] || 'Stop & Process';
  const procLabel = 'Processing…';

  const micBtn    = document.getElementById('mic-btn');
  const micStatus = document.getElementById('mic-status');

  if (micBtn) {
    if (state === 'recording') {
      micBtn.innerHTML = `<span class="mic-icon">⏹️</span> <span class="mic-btn-label">${stopLabel}</span>`;
      micBtn.className = 'mic-btn recording';
    } else if (state === 'processing') {
      micBtn.innerHTML = `<span class="mic-icon">⏳</span> <span class="mic-btn-label">${procLabel}</span>`;
      micBtn.className = 'mic-btn processing';
    } else {
      micBtn.innerHTML = `<span class="mic-icon">🎙️</span> <span class="mic-btn-label">${startLabel}</span>`;
      micBtn.className = 'mic-btn';
    }
  }

  // Update status pills across panels
  document.querySelectorAll('.assistant-status-pill').forEach(pill => {
    if (state === 'recording') {
      pill.textContent = '🔴 Live Recording';
      pill.className = 'assistant-status-pill recording';
    } else if (state === 'processing') {
      pill.textContent = '⏳ Processing…';
      pill.className = 'assistant-status-pill processing';
    } else {
      pill.textContent = dict['dash_copilot_status'] || 'Standby • Ready';
      pill.className = 'assistant-status-pill';
    }
  });

  // Helper for side action mic buttons
  function updateSideMicBtn(btnId, statusId) {
    const btn = document.getElementById(btnId);
    const status = document.getElementById(statusId);
    if (btn) {
      if (state === 'recording') {
        btn.innerHTML = `<span class="mic-icon">⏹️</span> <span class="mic-btn-label">${stopLabel}</span>`;
        btn.className = 'mic-btn-action recording';
        btn.setAttribute('title', 'Click to stop and process speech');
        if (status) status.textContent = 'Listening… Click "Stop & Process" when done';
      } else if (state === 'processing') {
        btn.innerHTML = `<span class="mic-icon">⏳</span> <span class="mic-btn-label">${procLabel}</span>`;
        btn.className = 'mic-btn-action processing';
        btn.setAttribute('title', 'Processing speech…');
        if (status) status.textContent = 'Transcribing your speech with Gnani AI…';
      } else {
        btn.innerHTML = `<span class="mic-icon">🎙️</span> <span class="mic-btn-label">${startLabel}</span>`;
        btn.className = 'mic-btn-action';
        btn.setAttribute('title', 'Click to start speaking');
        if (status) status.textContent = dict['dash_mic_tap'] || 'Click "Start Speaking" (Auto-detects language)';
      }
    }
  }

  updateSideMicBtn('dash-btn-mic', 'dash-mic-status');
  updateSideMicBtn('expenses-mic-btn', 'expenses-mic-status');
}

// ---------------------------------------------------------------------------
// Audio Visualiser — canvas frequency bars
// ---------------------------------------------------------------------------
function setupVisualizer(stream) {
  const canvas = document.getElementById('visualizer-canvas');
  if (!canvas) return;

  try {
    audioContext = new (window.AudioContext || window.webkitAudioContext)();
    const source = audioContext.createMediaStreamSource(stream);
    analyserNode = audioContext.createAnalyser();
    analyserNode.fftSize = 64;
    source.connect(analyserNode);
    drawVisualizer(canvas);
  } catch (err) {
    console.warn('[Voice] Visualizer setup failed:', err);
  }
}

function drawVisualizer(canvas) {
  if (!analyserNode) return;

  const ctx    = canvas.getContext('2d');
  const W      = canvas.width  = canvas.offsetWidth  || 240;
  const H      = canvas.height = canvas.offsetHeight || 56;
  const bufLen = analyserNode.frequencyBinCount;
  const data   = new Uint8Array(bufLen);
  const barW   = Math.max(2, (W / bufLen) * 1.5);

  function frame() {
    if (!analyserNode) return;
    animationId = requestAnimationFrame(frame);
    analyserNode.getByteFrequencyData(data);

    ctx.clearRect(0, 0, W, H);
    ctx.fillStyle = 'rgba(13,13,26,0.6)';
    ctx.fillRect(0, 0, W, H);

    let x = 0;
    for (let i = 0; i < bufLen; i++) {
      const barH = (data[i] / 255) * H;
      // Gradient bar: saffron at top, dimmer at bottom
      const alpha = 0.4 + (data[i] / 255) * 0.6;
      ctx.fillStyle = `rgba(255,107,53,${alpha})`;
      ctx.fillRect(x, H - barH, barW - 1, barH);
      x += barW;
    }
  }

  frame();
}

function stopVisualizer() {
  if (animationId) { cancelAnimationFrame(animationId); animationId = null; }
  analyserNode = null;

  // Clear canvas
  const canvas = document.getElementById('visualizer-canvas');
  if (canvas) {
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
}

// ---------------------------------------------------------------------------
// Expose for app.js and Expenses Co-Pilot
// ---------------------------------------------------------------------------
window.initVoice      = initVoice;
window.resetRecorder  = resetRecorder;
window.startRecording = startRecording;
window.stopRecording  = stopRecording;
window.isRecording    = () => isRecording;

// Phase 6: speak the transcript text back to the user via TTS
window.speakTranscript = function() {
  const text = document.getElementById('transcript-text')?.value?.trim();
  const btn  = document.getElementById('btn-listen-transcript');
  if (!text) { showToast('Nothing to speak yet.', 'warning'); return; }
  if (typeof window.speakText === 'function') {
    window.speakText(text, window.AppState?.currentLanguage || 'en-IN', btn);
  } else {
    showToast('Audio not ready yet.', 'info');
  }
};
