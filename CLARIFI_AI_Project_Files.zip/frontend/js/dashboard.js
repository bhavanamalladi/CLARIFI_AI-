/**
 * CLARIFI AI — Dashboard Module  (Phase 3)
 *
 * Renders:
 *  - Summary cards: income, expenses, savings, savings rate
 *  - Donut chart: category breakdown (pure Canvas, no libraries)
 *  - EMI obligations card
 *  - Emergency fund progress bar + adjustable target
 *  - Month navigation (prev / next month)
 *
 * Data source: GET /api/dashboard?month=&year=
 * All numbers are computed server-side — this file only renders.
 */

'use strict';

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
const DashState = {
  month: new Date().getMonth() + 1,
  year:  new Date().getFullYear(),
  data:  null,
};

// Category colours (consistent with expenses.js icons)
const CAT_COLORS = {
  rent:      '#6366f1',
  food:      '#f59e0b',
  transport: '#22d3ee',
  shopping:  '#ec4899',
  bills:     '#a3e635',
  EMI:       '#ef4444',
  other:     '#8888aa',
  income:    '#22c55e',
};

// ---------------------------------------------------------------------------
// Init — called by app.js when Dashboard tab is first opened
// ---------------------------------------------------------------------------
let _dashBound = false;

function initDashboard() {
  if (!_dashBound) {
    _dashBound = true;
    bindMonthNav();
    bindEFTargetForm();
    bindDashQuickWidget();
  }
  loadDashboard();
}

// ---------------------------------------------------------------------------
// Load data from API and render
// ---------------------------------------------------------------------------
async function loadDashboard() {
  showDashLoading(true);
  try {
    const res = await fetch(`/api/dashboard?month=${DashState.month}&year=${DashState.year}`, {
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (!res.ok) throw new Error(res.status);
    DashState.data = await res.json();
    renderDashboard(DashState.data);
  } catch (err) {
    console.error('[Dashboard] load error:', err);
    showToast('Could not load dashboard data.', 'error');
  } finally {
    showDashLoading(false);
  }
}

// ---------------------------------------------------------------------------
// Render everything
// ---------------------------------------------------------------------------
function renderDashboard(d) {
  if (!d) return;
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const dict = window.TRANSLATIONS?.[lang] || window.TRANSLATIONS?.['en-IN'] || {};

  // Personalized greeting
  const nameEl = document.getElementById('dash-user-name');
  if (nameEl) {
    nameEl.textContent = (window.AuthState?.user?.name)
      ? window.AuthState.user.name.trim().split(' ')[0]
      : 'Friend';
  }

  // Localized Month label
  const monthNames = {
    'en-IN': ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    'hi-IN': ['जनवरी', 'फ़रवरी', 'मार्च', 'अप्रैल', 'मई', 'जून', 'जुलाई', 'अगस्त', 'सितंबर', 'अक्टूबर', 'नवंबर', 'दिसंबर'],
    'kn-IN': ['ಜನವರಿ', 'ಫೆಬ್ರವರಿ', 'ಮಾರ್ಚ್', 'ಏಪ್ರಿಲ್', 'ಮೇ', 'ಜೂನ್', 'ಜುಲೈ', 'ಆಗಸ್ಟ್', 'ಸೆಪ್ಟೆಂಬರ್', 'ಅಕ್ಟೋಬರ್', 'ನವೆಂಬರ್', 'ಡಿಸೆಂಬರ್'],
    'te-IN': ['జనవరి', 'ఫిబ్రవరి', 'మార్చి', 'ఏప్రిల్', 'మే', 'జూన్', 'జూలై', 'ఆగస్టు', 'సెప్టెంబర్', 'అక్టోబర్', 'నవంబర్', 'డిసెంబర్']
  };
  const localizedMonth = (monthNames[lang] && DashState.month >= 1 && DashState.month <= 12)
    ? `${monthNames[lang][DashState.month - 1]} ${DashState.year}`
    : d.month;
  setEl('dash-month-label', localizedMonth);

  // Summary cards
  setEl('dash-income',      fmtRupee(d.monthly_income));
  setEl('dash-expenses',    fmtRupee(d.total_expenses));
  setEl('dash-savings',     fmtRupee(d.savings));
  setEl('dash-savings-rate', `${d.savings_rate}%`);

  // Cache user's actual savings for Schemes "According to My Savings" calculator
  if (d.savings > 0) {
    if (!window.AppState) window.AppState = {};
    window.AppState.userMonthlySavings = d.savings;
    try { localStorage.setItem('clarifi_calc_savings', String(d.savings)); } catch (_) {}
    if (typeof window.renderSchemesGrid === 'function') {
      window.renderSchemesGrid();
    }
  }

  // Colour-code savings
  const savingsEl = document.getElementById('dash-savings');
  if (savingsEl) {
    savingsEl.style.color = d.savings >= 0
      ? 'var(--color-success)'
      : 'var(--color-danger)';
  }

  // Savings rate colour + badge
  const rateEl = document.getElementById('dash-savings-rate');
  if (rateEl) {
    rateEl.style.color = d.savings_rate >= 20
      ? 'var(--color-success)'
      : d.savings_rate >= 10
        ? 'var(--color-warning)'
        : 'var(--color-danger)';
  }

  // Category donut chart
  renderDonut(d.category_breakdown, d.total_expenses);

  // Category legend list
  renderCategoryLegend(d.category_breakdown);

  // EMI card with native translations
  setEl('dash-emi',  fmtRupee(d.emi_obligations));
  const emiNote = document.getElementById('dash-emi-note');
  if (emiNote) {
    const pct = d.monthly_income > 0
      ? Math.round(d.emi_obligations / d.monthly_income * 100)
      : 0;

    const emiTexts = {
      'en-IN': {
        active: `${pct}% of your income — keep EMIs below 40% for financial health.`,
        none: 'No EMIs recorded this month.'
      },
      'hi-IN': {
        active: `आपकी आय का ${pct}% — वित्तीय सुरक्षा के लिए ईएमआई 40% से कम रखें।`,
        none: 'इस महीने कोई ईएमआई दर्ज नहीं है।'
      },
      'kn-IN': {
        active: `ನಿಮ್ಮ ಆದಾಯದ ${pct}% — ಆರ್ಥಿಕ ಕ್ಷೇಮಕ್ಕಾಗಿ ಇಎಂಐ 40% ಕ್ಕಿಂತ ಕಡಿಮೆ ಇರಿಸಿ.`,
        none: 'ಈ ತಿಂಗಳು ಯಾವುದೇ ಇಎಂಐ ಇಲ್ಲ.'
      },
      'te-IN': {
        active: `మీ ఆదాయంలో ${pct}% — ఆర్థిక భద్రత కోసం EMIలను 40% కంటే తక్కువగా ఉంచండి.`,
        none: 'ఈ నెలలో ఎలాంటి EMIలు నమోదు కాలేదు.'
      }
    };
    const t = emiTexts[lang] || emiTexts['en-IN'];
    emiNote.textContent = pct > 0 ? t.active : t.none;
    emiNote.style.color = pct > 40
      ? 'var(--color-danger)'
      : pct > 25
        ? 'var(--color-warning)'
        : 'var(--color-text-muted)';
  }

  // Emergency fund
  renderEmergencyFund(d);

  // Active goals spotlight & recent transactions preview
  loadDashGoalsPreview();
  loadDashRecentPreview();
}

// ---------------------------------------------------------------------------
// Donut chart — pure Canvas
// ---------------------------------------------------------------------------
function renderDonut(breakdown, totalExpenses) {
  const canvas = document.getElementById('donut-canvas');
  if (!canvas) return;

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const ctx = canvas.getContext('2d');
  const DPR = window.devicePixelRatio || 1;
  const SIZE = 200;
  canvas.width  = SIZE * DPR;
  canvas.height = SIZE * DPR;
  canvas.style.width  = SIZE + 'px';
  canvas.style.height = SIZE + 'px';
  ctx.scale(DPR, DPR);

  const cx = SIZE / 2, cy = SIZE / 2;
  const outerR = 80, innerR = 50;

  ctx.clearRect(0, 0, SIZE, SIZE);

  if (!breakdown || breakdown.length === 0 || totalExpenses === 0) {
    // Empty state circle
    ctx.beginPath();
    ctx.arc(cx, cy, outerR, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.05)';
    ctx.fill();
    ctx.font = '0.75rem system-ui';
    ctx.fillStyle = 'rgba(255,255,255,0.4)';
    ctx.textAlign = 'center';

    const noExpLabels = {
      'en-IN': ['No expenses', 'this month'],
      'hi-IN': ['कोई खर्च नहीं', 'इस महीने'],
      'kn-IN': ['ಯಾವುದೇ ಖರ್ಚಿಲ್ಲ', 'ಈ ತಿಂಗಳು'],
      'te-IN': ['ఖర్చులు లేవు', 'ఈ నెల']
    };
    const lines = noExpLabels[lang] || noExpLabels['en-IN'];
    ctx.fillText(lines[0], cx, cy - 6);
    ctx.fillText(lines[1], cx, cy + 10);
    return;
  }

  // Draw arcs
  let startAngle = -Math.PI / 2;
  breakdown.forEach(cat => {
    const slice = (cat.total / totalExpenses) * Math.PI * 2;
    const color = CAT_COLORS[cat.category] || CAT_COLORS.other;

    ctx.beginPath();
    ctx.moveTo(cx, cy);
    ctx.arc(cx, cy, outerR, startAngle, startAngle + slice);
    ctx.closePath();
    ctx.fillStyle = color;
    ctx.fill();

    // Small gap between slices
    startAngle += slice + 0.015;
  });

  // Punch inner hole (donut effect)
  ctx.beginPath();
  ctx.arc(cx, cy, innerR, 0, Math.PI * 2);
  ctx.fillStyle = 'var(--color-bg, #080c14)';
  ctx.fill();

  // Centre label (Localized)
  const spentLabels = {
    'en-IN': 'Spent',
    'hi-IN': 'कुल खर्च',
    'kn-IN': 'ಖರ್ಚು',
    'te-IN': 'ఖర్చు'
  };
  ctx.textAlign = 'center';
  ctx.font = `600 13px system-ui`;
  ctx.fillStyle = 'rgba(255,255,255,0.85)';
  ctx.fillText(spentLabels[lang] || 'Spent', cx, cy - 4);
  ctx.font = `bold 13px system-ui`;
  ctx.fillStyle = '#f8fafc';
  ctx.fillText(fmtRupeeShort(totalExpenses), cx, cy + 14);
}

// ---------------------------------------------------------------------------
// Category legend (below donut)
// ---------------------------------------------------------------------------
function renderCategoryLegend(breakdown) {
  const el = document.getElementById('cat-legend');
  if (!el) return;

  if (!breakdown || breakdown.length === 0) {
    el.innerHTML = '<p class="dash-empty-note">Add expenses to see the breakdown.</p>';
    return;
  }

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const dict = window.TRANSLATIONS?.[lang] || window.TRANSLATIONS?.['en-IN'] || {};
  const catNames = {
    food: dict['cat_food'] || '🍛 Food',
    rent: dict['cat_rent'] || '🏠 Rent',
    transport: dict['cat_transport'] || '🚌 Transport',
    shopping: dict['cat_shopping'] || '🛍️ Shopping',
    bills: dict['cat_bills'] || '💡 Bills',
    EMI: dict['cat_emi'] || '🏦 EMI',
    other: dict['cat_other'] || '📦 Other',
  };

  el.innerHTML = breakdown.map(cat => `
    <div class="legend-row">
      <span class="legend-dot" style="background:${CAT_COLORS[cat.category] || CAT_COLORS.other}"></span>
      <span class="legend-name">${catNames[cat.category] || capitalize(cat.category)}</span>
      <span class="legend-pct">${cat.percentage}%</span>
      <span class="legend-amt">${fmtRupee(cat.total)}</span>
    </div>`).join('');
}

// ---------------------------------------------------------------------------
// Emergency Fund
// ---------------------------------------------------------------------------
function renderEmergencyFund(d) {
  const pct   = Math.min(d.emergency_fund_progress_pct, 100);
  const bar   = document.getElementById('ef-bar-fill');
  const label = document.getElementById('ef-status-label');
  const saved = document.getElementById('ef-saved');
  const target= document.getElementById('ef-target');
  const mos   = document.getElementById('ef-months-target');

  if (bar) {
    bar.style.width = pct + '%';
    bar.style.background = pct >= 100
      ? 'var(--color-success)'
      : pct >= 50
        ? 'var(--color-warning)'
        : 'var(--color-accent)';
  }

  const lang = window.AppState?.currentLanguage || 'en-IN';
  if (label) {
    const efTexts = {
      'en-IN': {
        done: '🎉 Emergency fund complete!',
        progress: `${pct.toFixed(1)}% — keep going!`
      },
      'hi-IN': {
        done: '🎉 आपातकालीन निधि पूरी हो गई!',
        progress: `${pct.toFixed(1)}% — आगे बढ़ते रहें!`
      },
      'kn-IN': {
        done: '🎉 ತುರ್ತು ನಿಧಿ ಪೂರ್ಣಗೊಂಡಿದೆ!',
        progress: `${pct.toFixed(1)}% — ಉಳಿತಾಯ ಮುಂದುವರಿಸಿ!`
      },
      'te-IN': {
        done: '🎉 అత్యవసర నిధి పూర్తయింది!',
        progress: `${pct.toFixed(1)}% — కొనసాగించండి!`
      }
    };
    const et = efTexts[lang] || efTexts['en-IN'];
    if (pct >= 100) {
      label.textContent = et.done;
      label.style.color = 'var(--color-success)';
    } else {
      label.textContent = et.progress;
      label.style.color = 'var(--color-text-muted)';
    }
  }

  if (saved)   saved.textContent   = fmtRupee(d.emergency_fund_saved);
  if (target)  target.textContent  = fmtRupee(d.emergency_fund_target_amount);
  if (mos)     mos.textContent     = d.emergency_fund_target_months;

  // Seed the month-target input with current value
  const input = document.getElementById('ef-months-input');
  if (input) input.value = d.emergency_fund_target_months;
}

// ---------------------------------------------------------------------------
// Emergency fund target form
// ---------------------------------------------------------------------------
function bindEFTargetForm() {
  const form = document.getElementById('ef-form');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const months = parseInt(document.getElementById('ef-months-input').value);
    if (!months || months < 1 || months > 24) {
      showToast('Enter a value between 1 and 24 months', 'warning');
      return;
    }
    try {
      const res = await fetch('/api/emergency-fund', {
        method: 'PUT',
        headers: (window.getAuthHeaders ? window.getAuthHeaders({ 'Content-Type': 'application/json' }) : { 'Content-Type': 'application/json' }),
        body: JSON.stringify({ months_target: months }),
      });
      if (!res.ok) throw new Error(res.status);
      showToast(`Emergency fund target updated to ${months} months ✓`, 'success');
      loadDashboard();
    } catch (err) {
      showToast('Could not update target.', 'error');
    }
  });
}

// ---------------------------------------------------------------------------
// Month navigation
// ---------------------------------------------------------------------------
let _monthNavBound = false;

function bindMonthNav() {
  if (_monthNavBound) return;
  _monthNavBound = true;

  document.getElementById('btn-prev-month')?.addEventListener('click', () => {
    DashState.month--;
    if (DashState.month < 1) { DashState.month = 12; DashState.year--; }
    loadDashboard();
  });
  document.getElementById('btn-next-month')?.addEventListener('click', () => {
    const now = new Date();
    // Don't navigate into the future
    if (DashState.year === now.getFullYear() && DashState.month === now.getMonth() + 1) return;
    DashState.month++;
    if (DashState.month > 12) { DashState.month = 1; DashState.year++; }
    loadDashboard();
  });
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function setEl(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function fmtRupee(n) {
  if (n == null) return '₹0';
  return '₹' + Math.abs(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
}

function fmtRupeeShort(n) {
  if (n >= 100000) return '₹' + (n / 100000).toFixed(1) + 'L';
  if (n >= 1000)   return '₹' + (n / 1000).toFixed(1) + 'K';
  return '₹' + Math.round(n);
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : '';
}

function showDashLoading(on) {
  const el = document.getElementById('dash-loading');
  if (el) el.style.display = on ? 'flex' : 'none';
}

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ---------------------------------------------------------------------------
// Dashboard Quick Assistant Widget (Voice & Text)
// ---------------------------------------------------------------------------
function bindDashQuickWidget() {
  const form = document.getElementById('dash-quick-form');
  const input = document.getElementById('dash-quick-input');
  const btnSend = document.getElementById('dash-btn-send');
  const btnMic = document.getElementById('dash-btn-mic');
  const chips = document.querySelectorAll('.dash-quick-chips .chip-btn');

  const executeQuick = (query) => {
    const q = (query || input?.value || '').trim();
    if (!q) {
      if (typeof window.showToast === 'function') {
        window.showToast('Please type or speak an expense, goal, or scheme question.', 'info');
      }
      return;
    }
    if (typeof window.parseAndSave === 'function') {
      window.parseAndSave(q);
      if (input) input.value = '';
    }
  };

  form?.addEventListener('submit', (e) => {
    e.preventDefault();
    executeQuick();
  });
  btnSend?.addEventListener('click', (e) => {
    e.preventDefault();
    executeQuick();
  });
  input?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      executeQuick();
    }
  });

  // Direct In-Place Voice Recording on Dashboard
  btnMic?.addEventListener('click', async () => {
    if (typeof window.isRecording === 'function' && window.isRecording()) {
      if (typeof window.stopRecording === 'function') window.stopRecording();
    } else {
      window._recordingFromDashboard = true;
      if (typeof window.startRecording === 'function') {
        await window.startRecording();
      } else {
        showToast('Voice service is loading…', 'info');
      }
    }
  });

  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      const q = chip.dataset.query;
      if (input) input.value = q;
      executeQuick(q);
    });
  });

  // Mobile Screen View Toggle (<900px)
  document.querySelectorAll('.btn-dash-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.btn-dash-toggle').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const pane = btn.dataset.pane;
      const mainPanel = document.getElementById('dashboard-main-panel');
      const assistantPanel = document.getElementById('dashboard-assistant-panel');
      if (pane === 'snapshot') {
        mainPanel?.classList.remove('mobile-hide');
        assistantPanel?.classList.add('mobile-hide');
      } else {
        assistantPanel?.classList.remove('mobile-hide');
        mainPanel?.classList.add('mobile-hide');
      }
    });
  });
}

// ---------------------------------------------------------------------------
// Active Goals Spotlight (Real-time preview on Dashboard)
// ---------------------------------------------------------------------------
async function loadDashGoalsPreview() {
  const container = document.getElementById('dash-goals-list');
  if (!container) return;

  try {
    const res = await fetch('/api/goals', {
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (!res.ok) throw new Error(res.status);
    const goals = await res.json();

    if (!goals || goals.length === 0) {
      const emptyNote = (window.t ? window.t('goals_empty_title', 'No goals set yet.') : 'No goals set yet.');
      const carBtn = (window.t ? window.t('dash_chip_car', '🚗 I want to buy a car') : '🚗 I want to buy a car');
      container.innerHTML = `
        <div class="dash-empty-box">
          <p class="dash-empty-note">🎯 ${escHtml(emptyNote)}</p>
          <button type="button" class="btn btn-secondary btn-sm" onclick="window.parseAndSave('i want to buy a car')">
            ${escHtml(carBtn)}
          </button>
        </div>
      `;
      return;
    }

    const goalIcons = {
      car: '🚗', vehicle: '🚗', bike: '🏍️', motorcycle: '🏍️',
      laptop: '💻', computer: '💻', phone: '📱', mobile: '📱',
      house: '🏠', home: '🏠', flat: '🏠', emergency: '🛡️',
      vacation: '✈️', trip: '✈️', wedding: '💍', marriage: '💍',
      education: '🎓', college: '🎓'
    };

    const monthsLabel = (window.t ? window.t('dash_ef_months', 'Months') : 'Months');

    container.innerHTML = goals.slice(0, 3).map(g => {
      const nameLower = (g.name || '').toLowerCase();
      let icon = '🎯';
      for (const [k, ic] of Object.entries(goalIcons)) {
        if (nameLower.includes(k)) { icon = ic; break; }
      }
      const monthly = Math.round(g.target_amount / Math.max(1, g.months));
      return `
        <div class="dash-preview-item" onclick="window.showSection('goals')" title="View in Goals Dashboard">
          <div class="dash-item-left">
            <span class="dash-item-icon">${icon}</span>
            <div>
              <div class="dash-item-title">${escHtml(g.name)}</div>
              <div class="dash-item-sub">${g.months} ${monthsLabel} • ~₹${monthly.toLocaleString('en-IN')}/mo</div>
            </div>
          </div>
          <div class="dash-item-right">
            <span class="dash-item-amount gold-text">₹${Number(g.target_amount).toLocaleString('en-IN')}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    console.warn('[Dashboard] loadDashGoalsPreview error:', err);
    container.innerHTML = '<p class="dash-empty-note">Could not load goals preview.</p>';
  }
}

// ---------------------------------------------------------------------------
// Recent Transactions Preview (Real-time preview on Dashboard)
// ---------------------------------------------------------------------------
async function loadDashRecentPreview() {
  const container = document.getElementById('dash-recent-list');
  if (!container) return;

  try {
    const res = await fetch('/api/transactions?limit=4', {
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (!res.ok) throw new Error(res.status);
    const txs = await res.json();

    if (!txs || txs.length === 0) {
      const emptyTx = (window.t ? window.t('tx_empty_title', 'No transactions recorded this month yet.') : 'No transactions recorded this month yet.');
      container.innerHTML = `
        <div class="dash-empty-box">
          <p class="dash-empty-note">💸 ${escHtml(emptyTx)}</p>
          <button type="button" class="btn btn-secondary btn-sm" onclick="window.showSection('expenses')">
            + Add Expense
          </button>
        </div>
      `;
      return;
    }

    const catIcons = {
      rent: '🏠', food: '🍛', transport: '🚗', shopping: '🛍️',
      bills: '💡', EMI: '🏦', other: '🏷️', salary: '💰', freelance: '💻'
    };

    container.innerHTML = txs.slice(0, 4).map(t => {
      const isIncome = t.type === 'income';
      const icon = isIncome ? '💰' : (catIcons[t.category] || '💸');
      const sign = isIncome ? '+' : '-';
      const colorClass = isIncome ? 'amt-income' : 'amt-expense';
      const dateStr = t.date ? new Date(t.date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' }) : '';
      const desc = t.description || (isIncome ? 'Income' : capitalize(t.category || 'Expense'));

      return `
        <div class="dash-preview-item" onclick="window.showSection('expenses')" title="View in Expenses Dashboard">
          <div class="dash-item-left">
            <span class="dash-item-icon">${icon}</span>
            <div>
              <div class="dash-item-title">${escHtml(desc)}</div>
              <div class="dash-item-sub">${capitalize(t.category || t.type)} • ${dateStr}</div>
            </div>
          </div>
          <div class="dash-item-right">
            <span class="dash-item-amount ${colorClass}">${sign}₹${Number(t.amount).toLocaleString('en-IN')}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    console.warn('[Dashboard] loadDashRecentPreview error:', err);
    container.innerHTML = '<p class="dash-empty-note">Could not load transactions preview.</p>';
  }
}

// ---------------------------------------------------------------------------
// Expose
// ---------------------------------------------------------------------------
window.DashState             = DashState;
window.initDashboard         = initDashboard;
window.loadDashboard         = loadDashboard;
window.renderDashboard       = renderDashboard;
window.loadDashGoalsPreview  = loadDashGoalsPreview;
window.loadDashRecentPreview = loadDashRecentPreview;
