/**
 * CLARIFI AI — TTS + Language Module  (Phase 6)
 *
 * Provides:
 *  - window.speakText(text, language)  — calls /api/voice/tts, plays WAV
 *  - Audio cache (in-memory Map) to avoid duplicate fetches
 *  - Loading state on Listen buttons while audio fetches
 *  - Graceful fallback: if TTS returns 503 or errors, shows toast "Audio unavailable"
 *  - Language change propagates to: STT language_code, LLM language, TTS language
 *
 * All Listen buttons across the app call window.speakText().
 * Defined in: learn.js (listenToExplain), goals.js (listenToPlan),
 *             dashboard.js (future), voice.js (spoken feedback)
 */

'use strict';

// ---------------------------------------------------------------------------
// In-memory audio cache  Map<cacheKey, AudioBuffer | 'error'>
// ---------------------------------------------------------------------------
const _audioCache = new Map();

// Currently playing AudioBufferSourceNode (stop before playing new)
let _currentSource = null;
let _audioCtx      = null;
let _loadedVoices  = [];

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  _loadedVoices = window.speechSynthesis.getVoices();
  window.speechSynthesis.onvoiceschanged = () => {
    _loadedVoices = window.speechSynthesis.getVoices();
  };
}

// ---------------------------------------------------------------------------
// Main: speakText — called from any Listen button
// ---------------------------------------------------------------------------
/**
 * Fetch audio from /api/voice/tts and play it.
 * Falls back to toast notification if TTS fails.
 *
 * @param {string} text      - Text to speak (max 2000 chars)
 * @param {string} language  - Language code (en-IN / hi-IN / kn-IN / te-IN)
 * @param {HTMLElement} [btn]- Optional button element to show loading state
 */
async function speakText(text, language, btn) {
  if (!text || !text.trim()) return;

  // Stop any currently playing audio
  _stopCurrent();

  const lang     = language || window.AppState?.currentLanguage || 'en-IN';
  const cacheKey = `${lang}:${text.trim().slice(0, 200)}`;

  // Set button loading state
  _setBtnState(btn, 'loading');

  try {
    // --- Memory cache hit ---
    if (_audioCache.has(cacheKey)) {
      const cached = _audioCache.get(cacheKey);
      if (cached === 'error') {
        showToast('Audio unavailable — text shown above.', 'info', 3000);
        _setBtnState(btn, 'idle');
        return;
      }
      await _playBuffer(cached, btn);
      return;
    }

    // --- Fetch from backend ---
    const res = await fetch('/api/voice/tts', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ text: text.trim().slice(0, 2000), language: lang }),
    });

    if (!res.ok) {
      // Gnani service unavailable or no key — use browser speech synthesis as graceful fallback
      console.info('[TTS] Backend TTS returned', res.status, '— falling back to Web Speech API');
      _speakWithBrowserSpeech(text, lang, btn);
      return;
    }

    // --- Decode WAV ---
    const arrayBuf = await res.arrayBuffer();
    if (!arrayBuf || arrayBuf.byteLength === 0) {
      _speakWithBrowserSpeech(text, lang, btn);
      return;
    }

    // Decode into AudioBuffer via WebAudio
    const audioCtx = _getAudioContext();
    const decoded  = await audioCtx.decodeAudioData(arrayBuf);

    // Store in memory cache
    _audioCache.set(cacheKey, decoded);

    await _playBuffer(decoded, btn);

  } catch (err) {
    console.warn('[TTS] Backend error, falling back to Web Speech API:', err);
    _speakWithBrowserSpeech(text, lang, btn);
  }
}

// ---------------------------------------------------------------------------
// Fallback: Web Speech API (ensures user can ALWAYS listen to plans)
// ---------------------------------------------------------------------------
function _speakWithBrowserSpeech(text, lang, btn) {
  if (!('speechSynthesis' in window)) {
    showToast('Audio playback not supported in this browser.', 'info', 2000);
    _setBtnState(btn, 'idle');
    return;
  }
  try {
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[#*_`]/g, '').trim();
    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = lang || 'en-IN';
    utterance.rate = 0.95;

    // Pick appropriate voice matching language if available
    const voices = _loadedVoices.length ? _loadedVoices : window.speechSynthesis.getVoices();
    const prefix = (lang || 'en').split('-')[0].toLowerCase();
    const match = voices.find(v => v.lang && (v.lang.toLowerCase().startsWith(prefix) || v.lang.replace('_', '-').toLowerCase().startsWith(prefix)));
    if (match) utterance.voice = match;

    _setBtnState(btn, 'playing');

    if (btn) {
      btn.onclick = (e) => {
        if (e) e.stopPropagation();
        window.speechSynthesis.cancel();
        _setBtnState(btn, 'idle');
      };
    }

    utterance.onend = () => _setBtnState(btn, 'idle');
    utterance.onerror = () => _setBtnState(btn, 'idle');

    window.speechSynthesis.speak(utterance);
    showToast('🔊 Playing audio...', 'info', 2000);
  } catch (e) {
    console.error('[TTS] Web Speech fallback failed:', e);
    _setBtnState(btn, 'idle');
  }
}

// ---------------------------------------------------------------------------
// Play a decoded AudioBuffer
// ---------------------------------------------------------------------------
async function _playBuffer(buffer, btn) {
  _stopCurrent();

  const ctx    = _getAudioContext();
  const source = ctx.createBufferSource();
  source.buffer = buffer;
  source.connect(ctx.destination);

  _currentSource = source;
  _setBtnState(btn, 'playing');

  source.start(0);

  // When audio ends, reset button state
  source.onended = () => {
    _currentSource = null;
    _setBtnState(btn, 'idle');
  };
}

// ---------------------------------------------------------------------------
// Stop currently playing audio
// ---------------------------------------------------------------------------
function _stopCurrent() {
  if ('speechSynthesis' in window) {
    try { window.speechSynthesis.cancel(); } catch (_) {}
  }
  if (_currentSource) {
    try { _currentSource.stop(); } catch (_) {}
    _currentSource = null;
  }
}

// ---------------------------------------------------------------------------
// Lazy AudioContext (created on first user gesture — required by browsers)
// ---------------------------------------------------------------------------
function _getAudioContext() {
  if (!_audioCtx || _audioCtx.state === 'closed') {
    _audioCtx = new (window.AudioContext || window.webkitAudioContext)();
  }
  if (_audioCtx.state === 'suspended') {
    _audioCtx.resume();
  }
  return _audioCtx;
}

// ---------------------------------------------------------------------------
// Button loading/playing/idle states
// ---------------------------------------------------------------------------
function _setBtnState(btn, state) {
  if (!btn) return;
  btn.disabled = (state === 'loading');

  if (state === 'loading') {
    btn.classList.remove('is-speaking');
    btn.innerHTML = '<span class="speaker-icon-lg">⏳</span> <span>Loading…</span>';
  } else if (state === 'playing') {
    btn.classList.add('is-speaking');
    btn.innerHTML = '<span class="speaker-icon-lg">⏹</span> <span>Stop</span>';
    // Clicking again stops playback
    btn.onclick = (e) => {
      e.preventDefault();
      _stopCurrent();
      _setBtnState(btn, 'idle');
      // Restore original onclick after stop
      btn.onclick = btn._originalOnclick || null;
    };
  } else {
    btn.classList.remove('is-speaking');
    btn.innerHTML = '<span class="speaker-icon-lg">🔊</span> <span>Listen</span>';
  }
}

// ---------------------------------------------------------------------------
// Helper: build a Listen button that speaks a given text
// Called from renderResult / renderPlan to attach TTS to each section
// ---------------------------------------------------------------------------
function makeListenBtn(text, language, extraClass = '') {
  const btn  = document.createElement('button');
  btn.className = `btn btn-secondary btn-sm listen-btn ${extraClass}`;
  btn.textContent = '🔊 Listen';
  btn.addEventListener('click', () => {
    btn._originalOnclick = null;
    speakText(text, language || window.AppState?.currentLanguage || 'en-IN', btn);
  });
  return btn;
}

// ---------------------------------------------------------------------------
// Language change — propagate to STT + TTS + LLM prompt language
// ---------------------------------------------------------------------------
function onLanguageChange(newCode) {
  // Clear in-memory audio cache so the new language is fetched fresh
  _audioCache.clear();
  _stopCurrent();
  console.log('[TTS] Language changed to', newCode, '— audio cache cleared');
}

// ---------------------------------------------------------------------------
// User settings panel — language picker (enhanced, Phase 6)
// ---------------------------------------------------------------------------
function initLanguagePanel() {
  // Intercept language button clicks to also trigger onLanguageChange
  document.getElementById('lang-selector')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.lang-btn');
    if (btn && btn.dataset.code) onLanguageChange(btn.dataset.code);
  });
}

// ---------------------------------------------------------------------------
// Expose globals
// ---------------------------------------------------------------------------
window.speakText        = speakText;
window.makeListenBtn    = makeListenBtn;
window.onLanguageChange = onLanguageChange;

// Init language panel after DOM loads
document.addEventListener('DOMContentLoaded', initLanguagePanel);
