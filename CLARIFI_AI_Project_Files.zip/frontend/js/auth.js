/**
 * CLARIFI AI — Authentication & Onboarding Gate (auth.js)
 * Full 2-Factor Authentication via Gmail SMTP, Google Sign-In, and Profile Modal.
 */

'use strict';

const AuthState = {
  user: null, // { id: number, name: string, email: string, is_verified: boolean }
  pendingAuth: null, // { email: string, name?: string, mode: 'signup'|'signin' }
};

function initAuth() {
  // Check stored user session
  try {
    const stored = localStorage.getItem('clarifi_user');
    if (stored) {
      AuthState.user = JSON.parse(stored);
      // Auto-purge any stale mock sessions that don't have a valid email or verified state
      if (!AuthState.user || !AuthState.user.email || !AuthState.user.is_verified) {
        AuthState.user = null;
        localStorage.removeItem('clarifi_user');
      }
    }
  } catch (e) {
    console.warn('[Auth] Failed to parse stored user', e);
  }

  renderAuthBadge();
  bindAuthEvents();
  setupPasswordToggles();

  // If no user is logged in or user is not verified, show the welcome landing page & auth modal
  if (!AuthState.user || !AuthState.user.is_verified) {
    openAuthModal();
  }
}

function bindAuthEvents() {
  const authModal = document.getElementById('auth-modal');
  const profileModal = document.getElementById('profile-modal');
  const viewLanding = document.getElementById('auth-view-landing');
  const viewLogin = document.getElementById('auth-view-login');
  const btnLandingEnter = document.getElementById('btn-landing-enter');
  const btnLandingSignin = document.getElementById('btn-landing-signin');
  const btnLandingTopSignin = document.getElementById('btn-landing-top-signin');
  const btnBackToLanding = document.getElementById('btn-back-to-landing');
  const modalCard = document.getElementById('auth-modal-card');

  // Login / Signup / OTP elements
  const btnToggleSignUp = document.getElementById('btn-to-signup');
  const btnToggleSignIn = document.getElementById('btn-to-signin');
  const btnBackToAuth = document.getElementById('btn-back-to-auth');
  const btnGoogleLogin = document.getElementById('btn-google-login');
  const btnCancelGoogle = document.getElementById('btn-cancel-google');
  const formGoogleEmail = document.getElementById('auth-form-google-email');
  const formSignIn = document.getElementById('auth-form-signin');
  const formSignUp = document.getElementById('auth-form-signup');
  const formOtp = document.getElementById('auth-form-otp');
  const btnResendOtp = document.getElementById('btn-resend-otp');

  // Profile modal elements
  const authBadge = document.getElementById('user-profile-badge');
  const btnCloseProfile = document.getElementById('btn-close-profile');
  const btnSignoutConfirm = document.getElementById('btn-signout-confirm');
  const btnDeleteAccount = document.getElementById('btn-delete-account');

  const showLoginView = () => {
    if (modalCard) modalCard.classList.remove('fullscreen-mode');
    if (viewLanding) viewLanding.style.display = 'none';
    if (viewLogin) viewLogin.style.display = 'block';
  };

  const showLandingView = () => {
    if (modalCard) modalCard.classList.add('fullscreen-mode');
    if (viewLogin) viewLogin.style.display = 'none';
    if (viewLanding) viewLanding.style.display = 'block';
  };

  // Landing CTA buttons -> Transition to Sign In / Sign Up view
  btnLandingEnter?.addEventListener('click', showLoginView);
  btnLandingSignin?.addEventListener('click', showLoginView);
  btnLandingTopSignin?.addEventListener('click', showLoginView);

  // Back to Landing screen
  btnBackToLanding?.addEventListener('click', (e) => {
    e.preventDefault();
    showLandingView();
  });

  // Click brand logo in header -> opens welcome landing or profile
  document.querySelector('.app-logo')?.addEventListener('click', () => {
    if (!AuthState.user || !AuthState.user.is_verified) {
      openAuthModal(false);
    } else {
      openProfileModal();
    }
  });

  // Toggle between Sign In and Sign Up tabs
  btnToggleSignUp?.addEventListener('click', (e) => {
    e.preventDefault();
    if (formSignIn) formSignIn.style.display = 'none';
    if (formGoogleEmail) formGoogleEmail.style.display = 'none';
    if (formOtp) formOtp.style.display = 'none';
    if (formSignUp) formSignUp.style.display = 'flex';
  });

  btnToggleSignIn?.addEventListener('click', (e) => {
    e.preventDefault();
    if (formSignUp) formSignUp.style.display = 'none';
    if (formGoogleEmail) formGoogleEmail.style.display = 'none';
    if (formOtp) formOtp.style.display = 'none';
    if (formSignIn) formSignIn.style.display = 'flex';
  });

  btnBackToAuth?.addEventListener('click', (e) => {
    e.preventDefault();
    if (formOtp) formOtp.style.display = 'none';
    if (formSignIn) formSignIn.style.display = 'flex';
  });

  // Continue with Google -> Prompt user to enter their Gmail address
  btnGoogleLogin?.addEventListener('click', () => {
    if (formSignIn) formSignIn.style.display = 'none';
    if (formSignUp) formSignUp.style.display = 'none';
    if (formOtp) formOtp.style.display = 'none';
    if (formGoogleEmail) {
      formGoogleEmail.style.display = 'flex';
      document.getElementById('google-email-input')?.focus();
    }
  });

  // Cancel Google input -> return to normal signin
  btnCancelGoogle?.addEventListener('click', (e) => {
    e.preventDefault();
    if (formGoogleEmail) formGoogleEmail.style.display = 'none';
    if (formSignIn) formSignIn.style.display = 'flex';
  });

  // Submit Google email -> Sends 6-digit verification code to that Gmail inbox
  formGoogleEmail?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('google-email-input')?.value.trim();
    const name = document.getElementById('google-name-input')?.value.trim();

    if (!email || !email.includes('@')) {
      showToast('Please enter a valid Gmail / Google email address', 'warning', 2000);
      return;
    }

    showLoading(true, 'Sending verification code to Gmail…');
    try {
      const res = await fetch('/api/auth/google', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name: name || 'Google User' }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Failed to send Google verification code');

      AuthState.pendingAuth = { email, name: data.name || name || 'Google User', mode: 'google' };
      showOtpView(email, data.smtp_configured);
      showToast(data.message || 'Verification code sent to your Gmail inbox!', 'info', 3000);
    } catch (err) {
      showToast(err.message, 'error', 3000);
    } finally {
      showLoading(false);
    }
  });

  // Sign In submit -> Sends 2FA OTP
  formSignIn?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = document.getElementById('signin-email')?.value.trim();
    const password = document.getElementById('signin-password')?.value || 'demo123';

    if (!email) {
      showToast('Please enter an email address', 'warning', 2000);
      return;
    }

    showLoading(true, 'Verifying credentials…');
    try {
      const res = await fetch('/api/auth/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Sign in failed');

      AuthState.pendingAuth = { email, name: data.name || email.split('@')[0], mode: 'signin' };
      showOtpView(email, data.smtp_configured);
      showToast(data.message || 'Verification code sent to your email', 'info', 2000);
    } catch (err) {
      showToast(err.message, 'error', 2000);
    } finally {
      showLoading(false);
    }
  });

  // Sign Up submit -> Sends 2FA OTP via Gmail SMTP (All fields mandatory)
  formSignUp?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('signup-name')?.value.trim();
    const email = document.getElementById('signup-email')?.value.trim();
    const password = document.getElementById('signup-password')?.value;

    if (!name || name.length < 2) {
      showToast('First Name / Full Name is mandatory (minimum 2 characters)', 'warning', 3000);
      document.getElementById('signup-name')?.focus();
      return;
    }
    if (!email || !email.includes('@')) {
      showToast('Please enter a valid email address', 'warning', 3000);
      document.getElementById('signup-email')?.focus();
      return;
    }
    if (!password || password.length < 4) {
      showToast('Password is mandatory (minimum 4 characters)', 'warning', 3000);
      document.getElementById('signup-password')?.focus();
      return;
    }

    showLoading(true, 'Sending verification code to email…');
    try {
      const res = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Sign up failed');

      AuthState.pendingAuth = { email, name: data.name || name, mode: 'signup' };
      showOtpView(email, data.smtp_configured);
      showToast('6-digit verification code sent to your email!', 'info', 2000);
    } catch (err) {
      showToast(err.message, 'error', 2000);
    } finally {
      showLoading(false);
    }
  });

  // Verify OTP submit -> Validates code and enters the home page
  formOtp?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const otp = document.getElementById('otp-code-input')?.value.trim();
    const email = AuthState.pendingAuth?.email || document.getElementById('signin-email')?.value.trim();

    if (!otp || otp.length !== 6) {
      showToast('Please enter the 6-digit code', 'warning', 2000);
      return;
    }

    showLoading(true, 'Verifying 6-digit Code…');
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, otp }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Invalid verification code');

      loginUser(data.user);
      showToast('Account verified! Welcome to CLARIFI AI 🎉', 'success', 2500);
    } catch (err) {
      showToast(err.message, 'error', 2500);
    } finally {
      showLoading(false);
    }
  });

  // Resend OTP
  btnResendOtp?.addEventListener('click', async (e) => {
    e.preventDefault();
    if (!AuthState.pendingAuth?.email) return;
    showToast('Resending verification code…', 'info', 1500);
    try {
      let endpoint = '/api/auth/signin';
      if (AuthState.pendingAuth.mode === 'signup') endpoint = '/api/auth/signup';
      else if (AuthState.pendingAuth.mode === 'google') endpoint = '/api/auth/google';

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: AuthState.pendingAuth.name || 'User',
          email: AuthState.pendingAuth.email,
          password: '••••••••',
        }),
      });
      const data = await res.json();
      showOtpView(AuthState.pendingAuth.email, data.smtp_configured);
      showToast('New code sent to your email inbox!', 'success', 2000);
    } catch (err) {
      showToast('Could not resend code', 'error', 2000);
    }
  });

  // Profile click in header -> Opens themed Profile Modal
  authBadge?.addEventListener('click', () => {
    if (AuthState.user) {
      openProfileModal();
    } else {
      openAuthModal(true); // Open directly to sign in if clicked from header
    }
  });

  // Close profile modal
  btnCloseProfile?.addEventListener('click', () => {
    closeProfileModal();
  });

  // Confirm sign out in profile modal
  btnSignoutConfirm?.addEventListener('click', () => {
    closeProfileModal();
    logoutUser();
  });

  // Delete Account option in profile
  btnDeleteAccount?.addEventListener('click', async () => {
    if (!AuthState.user || !AuthState.user.email) return;

    const confirmed = window.confirm(
      `⚠️ Permanently delete your account (${AuthState.user.email})?\n\nThis will erase all your personal expenses, saved goals, and history. This action cannot be undone.`
    );
    if (!confirmed) return;

    showLoading(true, 'Deleting account and records…');
    try {
      const res = await fetch('/api/auth/delete-account', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: AuthState.user.email }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Failed to delete account');

      closeProfileModal();
      AuthState.user = null;
      localStorage.removeItem('clarifi_user');
      renderAuthBadge();
      showToast('Your account and financial records have been deleted.', 'info', 3000);
      openAuthModal(false); // Return to landing view
    } catch (err) {
      showToast(err.message, 'error', 3000);
    } finally {
      showLoading(false);
    }
  });
}

function showOtpView(email, smtpConfigured) {
  const formSignIn = document.getElementById('auth-form-signin');
  const formSignUp = document.getElementById('auth-form-signup');
  const formOtp = document.getElementById('auth-form-otp');
  const formGoogleEmail = document.getElementById('auth-form-google-email');
  const targetEmailEl = document.getElementById('otp-target-email');
  const otpInput = document.getElementById('otp-code-input');
  const banner = document.getElementById('smtp-status-banner');

  if (formSignIn) formSignIn.style.display = 'none';
  if (formSignUp) formSignUp.style.display = 'none';
  if (formGoogleEmail) formGoogleEmail.style.display = 'none';
  if (formOtp) formOtp.style.display = 'flex';

  if (targetEmailEl) targetEmailEl.textContent = email;

  if (banner) {
    if (smtpConfigured === false) {
      banner.className = 'smtp-status-banner warning';
      banner.style.display = 'block';
      banner.innerHTML = `⚠️ <strong>Gmail SMTP Credentials Missing in .env</strong><br>` +
        `<span style="font-size:0.78rem;opacity:0.95;">To receive 2FA verification codes in your Gmail inbox, add your <code>SMTP_USER</code> and 16-character App Password to <code>SMTP_PASSWORD</code> in your <code>.env</code> file.</span>`;
    } else if (smtpConfigured === true) {
      banner.className = 'smtp-status-banner success';
      banner.style.display = 'block';
      banner.innerHTML = `📬 <strong>Verification Code Dispatched!</strong><br><span style="font-size:0.8rem;opacity:0.95;">Please check your Gmail inbox (and spam folder) for your 6-digit code.</span>`;
    } else {
      banner.style.display = 'none';
    }
  }

  if (otpInput) {
    otpInput.value = '';
    setTimeout(() => otpInput.focus(), 150);
  }
}

function setupPasswordToggles() {
  [
    { btnId: 'btn-toggle-signin-password', inputId: 'signin-password' },
    { btnId: 'btn-toggle-signup-password', inputId: 'signup-password' },
  ].forEach(({ btnId, inputId }) => {
    const btn = document.getElementById(btnId);
    const input = document.getElementById(inputId);
    if (!btn || !input) return;
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const isPassword = input.type === 'password';
      input.type = isPassword ? 'text' : 'password';
      btn.textContent = isPassword ? '🙈' : '👁️';
      btn.title = isPassword ? 'Hide password' : 'Show password';
    });
  });
}

function loginUser(userData) {
  AuthState.user = userData;
  localStorage.setItem('clarifi_user', JSON.stringify(userData));
  renderAuthBadge();
  closeAuthModal();
  closeProfileModal();

  // Reset forms
  const formSignIn = document.getElementById('auth-form-signin');
  const formSignUp = document.getElementById('auth-form-signup');
  const formOtp = document.getElementById('auth-form-otp');
  const formGoogleEmail = document.getElementById('auth-form-google-email');
  if (formSignIn) formSignIn.style.display = 'flex';
  if (formSignUp) formSignUp.style.display = 'none';
  if (formOtp) formOtp.style.display = 'none';
  if (formGoogleEmail) formGoogleEmail.style.display = 'none';

  showToast(`Welcome, ${userData.name}! 👋`, 'success', 2000);

  // Navigate directly to Dashboard as the front page
  if (typeof window.showSection === 'function') {
    window.showSection('dashboard');
  }

  // Refresh views for the newly logged in user
  if (typeof window.loadTransactions === 'function') window.loadTransactions();
  if (typeof window.loadDashboard === 'function') window.loadDashboard();
  if (typeof window.loadGoals === 'function') window.loadGoals();

  // If user has language preference, apply it
  if (userData.preferredLanguage && window.applyLanguage) {
    window.setLanguage(userData.preferredLanguage);
  }
}

function logoutUser() {
  AuthState.user = null;
  localStorage.removeItem('clarifi_user');
  renderAuthBadge();
  if (typeof window.loadTransactions === 'function') window.loadTransactions();
  if (typeof window.loadDashboard === 'function') window.loadDashboard();
  if (typeof window.loadGoals === 'function') window.loadGoals();
  showToast('You have been signed out.', 'info', 2000);
  openAuthModal(false);
}

function renderAuthBadge() {
  const badge = document.getElementById('user-profile-badge');
  if (!badge) return;

  if (AuthState.user) {
    const initials = getInitials(AuthState.user.name);
    badge.innerHTML = `
      <span class="user-avatar-circle">${initials}</span>
      <span class="user-name">${escHtml(AuthState.user.name)}</span>
      <span class="user-arrow">▾</span>
    `;
    badge.classList.add('logged-in');
    badge.title = `${AuthState.user.name} (${AuthState.user.email}) — Click for account options`;
  } else {
    badge.innerHTML = `
      <span class="user-avatar">👤</span>
      <span class="user-name" data-i18n="auth_signin">Sign In</span>
    `;
    badge.classList.remove('logged-in');
    badge.title = 'Sign In to account';
  }
}

function openAuthModal(showLoginDirectly = false) {
  const modal = document.getElementById('auth-modal');
  const viewLanding = document.getElementById('auth-view-landing');
  const viewLogin = document.getElementById('auth-view-login');
  const modalCard = document.getElementById('auth-modal-card');
  if (modal) {
    const curLang = window.AppState?.currentLanguage || 'en-IN';
    modal.querySelectorAll('.auth-lang-btn').forEach(btn => {
      const code = btn.dataset.lang || btn.dataset.code;
      btn.classList.toggle('active', code === curLang);
    });

    if (showLoginDirectly) {
      if (modalCard) modalCard.classList.remove('fullscreen-mode');
      if (viewLanding) viewLanding.style.display = 'none';
      if (viewLogin) viewLogin.style.display = 'block';
    } else {
      if (modalCard) modalCard.classList.add('fullscreen-mode');
      if (viewLanding) viewLanding.style.display = 'block';
      if (viewLogin) viewLogin.style.display = 'none';
    }

    modal.classList.add('visible');
  }
}

function closeAuthModal() {
  if (!AuthState.user || !AuthState.user.is_verified) {
    return; // Strict gate: user must be verified before dashboard unlocks
  }
  const modal = document.getElementById('auth-modal');
  if (modal) modal.classList.remove('visible');
}

function openProfileModal() {
  const modal = document.getElementById('profile-modal');
  if (!modal || !AuthState.user) return;

  const avatarEl = document.getElementById('profile-avatar-display');
  const nameEl = document.getElementById('profile-name-display');
  const emailEl = document.getElementById('profile-email-display');

  if (avatarEl) avatarEl.textContent = getInitials(AuthState.user.name);
  if (nameEl) nameEl.textContent = AuthState.user.name;
  if (emailEl) emailEl.textContent = AuthState.user.email || 'user@clarifi.ai';

  modal.classList.add('visible');
}

function closeProfileModal() {
  const modal = document.getElementById('profile-modal');
  if (modal) modal.classList.remove('visible');
}

function getInitials(name) {
  if (!name) return 'U';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
  return name.slice(0, 2).toUpperCase();
}

function capitalize(s) {
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : 'User';
}

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;')
    .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

window.AuthState = AuthState;
window.initAuth = initAuth;
window.openProfileModal = openProfileModal;
window.closeProfileModal = closeProfileModal;
window.openAuthModal = openAuthModal;
window.closeAuthModal = closeAuthModal;
window.logoutUser = logoutUser;
