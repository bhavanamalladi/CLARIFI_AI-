/**
 * CLARIFI AI — Learn / Explainer Module  (Phase 4)
 *
 * Renders the Financial Product Explainer tab:
 *  - Quick-topic pill buttons (FD, SIP, PPF, NPS …) loaded from /api/explain/topics
 *  - Voice/typed query input that calls /api/explain
 *  - Renders: summary card, how-it-works, comparison table, worked example,
 *    key takeaway, related topics, financial compliance disclaimer
 *  - "🔊 Listen" button placeholder (wired up in Phase 6 with Gnani TTS)
 *
 * No external libraries. Pure vanilla JS + Canvas already in dashboard.js.
 */

'use strict';

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
const LearnState = {
  currentResult: null,   // last explanation JSON
  currentTopicKey: 'sip',
  currentQuery: '',
  loading: false,
};

// ---------------------------------------------------------------------------
// Init — called by app.js when Learn tab is first opened
// ---------------------------------------------------------------------------
async function initLearn() {
  await loadTopicButtons();
  bindLearnForm();
  renderSchemesGrid();

  // If Phase 2 routed here with a pending query, auto-explain it; otherwise default to SIP
  if (window.AppState?.pendingLearnQuery) {
    const q = window.AppState.pendingLearnQuery;
    window.AppState.pendingLearnQuery = null;
    await runExplain(q);
  } else if (!LearnState.currentResult) {
    await runExplain('What is a SIP and how does it work?', 'sip');
  }
}

// ---------------------------------------------------------------------------
// All Schemes & Instruments Showcase with Audio Voice on All Schemes
// ---------------------------------------------------------------------------
const SCHEMES_CATALOG = [
  {
    key: 'fd',
    icon: '🏦',
    name: 'Fixed Deposit (FD)',
    badge: '100% Capital Safe',
    category: 'Bank Deposit',
    returnRate: '6.5% – 7.5% p.a.',
    lockIn: '7 Days – 10 Years',
    risk: 'Very Low (DICGC ₹5L Insured)',
    query: 'Explain Fixed Deposit (FD) in simple terms',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Bank Vault with Guaranteed Return" — Lock away a lump sum for a fixed period. The bank guarantees your profit from day 1 with zero stock market risk and ₹5L RBI insurance.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "गारंटीड मुनाफे वाली बैंक तिजोरी" — एक निश्चित अवधि के लिए एकमुश्त रकम सुरक्षित रखें। बैंक बिना किसी बाजार जोखिम के पहले दिन से ब्याज की गारंटी देता है और ₹5 लाख तक आरबीआई बीमा उपलब्ध है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ಖಾತರಿ ಲಾಭದ ಬ್ಯಾಂಕ್ ವಾಲ್ಟ್" — ನಿಗದಿತ ಅವಧಿಗೆ ಒಂದು ಮೊತ್ತವನ್ನು ಸುರಕ್ಷಿತವಾಗಿ ಇರಿಸಿ. ಷೇರು ಮಾರುಕಟ್ಟೆ ಅಪಾಯವಿಲ್ಲದೆ ಮೊದಲ ದಿನದಿಂದಲೇ ಬ್ಯಾಂಕ್ ಖಾತರಿ ಬಡ್ಡಿ ನೀಡುತ್ತದೆ ಮತ್ತು ₹5 ಲಕ್ಷದವರೆಗೆ ವಿಮೆ ಇರುತ್ತದೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "గ్యారెంటీ లాభం ఇచ్చే బ్యాంక్ వాల్ట్" — నిర్ణీత కాలానికి ఒకేసారి కొంత మొత్తాన్ని డిపాజిట్ చేయండి. మార్కెట్ రిస్క్ లేకుండా మొదటి రోజు నుండే గ్యారెంటీ వడ్డీ లభిస్తుంది మరియు ₹5 లక్షల వరకు ప్రభుత్వ బీమా ఉంటుంది.'
    },
    speech: {
      'en-IN': 'A Fixed Deposit is like a bank vault with guaranteed profit. You lock in a lump sum for a fixed period at a guaranteed return of 6.5 to 7.5 percent per year. It is 100 percent capital safe with zero stock market risk, backed by RBI insurance up to 5 lakh rupees.',
      'hi-IN': 'फिक्स्ड डिपॉजिट यानी एफडी एक गारंटीड बैंक तिजोरी की तरह है। इसमें आपकी जमा राशि पर 6.5 से 7.5 प्रतिशत तक का तय ब्याज मिलता है। इसमें कोई शेयर बाजार जोखिम नहीं होता और आरबीआई द्वारा 5 लाख रुपये तक का बीमा रहता है।',
      'kn-IN': 'ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ ಎಂದರೆ ಖಾತರಿ ಲಾಭ ನೀಡುವ ಬ್ಯಾಂಕ್ ವಾಲ್ಟ್ ಇದ್ದಂತೆ. ನಿಮ್ಮ ಹಣವನ್ನು ನಿಗದಿತ ಅವಧಿಗೆ ಇರಿಸಿದರೆ ವಾರ್ಷಿಕ 6.5 ರಿಂದ 7.5 ಪ್ರತಿಶತ ಖಾತರಿಯ ಬಡ್ಡಿ ಸಿಗುತ್ತದೆ. ಮಾರುಕಟ್ಟೆ ಅಪಾಯವಿಲ್ಲದೆ 5 ಲಕ್ಷದವರೆಗೆ ಸರ್ಕಾರಿ ವಿಮೆ ಇರುತ್ತದೆ.',
      'te-IN': 'ఫిక్స్‌డ్ డిపాజిట్ అనేది గ్యారెంటీ లాభాన్ని ఇచ్చే బ్యాంక్ వాల్ట్ లాంటిది. మీ సొమ్ముపై వార్షికంగా 6.5 నుండి 7.5 శాతం ఖచ్చితమైన వడ్డీ లభిస్తుంది. మార్కెట్ రిస్క్ లేకుండా ఆర్బీఐ ద్వారా 5 లక్షల వరకు ప్రభుత్వ బీమా ఉంటుంది.'
    }
  },
  {
    key: 'rd',
    icon: '📅',
    name: 'Recurring Deposit (RD)',
    badge: 'Disciplined Monthly Saving',
    category: 'Monthly Deposit',
    returnRate: '6.5% – 7.2% p.a.',
    lockIn: '6 Months – 10 Years',
    risk: 'Very Low',
    query: 'Explain Recurring Deposit (RD)',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Automated Monthly Piggy Bank" — A fixed amount is automatically saved every month from your earnings into guaranteed compound interest with zero risk.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "ऑटोमेटेड मासिक गुल्लक" — हर महीने आपकी कमाई से एक तय राशि अपने आप सुरक्षित जमा होती है और बिना जोखिम के गारंटीड चक्रवृद्धि ब्याज मिलता है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ಸ್ವಯಂಚಾಲಿತ ಮಾಸಿಕ ಪಿಗ್ಗಿ ಬ್ಯಾಂಕ್" — ಪ್ರತಿ ತಿಂಗಳು ನಿಮ್ಮ ಆದಾಯದಿಂದ ನಿಗದಿತ ಮೊತ್ತ ಉಳಿತಾಯವಾಗಿ ಶೂನ್ಯ ಅಪಾಯದಲ್ಲಿ ಖಾತರಿ ಬಡ್ಡಿ ಗಳಿಸುತ್ತದೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "ఆటోమేటిక్ మంత్లీ పిగ్గీ బ్యాంక్" — ప్రతి నెలా మీ సంపాదన నుండి ఒక స్థిర మొత్తం స్వయంచాలితంగా జమ అవుతూ ఎటువంటి రిస్క్ లేకుండా గ్యారెంటీ చక్రవడ్డీ లభిస్తుంది.'
    },
    speech: {
      'en-IN': 'A Recurring Deposit is like an automated monthly piggy bank. A fixed amount is automatically saved from your salary each month, earning 6.5 to 7.2 percent guaranteed compound interest without any stock market risk.',
      'hi-IN': 'आवर्ती जमा यानी आरडी एक ऑटोमेटेड मासिक गुल्लक की तरह है। हर महीने आपके वेतन से एक निश्चित रकम अपने आप जमा होती है और 6.5 से 7.2 प्रतिशत गारंटीड चक्रवृद्धि ब्याज मिलता है।',
      'kn-IN': 'ರಿಕರಿಂಗ್ ಡೆಪಾಸಿಟ್ ಎಂದರೆ ಸ್ವಯಂಚಾಲಿತ ಮಾಸಿಕ ಪಿಗ್ಗಿ ಬ್ಯಾಂಕ್ ಇದ್ದಂತೆ. ಪ್ರತಿ ತಿಂಗಳು ಸಂಬಳದಿಂದ ನಿಗದಿತ ಮೊತ್ತ ಜಮೆಯಾಗಿ 6.5 ರಿಂದ 7.2 ಪ್ರತಿಶತ ಖಾತರಿ ಬಡ್ಡಿ ದೊರೆಯುತ್ತದೆ.',
      'te-IN': 'రికరింగ్ డిపాజిట్ అనేది ప్రతి నెలా పొదుపు చేసే పిగ్గీ బ్యాంక్ లాంటిది. ప్రతి నెలా మీ జీతం నుండి కొంత మొత్తం ఆటోమేటిక్‌గా జమ అవుతూ 6.5 నుండి 7.2 శాతం గ్యారెంటీ వడ్డీ లభిస్తుంది.'
    }
  },
  {
    key: 'sip',
    icon: '📈',
    name: 'Systematic Investment Plan (SIP)',
    badge: 'Top Wealth Builder',
    category: 'Mutual Fund SIP',
    returnRate: '12% – 15% (Illustrative)',
    lockIn: 'None (Flexible anytime)',
    risk: 'Moderate to High',
    query: 'What is a SIP and how does it work?',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Gym Membership for Wealth" — Small monthly amounts (like ₹500 or ₹2,000) invest into India\'s top companies and compound like a rolling snowball over time.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "संपत्ति के लिए जिम मेंबरशिप" — हर महीने ₹500 या ₹2,000 जैसी छोटी रकम भारत की शीर्ष कंपनियों में निवेश होती है और समय के साथ चक्रवृद्धि से बड़ी पूंजी बनाती है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ಸಂಪತ್ತಿನ ಜಿಮ್ ಸದಸ್ಯತ್ವ" — ಪ್ರತಿ ತಿಂಗಳು ₹500 ಅಥವಾ ₹2,000 ನಂತಹ ಸಣ್ಣ ಮೊತ್ತವು ಭಾರತದ ಮುಂಚೂಣಿ ಕಂಪನಿಗಳಲ್ಲಿ ಹೂಡಿಕೆಯಾಗಿ ಕಾಲಕ್ರಮೇಣ ದೊಡ್ಡ ಸಂಪತ್ತಾಗಿ ಬೆಳೆಯುತ್ತದೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "సంపద కోసం జిమ్ మెంబర్‌షిప్" — నెలకు ₹500 లేదా ₹2,000 వంటి చిన్న మొత్తాలు భారతదేశపు అగ్ర కంపెనీలలో పెట్టుబడి పెట్టి కాలక్రమేణా భారీ సంపదగా పెరుగుతాయి.'
    },
    speech: {
      'en-IN': 'A Systematic Investment Plan is like a gym membership for your wealth. Just as regular workouts build physical strength, small monthly investments like 500 or 2,000 rupees grow into large wealth over time through compounding.',
      'hi-IN': 'एसआईपी आपकी संपत्ति के लिए एक जिम मेंबरशिप की तरह है। जैसे नियमित कसरत से शरीर मजबूत होता है, वैसे ही हर महीने 500 या 2000 रुपये का छोटा निवेश समय के साथ चक्रवृद्धि ब्याज से बड़ा फंड बना देता है।',
      'kn-IN': 'ಎಸ್‌ಐಪಿ ಎಂದರೆ ಸಂಪತ್ತಿನ ಜಿಮ್ ಸದಸ್ಯತ್ವ ಇದ್ದಂತೆ. ದಿನನಿತ್ಯದ ವ್ಯಾಯಾಮ ದೇಹವನ್ನು ಸದೃಢಗೊಳಿಸುವಂತೆ, ಪ್ರತಿ ತಿಂಗಳು ₹500 ಅಥವಾ ₹2000 ಹೂಡಿಕೆ ಮಾಡುವುದರಿಂದ ದೀರ್ಘಾವಧಿಯಲ್ಲಿ ದೊಡ್ಡ ಸಂಪತ್ತು ನಿರ್ಮಾಣವಾಗುತ್ತದೆ.',
      'te-IN': 'సిప్ అనేది సంపదను పెంచే జిమ్ సభ్యత్వం లాంటిది. రోజూ వ్యాయామం చేస్తే ఆరోగ్యం మెరుగుపడినట్లే, ప్రతి నెలా 500 లేదా 2000 రూపాయల చిన్న పెట్టుబడి దీర్ಘకాలంలో భారీ సంపదగా మారుతుంది.'
    }
  },
  {
    key: 'mutual_funds',
    icon: '🌱',
    name: 'Mutual Funds',
    badge: 'Professional Diversification',
    category: 'Market Instrument',
    returnRate: '10% – 15% (Illustrative)',
    lockIn: 'None (except ELSS)',
    risk: 'Diversified Market Risk',
    query: 'Explain mutual funds for a beginner',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Professional Driver for Your Money" — Instead of picking individual stocks yourself, pool your money with others and let experienced, certified fund managers drive the portfolio.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "आपके पैसों के लिए पेशेवर ड्राइवर" — खुद अकेले शेयर चुनने के बजाय, कई लोगों का पैसा मिलकर प्रमाणित और अनुभवी फंड मैनेजर 50+ शीर्ष कंपनियों में समझदारी से निवेश करते हैं।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ನಿಮ್ಮ ಹಣಕ್ಕೆ ವೃತ್ತಿಪರ ಚಾಲಕ" — ನೀವೇ ಪ್ರತ್ಯೇಕ ಷೇರುಗಳನ್ನು ಆಯ್ಕೆ ಮಾಡುವ ಬದಲು, ನುರಿತ ಫಂಡ್ ಮ್ಯಾನೇಜರ್‌ಗಳು ಹಣವನ್ನು 50ಕ್ಕೂ ಹೆಚ್ಚು ಪ್ರಮುಖ ಕಂಪನಿಗಳಲ್ಲಿ ಸಮತೋಲನವಾಗಿ ಹೂಡಿಕೆ ಮಾಡುತ್ತಾರೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "మీ డబ్బుకు ప్రొఫెషనల్ డ్రైవర్" — మీరే స్వయంగా స్టాక్స్ ఎంచుకోవడానికి బదులుగా, అనుభవజ్ఞులైన ఫండ్ మేనేజర్లు డబ్బును టాప్ 50 కంపెనీలలో తెలివిగా పెట్టుబడి పెడతారు.'
    },
    speech: {
      'en-IN': 'Mutual Funds are like hiring a professional driver for your financial journey. Instead of choosing individual company shares yourself, certified fund managers pool money and invest across 50 plus top companies for balanced growth.',
      'hi-IN': 'म्यूचुअल फंड आपके पैसे के लिए एक पेशेवर ड्राइवर की तरह हैं। खुद अकेले शेयर चुनने के बजाय, प्रमाणित फंड मैनेजर कई लोगों के पैसे को जोड़कर 50 से अधिक शीर्ष कंपनियों में समझदारी से निवेश करते हैं।',
      'kn-IN': 'ಮ್ಯೂಚುಯಲ್ ಫಂಡ್‌ಗಳು ನಿಮ್ಮ ಹಣಕಾಸಿನ ಪಯಣಕ್ಕೆ ನುರಿತ ಚಾಲಕರಿದ್ದಂತೆ. ನೀವೇ ಪ್ರತ್ಯೇಕ ಷೇರುಗಳನ್ನು ಆರಿಸುವ ಬದಲು, ತಜ್ಞ ವ್ಯವಸ್ಥಾಪಕರು ನಿಮ್ಮ ಹಣವನ್ನು ಭಾರತದ ಟಾಪ್ 50 ಕಂಪನಿಗಳಲ್ಲಿ ಸಮತೋಲನವಾಗಿ ಹೂಡಿಕೆ ಮಾಡುತ್ತಾರೆ.',
      'te-IN': 'మ్యూచువల్ ఫండ్స్ మీ పెట్టుబడి ప్రయాణానికి నైపుణ్యం కలిగిన డ్రైవర్ లాంటివి. మీరే స్వయంగా షేర్లను ఎంచుకునే బదులు, నిపుణులైన ఫండ్ మేనేజర్లు మీ డబ్బును అగ్రశ్రేణి కంపెనీలలో తెలివిగా పెట్టుబడి పెడతారు.'
    }
  },
  {
    key: 'ppf',
    icon: '🏛️',
    name: 'Public Provident Fund (PPF)',
    badge: '100% Tax-Free Sovereign',
    category: 'Govt. Scheme',
    returnRate: '7.1% p.a. (Tax-Free EEE)',
    lockIn: '15 Years',
    risk: 'Zero (Govt of India Backed)',
    query: 'Explain Public Provident Fund (PPF)',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Government\'s Zero-Tax Safe Vault" — 15-year long-term savings 100% backed by the Central Government. You pay ₹0 tax on investment, profit, and maturity.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "सरकार की शून्य-टैक्स सुरक्षित तिजोरी" — 15 साल की दीर्घावधि बचत जो पूरी तरह केंद्र सरकार द्वारा सुरक्षित है। जमा, ब्याज और मैच्योरिटी तीनों पर शून्य टैक्स लगता है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ಸರ್ಕಾರದ ಶೂನ್ಯ ತೆರಿಗೆ ಸುರಕ್ಷಿತ ವಾಲ್ಟ್" — ಕೇಂದ್ರ ಸರ್ಕಾರದ 100% ಭರವಸೆ ಹೊಂದಿರುವ 15 ವರ್ಷಗಳ ದೀರ್ಘಾವಧಿ ಉಳಿತಾಯ. ಹೂಡಿಕೆ, ಬಡ್ಡಿ ಮತ್ತು ಮುಕ್ತಾಯ ಎಲ್ಲದರಲ್ಲೂ ₹0 ತೆರಿಗೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "ప్రభుత్వపు జీరో-టాక్స్ సేఫ్ వాల్ట్" — కేంద్ర ప్రభుత్వ పూర్తి రక్షణ ఉన్న 15 సంవత్సరాల దీర్ఘకాలిక పొదుపు. పెట్టుబడి, వడ్డీ మరియు మెచ్యూరిటీపై ₹0 పన్ను.'
    },
    speech: {
      'en-IN': 'Public Provident Fund is like the Government of India zero-tax safe vault. It is a 15-year sovereign savings scheme with 7.1 percent guaranteed return where your deposit, interest, and final maturity payout are 100 percent tax-free.',
      'hi-IN': 'पब्लिक प्रोविडेंट फंड यानी पीपीएफ भारत सरकार की टैक्स-फ्री तिजोरी की तरह है। यह 15 साल की योजना है जिसमें 7.1 प्रतिशत ब्याज मिलता है और जमा, ब्याज व निकासी तीनों पर शून्य टैक्स लगता है।',
      'kn-IN': 'ಪಿಪಿಎಫ್ ಕೇಂದ್ರ ಸರ್ಕಾರದ ಶೂನ್ಯ ತೆರಿಗೆ ಸುರಕ್ಷಿತ ವಾಲ್ಟ್ ಇದ್ದಂತೆ. 15 ವರ್ಷಗಳ ಈ ಯೋಜನೆಯಲ್ಲಿ ವಾರ್ಷಿಕ 7.1 ಪ್ರತಿಶತ ಬಡ್ಡಿ ಸಿಗುತ್ತದೆ ಹಾಗೂ ಠೇವಣಿ, ಬಡ್ಡಿ ಮತ್ತು ಮುಕ್ತಾಯ ಹಣ ಎಲ್ಲವೂ 100 ಪ್ರತಿಶತ ತೆರಿಗೆ ಮುಕ್ತವಾಗಿರುತ್ತದೆ.',
      'te-IN': 'పీపీఎఫ్ అనేది భారత ప్రభుత్వ జీరో-టాక్స్ సేఫ్ వాల్ట్ లాంటిది. 15 సంవత్సరాల ఈ పథకంలో 7.1 శాతం ఖచ్చితమైన రాబడి లభిస్తుంది మరియు పెట్టుబడి, వడ్డీ, గడువు ముగిసిన మొత్తం అన్నీ పూర్తి పన్ను రహితం.'
    }
  },
  {
    key: 'nps',
    icon: '👴',
    name: 'National Pension System (NPS)',
    badge: 'Extra ₹50,000 Tax Benefit',
    category: 'Retirement Fund',
    returnRate: '9% – 12% (Illustrative)',
    lockIn: 'Until Age 60',
    risk: 'Low to Moderate',
    query: 'Explain National Pension System (NPS)',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Your Future Monthly Paycheck for Life" — Prepares a lump sum cash bonus at retirement PLUS a guaranteed monthly pension paid to your bank account forever.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "जीवनभर का भविष्य का मासिक वेतन" — रिटायरमेंट पर एकमुश्त फंड तैयार करता है और साथ ही जीवनभर आपके बैंक खाते में मासिक पेंशन सुनिश्चित करता है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ನಿಮ್ಮ ಭವಿಷ್ಯದ ಆಜೀವ ಮಾಸಿಕ ವೇತನ" — ನಿವೃತ್ತಿಯ ಸಮಯದಲ್ಲಿ ದೊಡ್ಡ ಮೊತ್ತವನ್ನು ನೀಡುವುದರ ಜೊತೆಗೆ ಜೀವನಪರ್ಯಂತ ನಿಮ್ಮ ಖಾತೆಗೆ ಮಾಸಿಕ ಪಿಂಚಣಿ ನೀಡುತ್ತದೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "మీ భవిష్యపు జీవితాంతం నెలవారీ జీతం" — రిటైర్మెంట్ సమయంలో ఏకమొత్తం నిధితో పాటు జీవితాంతం మీ బ్యాంక్ ఖాతాకు గ్యారెంటీ నెలవారీ పెన్షన్ అందిస్తుంది.'
    },
    speech: {
      'en-IN': 'National Pension System is your future monthly paycheck for life. It invests for your retirement, gives an extra 50,000 rupee tax deduction, and at age 60 provides a cash lump sum plus a lifelong monthly pension check.',
      'hi-IN': 'एनपीएस रिटायरमेंट के बाद जीवनभर के मासिक वेतन की तरह है। यह आपके बुढ़ापे के लिए फंड बनाता है, 50,000 रुपये की अतिरिक्त टैक्स छूट देता है, और 60 की उम्र में एकमुश्त फंड के साथ आजीवन मासिक पेंशन देता है।',
      'kn-IN': 'ಎನ್‌ಪಿಎಸ್ ನಿವೃತ್ತಿಯ ನಂತರದ ಜೀವನಪೂರ್ತಿ ಮಾಸಿಕ ವೇತನದಂತೆ. ಹೆಚ್ಚುವರಿ ₹50,000 ತೆರಿಗೆ ವಿನಾಯಿತಿಯೊಂದಿಗೆ 60 ವರ್ಷ ತುಂಬಿದಾಗ ದೊಡ್ಡ ಮೊತ್ತದ ಜೊತೆಗೆ ಆಜೀವ ಮಾಸಿಕ ಪಿಂಚಣಿ ನೀಡುತ್ತದೆ.',
      'te-IN': 'ఎన్‌పీఎస్ రిటైర్మెంట్ తర్వాత జీవితాంతం వచ్చే నెలవారీ జీతం లాంటిది. అదనంగా 50,000 రూపాయల పన్ను ఆదాతో పాటు 60 ఏళ్ల వయస్సులో ఏకమొత్తం నగదు మరియు జీవితాంతం నెలవారీ పెన్షన్ అందిస్తుంది.'
    }
  },
  {
    key: 'elss',
    icon: '💰',
    name: 'ELSS (Tax-Saving Mutual Fund)',
    badge: 'Shortest 3-Yr Lock-In',
    category: 'Tax Saver 80C',
    returnRate: '12% – 15% (Illustrative)',
    lockIn: '3 Years (Lowest in 80C)',
    risk: 'Equity Market Linked',
    query: 'What is ELSS and how does it save tax?',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Fastest 3-Year Tax-Saver" — Saves income tax under Section 80C with India\'s shortest lock-in period of only 3 years (versus 5 yrs for FD or 15 yrs for PPF).',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "सबसे तेज 3 साल का टैक्स सेवर" — केवल 3 साल के सबसे कम लॉक-इन पीरियड के साथ धारा 80C के तहत टैक्स बचाता है और शेयर बाजार की बढ़त देता है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ಅತ್ಯಂತ ವೇಗದ 3 ವರ್ಷಗಳ ತೆರಿಗೆ ಉಳಿತಾಯ" — ಕೇವಲ 3 ವರ್ಷಗಳ ಕಡಿಮೆ ಲಾಕ್-ಇನ್ ಅವಧಿಯೊಂದಿಗೆ ಸೆಕ್ಷನ್ 80C ಅಡಿಯಲ್ಲಿ ಆದಾಯ ತೆರಿಗೆಯನ್ನು ಉಳಿಸುತ್ತದೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "వేగవంతమైన 3 సంవత్సరాల టాక్స్-సేవర్" — కేవలం 3 సంవత్సరాల అతి తక్కువ లాక్-ఇన్ కాలంతో సెక్షన్ 80C కింద ఆదాయపు పన్నును ఆదా చేస్తుంది.'
    },
    speech: {
      'en-IN': 'ELSS is the fastest 3-year tax saver. It allows you to save income tax under Section 80C with the shortest waiting period of only 3 years, while growing your money through top Indian companies.',
      'hi-IN': 'ईएलएसएस सबसे तेज 3 साल का टैक्स सेवर है। यह धारा 80सी के तहत टैक्स बचाने के साथ-साथ केवल 3 साल के सबसे कम लॉक-इन में शेयर बाजार की बढ़त का दोहरा फायदा देता है।',
      'kn-IN': 'ಇಎಲ್‌ಎಸ್‌ಎಸ್ ಅತ್ಯಂತ ವೇಗದ 3 ವರ್ಷಗಳ ತೆರಿಗೆ ಉಳಿತಾಯ ಫಂಡ್ ಆಗಿದೆ. ಕೇವಲ 3 ವರ್ಷಗಳ ಅತಿ ಕಡಿಮೆ ಲಾಕ್-ಇನ್ ಅವಧಿಯಲ್ಲಿ ತೆರಿಗೆ ಉಳಿತಾಯ ಮತ್ತು ಹೆಚ್ಚಿನ ಮಾರುಕಟ್ಟೆ ಆದಾಯ ಎರಡನ್ನೂ ನೀಡುತ್ತದೆ.',
      'te-IN': 'ఈఎల్ఎస్ఎస్ అతి వేగవంతమైన 3 సంవత్సరాల పన్ను ఆదా మార్గం. కేవలం 3 సంవత్సరాల తక్కువ లాక్-ఇన్ పీరియడ్‌తో సెక్షన్ 80C కింద పన్ను ఆదా మరియు మార్కెట్ లాభాలు రెండూ అందిస్తుంది.'
    }
  },
  {
    key: 'savings',
    icon: '💳',
    name: 'Savings Bank Account',
    badge: 'Instant 24/7 Liquidity',
    category: 'Liquid Account',
    returnRate: '2.7% – 4.0% p.a.',
    lockIn: 'Zero (Withdraw anytime)',
    risk: 'Zero (DICGC Insured)',
    query: 'How does a savings account work in India?',
    summary: {
      'en-IN': '💡 Real-Life Analogy: "Everyday Digital Wallet" — Your foundational bank account for daily UPI, Google Pay, and ATM spending with 24/7 instant cash availability.',
      'hi-IN': '💡 दैनिक जीवन का उदाहरण: "रोजमर्रा का डिजिटल बटुआ" — दैनिक यूपीआई, गूगल पे और एटीएम खर्च के लिए आपका बुनियादी बैंक खाता, जिसमें 24/7 तुरंत नकदी उपलब्ध रहती है।',
      'kn-IN': '💡 ನಿಜ ಜೀವನದ ಹೋಲಿಕೆ: "ದೈನಂದಿನ ಡಿಜಿಟಲ್ ವ್ಯಾಲೆಟ್" — ದಿನನಿತ್ಯದ ಯುಪಿಐ, ಗೂಗಲ್ ಪೇ ಮತ್ತು ಎಟಿಎಂ ಖರ್ಚುಗಳಿಗೆ 24/7 ತಕ್ಷಣದ ಹಣ ಲಭ್ಯವಿರುವ ಮೂಲ ಬ್ಯಾಂಕ್ ಖಾತೆ.',
      'te-IN': '💡 నిజ జీవిత పోలిక: "రోజువారీ డిజిటల్ వాలెట్" — రోజువారీ యూపీఐ, గూగుల్ పే మరియు ఏటీఎం ఖర్చుల కోసం 24/7 తಕ್ಷಣమే డబ్బు అందుబాటులో ఉండే ప్రాథమిక బ్యాంక్ ఖాతా.'
    },
    speech: {
      'en-IN': 'A Savings Bank Account is like your everyday digital wallet. It keeps your money safe with RBI insurance up to 5 lakh rupees and gives 24/7 instant access for UPI, Google Pay, and ATM withdrawals.',
      'hi-IN': 'बचत खाता आपके रोजमर्रा के डिजिटल बटुए की तरह है। यह यूपीआई, गूगल पे और एटीएम से 24 घंटे तत्काल पैसे खर्च करने की सुविधा देता है और 5 लाख रुपये तक सरकारी बीमित रहता है।',
      'kn-IN': 'ಉಳಿತಾಯ ಖಾತೆಯು ನಿಮ್ಮ ದೈನಂದಿನ ಡಿಜಿಟಲ್ ವ್ಯಾಲೆಟ್ ಇದ್ದಂತೆ. ಯುಪಿಐ ಮತ್ತು ಎಟಿಎಂ ಮೂಲಕ 24 ಗಂಟೆಯೂ ತಕ್ಷಣದ ಹಣ ಲಭ್ಯವಿರುತ್ತದೆ ಹಾಗೂ ₹5 ಲಕ್ಷದವರೆಗೆ ಸರ್ಕಾರದ ವಿಮೆ ಇರುತ್ತದೆ.',
      'te-IN': 'సేవింగ్స్ ఖాతా మీ రోజువారీ డిజిటల్ వాలెట్ లాంటిది. యూపీఐ, గూగుల్ పే మరియు ఏటీఎం ద్వారా 24 గంటలూ తక్షణమే నగదు వాడుకోవడానికి పూర్తి భద్రతతో కూడిన ఖాతా.'
    }
  }
];

function renderSchemesGrid() {
  const container = document.getElementById('schemes-grid');
  if (!container) return;

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const userSavings = getUserSavingsAmount();

  container.innerHTML = SCHEMES_CATALOG.map(scheme => {
    const defaultYield = calculateSchemeYield(scheme.key, userSavings);
    const summaryText = typeof scheme.summary === 'object' ? (scheme.summary[lang] || scheme.summary['en-IN']) : scheme.summary;
    const nameText = typeof scheme.name === 'object' ? (scheme.name[lang] || scheme.name['en-IN']) : scheme.name;
    const badgeText = typeof scheme.badge === 'object' ? (scheme.badge[lang] || scheme.badge['en-IN']) : scheme.badge;
    const withSavingsLabel = (window.t ? window.t('scheme_calc_with_savings', 'With your savings') : 'With your savings');
    const getEstLabel = (window.t ? window.t('scheme_calc_get_est', 'Get est.') : 'Get est.');
    const inLabel = (window.t ? window.t('scheme_calc_in', 'in') : 'in');
    const returnLabel = (window.t ? window.t('scheme_metric_return', 'Return') : 'Return');
    const lockinLabel = (window.t ? window.t('scheme_metric_lockin', 'Lock-in') : 'Lock-in');
    const listenLabel = (window.t ? window.t('btn_listen', 'Listen') : 'Listen');
    const detailsLabel = (window.t ? window.t('scheme_btn_details', 'Details & Calculate') : 'Details & Calculate');

    return `
    <div class="scheme-card" data-key="${scheme.key}">
      <div class="scheme-header">
        <div class="scheme-icon-title">
          <span class="scheme-icon">${scheme.icon}</span>
          <div>
            <div class="scheme-title">${escHtml(nameText)}</div>
            <span class="scheme-badge">${escHtml(badgeText)}</span>
          </div>
        </div>
      </div>
      <p class="scheme-desc">${escHtml(summaryText)}</p>

      <!-- Interactive "According to My Savings" Preview -->
      <div class="scheme-savings-preview">
        <span class="calc-chip-icon">💰</span>
        <div class="calc-preview-text">
          <span class="calc-preview-label">${escHtml(withSavingsLabel)} (₹${userSavings.toLocaleString('en-IN')}/mo):</span>
          <span class="calc-preview-val">${escHtml(getEstLabel)} <strong>₹${defaultYield.maturity.toLocaleString('en-IN')}</strong> ${escHtml(inLabel)} ${defaultYield.tenureLabel}</span>
        </div>
      </div>

      <div class="scheme-metrics">
        <div class="scheme-metric">
          <span class="metric-label">${escHtml(returnLabel)}:</span>
          <span class="metric-val">${escHtml(scheme.returnRate)}</span>
        </div>
        <div class="scheme-metric">
          <span class="metric-label">${escHtml(lockinLabel)}:</span>
          <span class="metric-val">${escHtml(scheme.lockIn)}</span>
        </div>
      </div>
      <div class="scheme-actions">
        <button type="button" class="btn btn-secondary btn-sm btn-listen-scheme" data-key="${scheme.key}" title="Listen to ${escHtml(nameText)}">
          <span class="speaker-icon-lg">🔊</span> <span>${escHtml(listenLabel)}</span>
        </button>
        <button type="button" class="btn btn-ghost btn-sm btn-details-scheme" data-key="${scheme.key}">
          <span>📖 ${escHtml(detailsLabel)}</span>
        </button>
      </div>
    </div>
  `}).join('');

  // Bind Listen buttons
  container.querySelectorAll('.btn-listen-scheme').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const key = btn.dataset.key;
      const scheme = SCHEMES_CATALOG.find(s => s.key === key);
      if (!scheme) return;
      const textToSpeak = (scheme.speech && scheme.speech[lang]) || scheme.speech['en-IN'];
      if (typeof window.speakText === 'function') {
        window.speakText(textToSpeak, lang, btn);
      }
    });
  });

  // Bind Details buttons
  container.querySelectorAll('.btn-details-scheme').forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.key;
      const scheme = SCHEMES_CATALOG.find(s => s.key === key);
      if (scheme) {
        // Highlight active pill
        document.querySelectorAll('#topic-pills .topic-pill').forEach(b => {
          b.classList.toggle('active', b.dataset.key === key);
        });
        runExplain(scheme.query, scheme.key);
      }
    });
  });
}

// ---------------------------------------------------------------------------
// Load preset topic pills from /api/explain/topics
// ---------------------------------------------------------------------------
async function loadTopicButtons() {
  const wrap = document.getElementById('topic-pills');
  if (!wrap) return;

  try {
    const res = await fetch('/api/explain/topics');
    if (!res.ok) throw new Error(res.status);
    const topics = await res.json();

    const lang = window.AppState?.currentLanguage || 'en-IN';
    const localizedPillLabels = {
      'en-IN': {
        fd: '🏦 Fixed Deposit (FD)',
        rd: '📅 Recurring Deposit (RD)',
        sip: '📈 SIP',
        mutual_funds: '🌱 Mutual Funds',
        ppf: '🏛️ PPF',
        nps: '👴 NPS',
        elss: '💰 ELSS',
        savings: '💳 Savings Account',
      },
      'hi-IN': {
        fd: '🏦 सावधि जमा (FD)',
        rd: '📅 आवर्ती जमा (RD)',
        sip: '📈 एसआईपी (SIP)',
        mutual_funds: '🌱 म्यूचुअल फंड',
        ppf: '🏛️ पीपीएफ (PPF)',
        nps: '👴 एनपीएस (NPS)',
        elss: '💰 ईएलएसएस (ELSS)',
        savings: '💳 बचत खाता',
      },
      'kn-IN': {
        fd: '🏦 ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ (FD)',
        rd: '📅 ರಿಕರಿಂಗ್ ಡೆಪಾಸಿಟ್ (RD)',
        sip: '📈 ಎಸ್‌ಐಪಿ (SIP)',
        mutual_funds: '🌱 ಮ್ಯೂಚುಯಲ್ ಫಂಡ್',
        ppf: '🏛️ ಪಿಪಿಎಫ್ (PPF)',
        nps: '👴 ಎನ್‌ಪಿಎಸ್ (NPS)',
        elss: '💰 ಇಎಲ್‌ಎಸ್‌ಎಸ್ (ELSS)',
        savings: '💳 ಉಳಿತಾಯ ಖಾತೆ',
      },
      'te-IN': {
        fd: '🏦 ఫిక్స్‌డ్ డిపాజిట్ (FD)',
        rd: '📅 రికరింగ్ డిపాజిట్ (RD)',
        sip: '📈 సిప్ (SIP)',
        mutual_funds: '🌱 మ్యూచువల్ ఫండ్స్',
        ppf: '🏛️ పీపీఎఫ్ (PPF)',
        nps: '👴 ఎన్‌పీఎస్ (NPS)',
        elss: '💰 ఈఎల్ఎస్ఎస్ (ELSS)',
        savings: '💳 సేవింగ్స్ ఖాతా',
      }
    };
    const pillDict = localizedPillLabels[lang] || localizedPillLabels['en-IN'];

    wrap.innerHTML = topics.map(t => {
      const label = pillDict[t.key] || t.label;
      const isActive = LearnState.currentTopicKey === t.key ? ' active' : '';
      return `<button class="topic-pill${isActive}" data-key="${escHtml(t.key)}" data-query="${escHtml(t.query)}" title="${escHtml(label)}">
        ${escHtml(label)}
      </button>`;
    }).join('');

    // Bind clicks
    wrap.querySelectorAll('.topic-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        wrap.querySelectorAll('.topic-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        runExplain(btn.dataset.query, btn.dataset.key);
      });
    });
  } catch (err) {
    console.error('[Learn] loadTopicButtons error:', err);
    wrap.innerHTML = '<p style="color:var(--color-text-muted);font-size:0.8rem">Could not load topics.</p>';
  }
}

// ---------------------------------------------------------------------------
// Bind the custom query form
// ---------------------------------------------------------------------------
function bindLearnForm() {
  const form  = document.getElementById('learn-form');
  const input = document.getElementById('learn-query');
  if (!form || !input) return;

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const q = input.value.trim();
    if (!q) { showToast('Please enter a question.', 'warning'); return; }
    runExplain(q);
  });
}

// ---------------------------------------------------------------------------
// Core: call /api/explain and render the result
// ---------------------------------------------------------------------------
async function runExplain(query, topicKey, autoSpeak = false) {
  if (LearnState.loading) return;
  LearnState.loading = true;
  if (topicKey) LearnState.currentTopicKey = topicKey;
  if (query) LearnState.currentQuery = query;

  showLearnLoading(true);
  clearResult();

  const activeLang = window.AppState?.currentLanguage || 'en-IN';

  try {
    const res = await fetch('/api/explain', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: query || LearnState.currentQuery || '',
        topic_key: topicKey || LearnState.currentTopicKey || null,
        language: activeLang,
      }),
    });

    if (!res.ok) throw new Error(`Server ${res.status}`);
    const data = await res.json();

    LearnState.currentResult = data;
    renderResult(data);

    // Scroll result into view
    document.getElementById('learn-result')?.scrollIntoView({ behavior: 'smooth', block: 'start' });

    if (autoSpeak) {
      setTimeout(() => {
        listenToExplain();
      }, 400);
    }

  } catch (err) {
    console.error('[Learn] explain error:', err);
    showToast('Could not get explanation. Please try again.', 'error');
  } finally {
    LearnState.loading = false;
    showLearnLoading(false);
  }
}

// ---------------------------------------------------------------------------
// Open Scheme & Speak Voice Narration Automatically (Talk with Money routing)
// ---------------------------------------------------------------------------
async function openSchemeAndSpeak(schemeKey, topicName, originalQuery) {
  // 1. Switch to Schemes section immediately
  if (typeof window.showSection === 'function') {
    window.showSection('learn');
  }

  // 2. Ensure Schemes section is initialised
  if (!window.AppState?._learnInitialised && typeof initLearn === 'function') {
    window.AppState._learnInitialised = true;
    await initLearn();
  }

  // 3. Resolve scheme key
  let targetKey = (schemeKey || '').toLowerCase();
  if (!targetKey || targetKey === 'null') {
    targetKey = detectSchemeKey(topicName, originalQuery);
  }
  const matchedScheme = SCHEMES_CATALOG.find(s => s.key === targetKey) || SCHEMES_CATALOG[2]; // Default SIP

  // 4. Highlight the matching topic pill
  const pillWrap = document.getElementById('topic-pills');
  if (pillWrap) {
    pillWrap.querySelectorAll('.topic-pill').forEach(b => {
      b.classList.toggle('active', b.dataset.key === matchedScheme.key);
    });
  }

  // 5. Run the full explanation & According to My Savings calculator
  const explainQuery = originalQuery || matchedScheme.query;
  await runExplain(explainQuery, matchedScheme.key, false);

  // 6. Speak the voice automatically for the asked scheme!
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const textToSpeak = (matchedScheme.speech && matchedScheme.speech[lang]) || matchedScheme.speech['en-IN'];
  
  setTimeout(() => {
    const btn = document.getElementById('btn-listen-explain') || document.querySelector(`.btn-listen-scheme[data-key="${matchedScheme.key}"]`);
    if (typeof window.speakText === 'function') {
      window.speakText(textToSpeak, lang, btn);
    }
  }, 350);
}

// ---------------------------------------------------------------------------
// According to My Savings — Yield Calculation Engine & Dynamic UI
// ---------------------------------------------------------------------------

function getUserSavingsAmount() {
  if (window.AppState?.userMonthlySavings && window.AppState.userMonthlySavings > 0) {
    return Math.round(window.AppState.userMonthlySavings);
  }
  const stored = localStorage.getItem('clarifi_calc_savings');
  if (stored && !isNaN(parseFloat(stored)) && parseFloat(stored) > 0) {
    return Math.round(parseFloat(stored));
  }
  const dashEl = document.getElementById('dash-savings');
  if (dashEl) {
    const clean = dashEl.textContent.replace(/[^0-9.]/g, '');
    const amt = parseFloat(clean);
    if (!isNaN(amt) && amt > 0) {
      if (!window.AppState) window.AppState = {};
      window.AppState.userMonthlySavings = amt;
      return Math.round(amt);
    }
  }
  return 5000; // Default illustrative ₹5,000/mo
}

function detectSchemeKey(topicName, query) {
  const text = `${topicName || ''} ${query || ''}`.toLowerCase();
  if (text.includes('fixed deposit') || text.includes('fd') || text.includes('सावधि') || text.includes('ಫಿಕ್ಸೆಡ್') || text.includes('ఫిక్స్‌డ్')) return 'fd';
  if (text.includes('recurring deposit') || text.includes('rd') || text.includes('आवर्ती') || text.includes('ರಿಕರಿಂಗ್') || text.includes('రికరింగ్')) return 'rd';
  if (text.includes('public provident') || text.includes('ppf') || text.includes('पीपीएफ') || text.includes('ಪಿಪಿಎಫ್') || text.includes('పీపీఎఫ్')) return 'ppf';
  if (text.includes('national pension') || text.includes('nps') || text.includes('एनपीएस') || text.includes('ಎನ್‌ಪಿಎಸ್') || text.includes('ఎన్‌పీఎస్')) return 'nps';
  if (text.includes('elss') || text.includes('tax saving') || text.includes('ईएलएसएस') || text.includes('ಇಎಲ್‌ಎಸ್‌ಎಸ್') || text.includes('ఈఎల్ఎస్ఎస్')) return 'elss';
  if (text.includes('saving') || text.includes('savings account') || text.includes('बचत खाता') || text.includes('ಉಳಿತಾಯ') || text.includes('సేవింగ్స్')) return 'savings';
  if (text.includes('mutual') || text.includes('म्यूचुअल') || text.includes('ಮ್ಯೂಚುಯಲ್') || text.includes('మ్యూచువల్')) return 'mutual_funds';
  return 'sip';
}

function getSchemeTenureOptions(schemeKey) {
  switch (schemeKey) {
    case 'fd':
      return [
        { years: 1, label: '1 Year (Short term)' },
        { years: 2, label: '2 Years' },
        { years: 3, label: '3 Years (Popular)', default: true },
        { years: 5, label: '5 Years (Tax Saving FD)' },
        { years: 10, label: '10 Years (Max tenure)' }
      ];
    case 'rd':
      return [
        { years: 1, label: '1 Year (12 months)' },
        { years: 2, label: '2 Years (24 months)' },
        { years: 3, label: '3 Years (36 months)', default: true },
        { years: 5, label: '5 Years (60 months)' },
        { years: 10, label: '10 Years (120 months)' }
      ];
    case 'ppf':
      return [
        { years: 5, label: '5 Years (Partial withdrawal)' },
        { years: 10, label: '10 Years' },
        { years: 15, label: '15 Years (Full Maturity)', default: true }
      ];
    case 'nps':
      return [
        { years: 10, label: '10 Years' },
        { years: 15, label: '15 Years' },
        { years: 20, label: '20 Years until Retirement', default: true },
        { years: 25, label: '25 Years' },
        { years: 30, label: '30 Years (Maximum Corpus)' }
      ];
    case 'elss':
      return [
        { years: 3, label: '3 Years (Mandatory Lock-in)', default: true },
        { years: 5, label: '5 Years (Optimal Wealth Growth)' },
        { years: 7, label: '7 Years' }
      ];
    case 'savings':
      return [
        { years: 1, label: '1 Year (Liquid balance)', default: true },
        { years: 2, label: '2 Years' },
        { years: 3, label: '3 Years' }
      ];
    case 'sip':
    case 'mutual_funds':
    default:
      return [
        { years: 1, label: '1 Year' },
        { years: 3, label: '3 Years' },
        { years: 5, label: '5 Years (Recommended)', default: true },
        { years: 10, label: '10 Years (High Wealth Growth)' },
        { years: 15, label: '15 Years (Long-term Compounding)' },
        { years: 20, label: '20 Years (Multifold Wealth)' }
      ];
  }
}

function calculateSchemeYield(key, monthlySavings, tenureYears = null) {
  const s = Math.max(100, Number(monthlySavings) || 5000);

  switch (key) {
    case 'sip': {
      const t = tenureYears || 5;
      const n = t * 12;
      const r = 0.125 / 12; // 12.5% p.a.
      const maturity = Math.round(s * ((Math.pow(1 + r, n) - 1) / r) * (1 + r));
      const invested = s * n;
      const gain = maturity - invested;
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '12.5% p.a. (Historical Equity Average)',
        benefitText: '📈 Power of Compounding: Rupee-cost averaging smooths market volatility and maximizes long-term wealth.'
      };
    }
    case 'mutual_funds': {
      const t = tenureYears || 5;
      const n = t * 12;
      const r = 0.12 / 12; // 12% p.a.
      const maturity = Math.round(s * ((Math.pow(1 + r, n) - 1) / r) * (1 + r));
      const invested = s * n;
      const gain = maturity - invested;
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '12.0% p.a. (Diversified Basket)',
        benefitText: '🌱 Diversified Growth: Money invested across India top companies by certified fund managers.'
      };
    }
    case 'rd': {
      const t = tenureYears || 3;
      const n = t * 12;
      const r = 0.068 / 4; // 6.8% quarterly compound
      let maturity = 0;
      for (let m = 1; m <= n; m++) {
        maturity += s * Math.pow(1 + r, (4 * (n - m + 1)) / 12);
      }
      maturity = Math.round(maturity);
      const invested = s * n;
      const gain = maturity - invested;
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '6.8% p.a. (Quarterly Compounding)',
        benefitText: '🔒 100% Guaranteed Capital Safe: Ideal for salaried first-time earners to build savings discipline.'
      };
    }
    case 'fd': {
      const t = tenureYears || 3;
      const principal = s * 12; // 1 year savings locked in FD
      const r = 0.071 / 4; // 7.1% quarterly compound
      const maturity = Math.round(principal * Math.pow(1 + r, 4 * t));
      const invested = principal;
      const gain = maturity - invested;
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '7.1% p.a. (Guaranteed Fixed Rate)',
        benefitText: `🛡️ Fixed Deposit: Depositing 1 Year of your savings (₹${principal.toLocaleString('en-IN')}) gives guaranteed returns backed by ₹5L DICGC insurance.`
      };
    }
    case 'ppf': {
      const t = tenureYears || 15;
      const annual = Math.min(s * 12, 150000);
      const r = 0.071; // 7.1% p.a.
      let maturity = 0;
      for (let y = 1; y <= t; y++) {
        maturity += annual * Math.pow(1 + r, t - y + 1);
      }
      maturity = Math.round(maturity);
      const invested = annual * t;
      const gain = maturity - invested;
      const taxSavedTotal = Math.round(annual * 0.20 * t);
      return {
        invested,
        maturity,
        gain,
        taxSavedTotal,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '7.1% p.a. (100% Sovereign & Tax-Free)',
        benefitText: `🏛️ Triple EEE Tax Exemption: Your ₹${gain.toLocaleString('en-IN')} gain is 100% tax-free! Plus you save up to ₹${taxSavedTotal.toLocaleString('en-IN')} in taxes under Sec 80C.`
      };
    }
    case 'nps': {
      const t = tenureYears || 20;
      const n = t * 12;
      const r = 0.10 / 12; // 10% p.a.
      const maturity = Math.round(s * ((Math.pow(1 + r, n) - 1) / r) * (1 + r));
      const invested = s * n;
      const gain = maturity - invested;
      const lumpSum60 = Math.round(maturity * 0.60);
      const annuity40 = Math.round(maturity * 0.40);
      const estMonthlyPension = Math.round((annuity40 * 0.06) / 12);
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '10.0% p.a. (Pension Compounding)',
        benefitText: `👴 Retirement Security: You get a tax-free lump sum of ₹${lumpSum60.toLocaleString('en-IN')} + a lifetime monthly pension of ~₹${estMonthlyPension.toLocaleString('en-IN')}/month!`
      };
    }
    case 'elss': {
      const t = tenureYears || 3;
      const n = t * 12;
      const r = 0.13 / 12; // 13% p.a.
      const maturity = Math.round(s * ((Math.pow(1 + r, n) - 1) / r) * (1 + r));
      const invested = s * n;
      const gain = maturity - invested;
      const taxSavedAnnual = Math.round(Math.min(s * 12, 150000) * 0.20);
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Years (Lock-in)`,
        rateLabel: '13.0% p.a. (Equity Tax Saver)',
        benefitText: `💰 Dual Advantage: Saves up to ₹${taxSavedAnnual.toLocaleString('en-IN')}/yr under Sec 80C while earning high equity growth with the shortest 3-year lock-in.`
      };
    }
    case 'savings': {
      const t = tenureYears || 1;
      const n = t * 12;
      const r = 0.035 / 12;
      const maturity = Math.round(s * ((Math.pow(1 + r, n) - 1) / r) * (1 + r));
      const invested = s * n;
      const gain = maturity - invested;
      return {
        invested,
        maturity,
        gain,
        tenureYears: t,
        tenureLabel: `${t} Year`,
        rateLabel: '3.5% p.a. (Liquid Savings)',
        benefitText: '💳 24/7 Total Liquidity: Withdraw anytime via UPI or ATM. Interest up to ₹10,000/yr is tax-free under Sec 80TTA.'
      };
    }
    default: {
      const t = tenureYears || 3;
      const invested = s * t * 12;
      const maturity = Math.round(invested * 1.25);
      return {
        invested,
        maturity,
        gain: maturity - invested,
        tenureYears: t,
        tenureLabel: `${t} Years`,
        rateLabel: '8.0% p.a.',
        benefitText: 'Balanced financial growth tailored to your monthly savings.'
      };
    }
  }
}

function renderSchemeSavingsCalculator(schemeKey, topicName) {
  const userSavings = getUserSavingsAmount();
  const tenureOptions = getSchemeTenureOptions(schemeKey);
  const defaultTenure = (tenureOptions.find(o => o.default) || tenureOptions[0]).years;
  const yieldData = calculateSchemeYield(schemeKey, userSavings, defaultTenure);

  return `
    <!-- "According to My Savings" Interactive Calculation Card -->
    <div class="user-savings-scheme-calc" id="user-savings-scheme-calc">
      <div class="scheme-calc-header">
        <div class="scheme-calc-title">
          <span class="calc-icon">⚡</span>
          <span class="calc-heading-text">According to My Savings</span>
        </div>
        <span class="calc-badge-gold">Interactive Yield Calculator</span>
      </div>

      <p class="scheme-calc-sub">
        Calculate how much you will get if you invest your monthly savings in <strong>${escHtml(topicName || 'this scheme')}</strong>:
      </p>

      <div class="scheme-calc-inputs-row">
        <div class="calc-field">
          <label class="calc-label">My Monthly Savings Amount:</label>
          <div class="calc-input-box">
            <span class="calc-curr-sym">₹</span>
            <input type="number" id="calc-savings-input" class="calc-num-input" min="100" step="500" value="${userSavings}" placeholder="5000" />
          </div>
        </div>

        <div class="calc-field">
          <label class="calc-label">Investment Duration:</label>
          <select id="calc-tenure-select" class="calc-tenure-dropdown">
            ${tenureOptions.map(opt => `<option value="${opt.years}" ${opt.years === defaultTenure ? 'selected' : ''}>${opt.label}</option>`).join('')}
          </select>
        </div>
      </div>

      <!-- Quick Savings Chips -->
      <div class="calc-quick-pills">
        <span class="pills-label">Quick select:</span>
        <button type="button" class="btn-calc-pill ${userSavings === 2000 ? 'active' : ''}" data-amt="2000">₹2,000/mo</button>
        <button type="button" class="btn-calc-pill ${userSavings === 5000 ? 'active' : ''}" data-amt="5000">₹5,000/mo</button>
        <button type="button" class="btn-calc-pill ${userSavings === 10000 ? 'active' : ''}" data-amt="10000">₹10,000/mo</button>
        <button type="button" class="btn-calc-pill ${userSavings === 25000 ? 'active' : ''}" data-amt="25000">₹25,000/mo</button>
        ${window.AppState?.userMonthlySavings ? `<button type="button" class="btn-calc-pill ${userSavings === Math.round(window.AppState.userMonthlySavings) ? 'active' : ''}" data-amt="${Math.round(window.AppState.userMonthlySavings)}">My Dashboard Savings (₹${Math.round(window.AppState.userMonthlySavings).toLocaleString('en-IN')})</button>` : ''}
      </div>

      <!-- Dynamic Output Grid -->
      <div class="calc-metrics-grid" id="calc-metrics-grid">
        <div class="calc-metric-card">
          <span class="calc-metric-label">Total You Invest</span>
          <span class="calc-metric-val" id="calc-val-invested">₹${yieldData.invested.toLocaleString('en-IN')}</span>
        </div>
        <div class="calc-metric-card highlight">
          <span class="calc-metric-label">Estimated Maturity</span>
          <span class="calc-metric-val" id="calc-val-maturity">₹${yieldData.maturity.toLocaleString('en-IN')}</span>
        </div>
        <div class="calc-metric-card calc-metric-gain">
          <span class="calc-metric-label">Net Wealth Gain</span>
          <span class="calc-metric-val" id="calc-val-gain">+₹${yieldData.gain.toLocaleString('en-IN')}</span>
        </div>
      </div>

      <!-- Scheme specific highlights & benefits -->
      <div class="calc-benefit-banner" id="calc-benefit-banner">
        ${yieldData.benefitText}
      </div>

      <!-- Listen to this Calculation Voice Action -->
      <div class="calc-listen-action">
        <button type="button" class="btn btn-secondary btn-sm" id="btn-listen-my-savings" title="Listen to According to My Savings plan">
          <span class="speaker-icon-lg">🔊</span> <span>Listen to "According to My Savings" Plan</span>
        </button>
      </div>
    </div>
  `;
}

function bindSavingsCalculator(schemeKey, topicName) {
  const container = document.getElementById('user-savings-scheme-calc');
  if (!container) return;

  const input = document.getElementById('calc-savings-input');
  const select = document.getElementById('calc-tenure-select');
  const banner = document.getElementById('calc-benefit-banner');
  const listenBtn = document.getElementById('btn-listen-my-savings');

  function updateCalcUI() {
    const s = Math.max(100, parseFloat(input.value) || 5000);
    const t = parseInt(select.value) || 3;
    const res = calculateSchemeYield(schemeKey, s, t);

    // Save to AppState and storage
    if (!window.AppState) window.AppState = {};
    window.AppState.userMonthlySavings = s;
    try { localStorage.setItem('clarifi_calc_savings', String(s)); } catch (_) {}

    const elInv = document.getElementById('calc-val-invested');
    const elMat = document.getElementById('calc-val-maturity');
    const elGain = document.getElementById('calc-val-gain');
    if (elInv) elInv.textContent = `₹${res.invested.toLocaleString('en-IN')}`;
    if (elMat) elMat.textContent = `₹${res.maturity.toLocaleString('en-IN')}`;
    if (elGain) elGain.textContent = `+₹${res.gain.toLocaleString('en-IN')}`;
    if (banner) banner.textContent = res.benefitText;

    // Refresh scheme grid previews if visible
    const gridPreview = document.querySelector(`.scheme-card[data-key="${schemeKey}"] .calc-preview-val strong`);
    if (gridPreview) {
      gridPreview.textContent = `₹${res.maturity.toLocaleString('en-IN')}`;
    }
  }

  if (input) {
    input.addEventListener('input', () => {
      container.querySelectorAll('.btn-calc-pill').forEach(b => b.classList.remove('active'));
      updateCalcUI();
    });
  }

  if (select) {
    select.addEventListener('change', updateCalcUI);
  }

  container.querySelectorAll('.btn-calc-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      container.querySelectorAll('.btn-calc-pill').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const amt = parseFloat(btn.dataset.amt);
      if (input && !isNaN(amt)) {
        input.value = amt;
        updateCalcUI();
      }
    });
  });

  if (listenBtn) {
    listenBtn.addEventListener('click', () => {
      const s = Math.max(100, parseFloat(input.value) || 5000);
      const t = parseInt(select.value) || 3;
      speakSavingsPlan(schemeKey, topicName, s, t);
    });
  }
}

function speakSavingsPlan(schemeKey, schemeName, monthlySavings, tenureYears) {
  const yieldData = calculateSchemeYield(schemeKey, monthlySavings, tenureYears);
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const s = monthlySavings;
  const t = yieldData.tenureYears;
  const inv = yieldData.invested.toLocaleString('en-IN');
  const mat = yieldData.maturity.toLocaleString('en-IN');
  const gain = yieldData.gain.toLocaleString('en-IN');

  const speechMap = {
    'en-IN': `According to your monthly savings of ₹${s.toLocaleString('en-IN')}, if you choose ${schemeName} for ${t} years: you will invest a total of ₹${inv}, and receive an estimated maturity amount of ₹${mat}, with a net wealth gain of ₹${gain}.`,
    'hi-IN': `आपकी ₹${s.toLocaleString('en-IN')} प्रति माह की बचत के अनुसार, यदि आप ${t} वर्षों के लिए ${schemeName} चुनते हैं: तो आपकी कुल जमा राशि ₹${inv} होगी, और आपको ₹${mat} की अनुमानित मैच्योरिटी राशि मिलेगी, जिससे ₹${gain} का शुद्ध लाभ होगा।`,
    'kn-IN': `ನಿಮ್ಮ ಪ್ರತಿ ತಿಂಗಳ ₹${s.toLocaleString('en-IN')} ಉಳಿತಾಯದ ಪ್ರಕಾರ, ನೀವು ${t} ವರ್ಷಗಳ ಕಾಲ ${schemeName} ಅನ್ನು ಆರಿಸಿದರೆ: ನಿಮ್ಮ ಒಟ್ಟು ಹೂಡಿಕೆ ₹${inv} ಆಗಿರುತ್ತದೆ, ಮತ್ತು ನಿಮಗೆ ಅಂದಾಜು ₹${mat} ಮುಕ್ತಾಯ ಮೊತ್ತ ಸಿಗುತ್ತದೆ, ಇದರಿಂದ ₹${gain} ನಿವ್ವಳ ಲಾಭ ದೊರೆಯುತ್ತದೆ.`,
    'te-IN': `మీ నెలవారీ ₹${s.toLocaleString('en-IN')} పొదుపు ప్రకారం, మీరు ${t} సంవత్సరాల పాటు ${schemeName} ఎంచుకుంటే: మీ మొత్తం పెట్టుబడి ₹${inv} అవుతుంది, మరియు మీకు సుమారుగా ₹${mat} మెచ్యూరిటీ మొత్తం లభిస్తుంది, దీని ద్వారా ₹${gain} నికర లాభం వస్తుంది.`
  };

  const textToSpeak = speechMap[lang] || speechMap['en-IN'];
  const btn = document.getElementById('btn-listen-my-savings');
  if (typeof window.speakText === 'function') {
    window.speakText(textToSpeak, lang, btn);
  } else {
    showToast('🔊 Audio synthesis currently active.', 'info');
  }
}

// ---------------------------------------------------------------------------
// Jargon Buster Data: Clear, Plain-Language Explanations of Financial Terms
// ---------------------------------------------------------------------------
const JARGON_BUSTER_DATA = {
  'en-IN': {
    title: '📖 Financial Words Decoded (Jargon Buster)',
    subtitle: 'Confused by financial terms? Here is what they mean in plain, everyday language:',
    items: [
      { term: '🔒 Lock-in Period', meaning: 'The minimum time your money must stay invested before you can take it out (e.g. 3 years for ELSS, 15 years for PPF).' },
      { term: '💧 Liquidity', meaning: 'How quickly and easily you can convert your investment back into spendable cash in your bank account.' },
      { term: '❄️ Compounding', meaning: 'Earning profit on top of your previous profits (interest on interest), like a snowball growing bigger as it rolls downhill.' },
      { term: '🏁 Maturity', meaning: 'The official completion date of your investment when all your money plus accumulated returns are paid back to you.' },
      { term: '🧾 Section 80C Tax Exemption', meaning: 'A government rule in India that reduces your taxable income by up to ₹1,50,000 each year when you invest in eligible schemes.' },
      { term: '⚖️ Investment Risk', meaning: 'The degree of short-term ups and downs in value in exchange for higher long-term wealth growth.' }
    ]
  },
  'hi-IN': {
    title: '📖 वित्तीय शब्दावली: आसान शब्दों में समझें (Jargon Buster)',
    subtitle: 'कठिन वित्तीय शब्दों का रोजमर्रा की भाषा में सीधा और सरल मतलब:',
    items: [
      { term: '🔒 लॉक-इन अवधि (Lock-in)', meaning: 'वह न्यूनतम समय जिसके दौरान आप अपना पैसा नहीं निकाल सकते (जैसे ELSS में 3 वर्ष, PPF में 15 वर्ष)।' },
      { term: '💧 तरलता (Liquidity)', meaning: 'आप अपने निवेश को कितनी जल्दी और आसानी से बैंक खाते में खर्च करने योग्य नकदी में बदल सकते हैं।' },
      { term: '❄️ चक्रवृद्धि ब्याज (Compounding)', meaning: 'कमाए हुए ब्याज पर भी ब्याज मिलना — जैसे बर्फ का गोला लुढ़कते हुए और बड़ा होता जाता है।' },
      { term: '🏁 परिपक्वता (Maturity)', meaning: 'योजना की अंतिम तारीख जब आपका पूरा जमा धन और कमाया हुआ मुनाफा आपको वापस मिलता है।' },
      { term: '🧾 धारा 80C टैक्स छूट', meaning: 'भारत सरकार का नियम जिसके तहत योग्य योजनाओं (PPF, ELSS) में निवेश करने पर ₹1.5 लाख तक की आय पर टैक्स बचता है।' },
      { term: '⚖️ निवेश जोखिम (Risk)', meaning: 'दीर्घकालिक वृद्धि की संभावना के बदले अल्पकालिक बाजार में मूल्यों का ऊपर-नीचे होना।' }
    ]
  },
  'kn-IN': {
    title: '📖 ಆರ್ಥಿಕ ಪದಕೋಶ: ಸರಳ ವಿವರಣೆ (Jargon Buster)',
    subtitle: 'ಕಠಿಣ ಹಣಕಾಸು ಪದಗಳ ದೈನಂದಿನ ಸರಳ ಅರ್ಥಗಳು:',
    items: [
      { term: '🔒 ಲಾಕ್-ಇನ್ ಅವಧಿ (Lock-in)', meaning: 'ಹಣವನ್ನು ಹಿಂಪಡೆಯುವ ಮೊದಲು ಕಡ್ಡಾಯವಾಗಿ ಹೂಡಿಕೆಯಲ್ಲಿ ಇಡಬೇಕಾದ ಕನಿಷ್ಠ ಸಮಯ (ಉದಾ. ELSS ಗೆ 3 ವರ್ಷ, PPF ಗೆ 15 ವರ್ಷ).' },
      { term: '💧 ನಗದು ಸೌಲಭ್ಯ (Liquidity)', meaning: 'ನಿಮ್ಮ ಹೂಡಿಕೆಯನ್ನು ಎಷ್ಟು ಬೇಗ ಮತ್ತು ಸುಲಭವಾಗಿ ನಿಮ್ಮ ಬ್ಯಾಂಕ್ ಖಾತೆಗೆ ನಗದಾಗಿ ಪಡೆಯಬಹುದು ಎಂಬುದು.' },
      { term: '❄️ ಚಕ್ರಬಡ್ಡಿ (Compounding)', meaning: 'ಅಸಲಿನ ಜೊತೆಗೆ ಈಗಾಗಲೇ ಬಂದ ಬಡ್ಡಿಯ ಮೇಲೂ ಮತ್ತಷ್ಟು ಬಡ್ಡಿ ಗಳಿಸುವುದು — ಹಿಮದ ಉಂಡೆಯಂತೆ ಬೆಳೆಯುವ ಸಂಪತ್ತು.' },
      { term: '🏁 ಮೆಚ್ಯೂರಿಟಿ (Maturity)', meaning: 'ಯೋಜನೆಯ ಅವಧಿ ಮುಗಿದು ನಿಮ್ಮ ಎಲ್ಲಾ ಹಣ ಮತ್ತು ಗಳಿಸಿದ ಲಾಭ ನಿಮ್ಮ ಕೈಸೇರುವ ಅಂತಿಮ ದಿನಾಂಕ.' },
      { term: '🧾 ಸೆಕ್ಷನ್ 80C ತೆರಿಗೆ ವಿನಾಯಿತಿ', meaning: 'ಅರ್ಹ ಯೋಜನೆಗಳಲ್ಲಿ (PPF, ELSS) ಹೂಡಿಕೆ ಮಾಡುವ ಮೂಲಕ ವಾರ್ಷಿಕ ₹1.5 ಲಕ್ಷದವರೆಗೆ ತೆರಿಗೆ ಉಳಿಸುವ ಭಾರತ ಸರ್ಕಾರದ ನಿಯಮ.' },
      { term: '⚖️ ಹೂಡಿಕೆ ಅಪಾಯ (Risk)', meaning: 'ದೀರ್ಘಾವಧಿಯ ಹೆಚ್ಚಿನ ಬೆಳವಣಿಗೆಯ ಜೊತೆಗೆ ಅಲ್ಪಾವಧಿಯಲ್ಲಿ ಮಾರುಕಟ್ಟೆ ಮೌಲ್ಯದಲ್ಲಿ ಆಗುವ ಏರಿಳಿತಗಳು.' }
    ]
  },
  'te-IN': {
    title: '📖 ఆర్థిక పదాల నిఘంటువు: సులభమైన అర్థాలు (Jargon Buster)',
    subtitle: 'క్లిష్టమైన ఆర్థిక పదాలకు రోజువారీ సులభమైన వివరణలు:',
    items: [
      { term: '🔒 లాక్-ఇన్ పీరియడ్ (Lock-in)', meaning: 'మీరు డబ్బును వెనక్కి తీసుకోకుండా పథకంలో ఉంచాల్సిన కనీస కాలం (ఉదాహరణకు ELSS కు 3 సంవత్సరాలు, PPF కు 15 సంవత్సరాలు).' },
      { term: '💧 లిక్విడిటీ (Liquidity)', meaning: 'మీ పెట్టుబడిని ఎంత త్వరగా, ఎంత సులభంగా మీ బ్యాంకు ఖాతాలో ఖర్చు చేయగల నగదుగా మార్చుకోవచ్చు అనేది.' },
      { term: '❄️ చక్రవడ్డీ (Compounding)', meaning: 'అసలుపై మాత్రమే కాకుండా, వచ్చిన వడ్డీపై కూడా మళ్లీ వడ్డీ రావడం — మంచు బంతి దొర్లుతూ పెరిగినట్లు సంపద పెరుగుతుంది.' },
      { term: '🏁 మెచ్యూరిటీ (Maturity)', meaning: 'మీ పెట్టుబడి పథకం ముగిసే తేదీ, అప్పుడు మీ పూర్తి అసలు మరియు వచ్చిన లాభం మీ ఖాతాకు చెల్లించబడతాయి.' },
      { term: '🧾 సెక్షన్ 80C పన్ను మినహాయింపు', meaning: 'అర్హతగల పథకాలలో (PPF, ELSS) పెట్టుబడి పెట్టి సంవత్సరానికి ₹1,50,000 వరకు పన్ను ఆదా చేసుకునే భారత ప్రభుత్వ నిబంధన.' },
      { term: '⚖️ పెట్టుబడి రిస్క్ (Risk)', meaning: 'దీర్ఘకాలిక అధిక రాబడి కోసం స్వల్పకాలంలో మార్కెట్ విలువలు పెరగడం లేదా తగ్గడం.' }
    ]
  }
};

function renderJargonBuster(lang) {
  const data = JARGON_BUSTER_DATA[lang] || JARGON_BUSTER_DATA['en-IN'];
  return `
    <div class="jargon-buster-card">
      <div class="jargon-buster-header">
        <span class="jargon-icon">💡</span>
        <div>
          <div class="jargon-title">${escHtml(data.title)}</div>
          <div class="jargon-sub">${escHtml(data.subtitle)}</div>
        </div>
      </div>
      <div class="jargon-grid">
        ${data.items.map(item => `
          <div class="jargon-item">
            <div class="jargon-term">${escHtml(item.term)}</div>
            <div class="jargon-meaning">${escHtml(item.meaning)}</div>
          </div>
        `).join('')}
      </div>
    </div>
  `;
}

// ---------------------------------------------------------------------------
// Render the full explanation card
// ---------------------------------------------------------------------------
function renderResult(d) {
  const container = document.getElementById('learn-result');
  if (!container) return;

  if (d.error) {
    container.innerHTML = `<div class="learn-error">⚠️ ${escHtml(d.summary)}</div>`;
    container.style.display = 'block';
    return;
  }

  const matchedSchemeKey = LearnState.currentTopicKey || detectSchemeKey(d.topic, LearnState.currentQuery);

  // Build comparison table rows HTML
  const tableRows = (d.comparison_table || []).map(row => `
    <tr>
      <td class="table-aspect">${escHtml(row.aspect)}</td>
      <td class="table-value">${escHtml(row.value)}</td>
    </tr>`).join('');

  // Related topics pills
  const relatedHtml = (d.related_topics || []).map(t => `
    <button class="related-pill" onclick="runExplain('Explain ${escHtml(t)}')">
      ${escHtml(t)}
    </button>`).join('');

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const labels = {
    'hi-IN': { what: '📌 यह क्या है?', how: '⚙️ यह कैसे काम करता है', glance: '📊 एक नज़र में', example: '🧮 उदाहरण', takeaway: '💡 मुख्य बात:', explore: '🔗 आगे जानें', note: '* सभी आंकड़े केवल सांकेतिक हैं। वास्तविक रिटर्न भिन्न हो सकते हैं।' },
    'kn-IN': { what: '📌 ಇದು ಏನು?', how: '⚙️ ಇದು ಹೇಗೆ ಕೆಲಸ ಮಾಡುತ್ತದೆ', glance: '📊 ಒಂದು ನೋಟದಲ್ಲಿ', example: '🧮 ಉದಾಹರಣೆ', takeaway: '💡 ಮುಖ್ಯ ಅಂಶ:', explore: '🔗 ಮುಂದಕ್ಕೆ ನೋಡಿ', note: '* ಎಲ್ಲಾ ಅಂಕಿಅಂಶಗಳು ಕೇವಲ ವಿವರಣಾತ್ಮಕವಾಗಿವೆ.' },
    'te-IN': { what: '📌 ఇది ఏమిటి?', how: '⚙️ ఇది ఎలా పనిచేస్తుంది', glance: '📊 ఒక చూపులో', example: '🧮 ఉదాహరణ', takeaway: '💡 ముఖ్యమైన విషయం:', explore: '🔗 తదుపరి అంశాలు', note: '* అన్ని సంఖ్యలు కేవలం ఉదాహరణ మాత్రమే.' },
    'en-IN': { what: '📌 What is it?', how: '⚙️ How it works', glance: '📊 At a glance', example: '🧮 Worked Example', takeaway: '💡 Key takeaway:', explore: '🔗 Explore next', note: '* All numbers are illustrative. Actual returns vary.' }
  }[lang] || { what: '📌 What is it?', how: '⚙️ How it works', glance: '📊 At a glance', example: '🧮 Worked Example', takeaway: '💡 Key takeaway:', explore: '🔗 Explore next', note: '* All numbers are illustrative. Actual returns vary.' };

  // Build the full card
  container.innerHTML = `
    <!-- Topic header -->
    <div class="result-header">
      <div class="result-topic">${escHtml(d.topic || '')}</div>
      <button class="btn btn-secondary btn-sm listen-btn" id="btn-listen-explain"
              onclick="listenToExplain()" title="Listen to this explanation">
        <span class="speaker-icon-lg">🔊</span> <span data-i18n="btn_listen">Listen</span>
      </button>
    </div>

    <!-- Summary -->
    <div class="result-section">
      <div class="result-section-label">${labels.what}</div>
      <p class="result-text">${escHtml(d.summary || '')}</p>
    </div>

    <!-- How it works -->
    ${d.how_it_works ? `
    <div class="result-section">
      <div class="result-section-label">${labels.how}</div>
      <p class="result-text">${escHtml(d.how_it_works)}</p>
    </div>` : ''}

    <!-- Comparison table -->
    ${tableRows ? `
    <div class="result-section">
      <div class="result-section-label">${labels.glance}</div>
      <div class="compare-table-wrap">
        <table class="compare-table">
          <tbody>${tableRows}</tbody>
        </table>
      </div>
    </div>` : ''}

    <!-- Worked example -->
    ${d.worked_example ? `
    <div class="result-section example-section">
      <div class="result-section-label">${labels.example}</div>
      <p class="result-text example-text">${escHtml(d.worked_example)}</p>
      <p class="illustrative-note">${labels.note}</p>
    </div>` : ''}

    <!-- "According to My Savings" Interactive Calculation Card -->
    ${renderSchemeSavingsCalculator(matchedSchemeKey, d.topic)}

    <!-- 💡 Financial Words Decoded (Jargon Buster) -->
    ${renderJargonBuster(lang)}

    <!-- Key takeaway -->
    ${d.key_takeaway ? `
    <div class="takeaway-card">
      <strong>${labels.takeaway}</strong> ${escHtml(d.key_takeaway)}
    </div>` : ''}

    <!-- Related topics -->
    ${relatedHtml ? `
    <div class="result-section">
      <div class="result-section-label">${labels.explore}</div>
      <div class="related-pills">${relatedHtml}</div>
    </div>` : ''}

    <!-- Financial compliance disclaimer (always shown) -->
    <div class="financial-note">
      ⚖️ ${escHtml(d.compliance_note || 'This is educational information. For personalised advice, consult a certified financial advisor.')}
    </div>
  `;

  container.style.display = 'block';

  // Bind the interactive savings calculator events
  bindSavingsCalculator(matchedSchemeKey, d.topic);
}

// ---------------------------------------------------------------------------
// "Listen" button — calls Gnani TTS via tts.js speakText()
// ---------------------------------------------------------------------------
function listenToExplain() {
  if (!LearnState.currentResult) return;
  const d = LearnState.currentResult;
  const lang = window.AppState?.currentLanguage || 'en-IN';

  // Build a natural spoken version (narrative parts in the chosen language)
  const spokenText = [
    d.topic ? `${d.topic}.` : '',
    d.summary        || '',
    d.how_it_works   || '',
    d.worked_example || '',
    d.key_takeaway   || '',
  ].filter(Boolean).join(' ');

  const btn = document.getElementById('btn-listen-explain');

  if (typeof window.speakText === 'function') {
    window.speakText(spokenText, lang, btn);
  } else {
    showToast('🔊 Audio unavailable right now.', 'info', 3000);
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function showLearnLoading(on) {
  const el = document.getElementById('learn-loading');
  if (el) el.style.display = on ? 'flex' : 'none';
  const btn = document.getElementById('btn-explain-submit');
  if (btn) btn.disabled = on;
}

function clearResult() {
  const el = document.getElementById('learn-result');
  if (el) { el.innerHTML = ''; el.style.display = 'none'; }
}

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// ---------------------------------------------------------------------------
// Expose globals
// ---------------------------------------------------------------------------
window.initLearn = initLearn;
window.runExplain = runExplain;
window.LearnState = LearnState;
window.loadTopicButtons = loadTopicButtons;
window.listenToExplain = listenToExplain;
window.renderSchemesGrid = renderSchemesGrid;
window.getUserSavingsAmount = getUserSavingsAmount;
window.calculateSchemeYield = calculateSchemeYield;
window.speakSavingsPlan = speakSavingsPlan;
window.bindSavingsCalculator = bindSavingsCalculator;
window.openSchemeAndSpeak = openSchemeAndSpeak;
