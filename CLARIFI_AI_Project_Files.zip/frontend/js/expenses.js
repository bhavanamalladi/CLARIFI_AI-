/**
 * CLARIFI AI — Expenses Module (expenses.js)  Phase 2
 *
 * Handles:
 *  - Sending confirmed transcript to /api/parse
 *  - Rendering parse result (entries saved / clarifying questions)
 *  - Expenses list: load, display, delete individual entries
 *  - Manual entry form
 *  - Delete all data button
 */

'use strict';

// ---------------------------------------------------------------------------
// Parse & Save — called from voice.js when user confirms transcript
// ---------------------------------------------------------------------------

async function parseAndSave(transcript) {
  const rawText = transcript.trim();
  const rawLower = rawText.toLowerCase();

  // 1. Check if we are answering a Goal Requirements Clarification (Amount or Time)
  if (window.AppState?.activeGoalClarification) {
    const goalState = window.AppState.activeGoalClarification;

    if (goalState.step === 'need_amount') {
      let extractedAmt = null;
      const lakhM = rawLower.match(/(\d+(?:\.\d+)?)\s*(?:lakh|lakhs|lac|lacs|लाख|ಲಕ್ಷ|లక్ష)/);
      if (lakhM) {
        extractedAmt = parseFloat(lakhM[1]) * 100000;
      } else {
        const kM = rawLower.match(/(\d+(?:\.\d+)?)\s*k\b/);
        if (kM) {
          extractedAmt = parseFloat(kM[1]) * 1000;
        } else {
          const numM = rawLower.match(/(\d+(?:,\d+)*(?:\.\d+)?)/);
          if (numM) extractedAmt = parseFloat(numM[1].replace(/,/g, ''));
        }
      }

      if (extractedAmt && extractedAmt > 0) {
        goalState.target_amount = extractedAmt;
        if (goalState.months) {
          // Both are ready!
          window.AppState.activeGoalClarification = null;
          return parseAndSave(`investment plan for ${goalState.goal_name} target ₹${extractedAmt} in ${goalState.months} months`);
        } else {
          // Next step: Need Time
          goalState.step = 'need_time';
          const isCar = (goalState.goal_name || '').toLowerCase().includes('car');
          const timePills = isCar
            ? ['1 Year (12 Mo)', '2 Years (24 Mo)', '3 Years (36 Mo)', '5 Years (60 Mo)']
            : ['3 Months', '6 Months', '12 Months (1 Year)', '24 Months (2 Years)', '36 Months (3 Years)'];
          const timeEg = isCar ? '1 year, 2 years, or 3 years' : '6 months, 1 year, 2 years';
          showGoalClarificationPrompt({
            step: 'need_time',
            goal_name: goalState.goal_name,
            target_amount: extractedAmt,
            question: `⏳ Target of ₹${extractedAmt.toLocaleString('en-IN')} for ${goalState.goal_name} noted! Over how many months or years would you like to achieve this? (e.g. ${timeEg})`,
            spoken_question: `Target of ${extractedAmt} rupees for ${goalState.goal_name} noted. Over how many months or years would you like to achieve this? For example, ${timeEg}?`,
            quick_options: timePills
          });
          return;
        }
      }
    } else if (goalState.step === 'need_time') {
      let extractedMonths = null;
      const yrM = rawLower.match(/(\d+)\s*(?:year|years|yr|yrs|साल|वर्ष|ವರ್ಷ|సంవత్సరాలు|సంవత్సరం)/);
      if (yrM) {
        extractedMonths = parseInt(yrM[1]) * 12;
      } else {
        const moM = rawLower.match(/(\d+)\s*(?:month|months|mo|mos|महीने|महीना|ತಿಂಗಳು|ನెలలు|నెల)/);
        if (moM) extractedMonths = parseInt(moM[1]);
      }

      if (extractedMonths && extractedMonths > 0) {
        goalState.months = extractedMonths;
        const targetAmt = goalState.target_amount || 50000;
        window.AppState.activeGoalClarification = null;
        return parseAndSave(`investment plan for ${goalState.goal_name} target ₹${targetAmt} in ${extractedMonths} months`);
      }
    }
  }

  // 2. Check if we are waiting for a mandatory category for a pending entry
  if (window.AppState?.pendingCategoryEntry) {
    const catMap = {
      food: ['food', 'lunch', 'dinner', 'swiggy', 'zomato', 'snack', 'tea', 'chai', 'coffee', 'खाना', 'ಊಟ', 'భోజనం'],
      transport: ['transport', 'travel', 'uber', 'ola', 'auto', 'metro', 'bus', 'petrol', 'fuel', 'cab', 'ऑटो', 'ಬಸ್', 'బస్సు'],
      rent: ['rent', 'room', 'flat', 'pg', 'किराया', 'ಬಾಡಿಗೆ', 'అద్దె'],
      shopping: ['shopping', 'clothes', 'amazon', 'flipkart', 'dress', 'shirt', 'shoes', 'खरीदारी', 'ಖರೀದಿ', 'షాపింగ్'],
      bills: ['bill', 'electricity', 'wifi', 'recharge', 'water', 'बिजली', 'ಕರೆಂಟ್', 'కరెంట్'],
      EMI: ['emi', 'loan', 'installment', 'credit card', 'ईएमआई', 'ಸಾಲ', 'రుణం'],
      other: ['other', 'misc', 'miscellaneous', 'अन्य']
    };
    for (const [catKey, kws] of Object.entries(catMap)) {
      if (kws.some(kw => rawLower.includes(kw))) {
        await savePendingWithCategory(catKey);
        return;
      }
    }
  }

  showLoading(true, 'Understanding your input…');
  try {
    const normalizedText = window.convertIndicNumbersInText ? window.convertIndicNumbersInText(transcript) : transcript;
    const res = await fetch('/api/parse', {
      method: 'POST',
      headers: (window.getAuthHeaders ? window.getAuthHeaders({ 'Content-Type': 'application/json' }) : { 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        transcript: normalizedText,
        language: window.AppState?.currentLanguage || 'en-IN',
      }),
    });

    if (!res.ok) throw new Error(`Server error ${res.status}`);
    const data = await res.json();
    handleParseResult(data, transcript);
  } catch (err) {
    console.error('[Expenses] parseAndSave error:', err);
    showToast('Could not process input. Please try again.', 'error');
  } finally {
    showLoading(false);
  }
}

function handleParseResult(data, originalTranscript) {
  const parsed = data.parsed;

  // --- 0. Plan Doubt: Answer questions about an active or created plan ---
  if (data.is_plan_doubt && data.plan_doubt) {
    renderPlanDoubtAnswerCard(data.plan_doubt);
    return;
  }

  // --- 1. Investment Plan: All requirements available -> Generate plan, auto-save to Goals, voice narration ---
  if (data.is_investment_plan && data.investment_plan) {
    window.AppState.activeGoalClarification = null;
    window.AppState.activeGoalPlan = data.investment_plan;
    renderInvestmentPlanCard(data.investment_plan);
    if (typeof window.loadGoals === 'function') {
      window.loadGoals();
    }
    if (typeof window.loadDashGoalsPreview === 'function') {
      window.loadDashGoalsPreview();
    }
    showToast('✅ Investment plan created & saved to Goals!', 'success', 3000);
    return;
  }

  // --- 2. Goal Clarification: Ask for Amount or Time requirements with Voice & interactive pills ---
  if (data.is_goal_clarification && data.goal_clarification) {
    window.AppState = window.AppState || {};
    window.AppState.activeGoalClarification = data.goal_clarification;
    showGoalClarificationPrompt(data.goal_clarification);
    return;
  }

  // --- 3. Mandatory Category Required: Prompt user with category pills before saving ---
  if (data.needs_category && data.pending_entry) {
    window.AppState = window.AppState || {};
    window.AppState.pendingCategoryEntry = data.pending_entry;
    showCategoryChoicePrompt(data.pending_entry);
    return;
  }

  // --- 4. Clarifying questions: show them, don't save yet ---
  if (parsed.questions && parsed.questions.length > 0) {
    showParseQuestions(parsed.questions);
    return;
  }

  // --- 5. Product / Scheme question: automatically open Schemes page and speak voice ---
  if (data.is_product_question) {
    const topic = data.product_topic || parsed.raw_intent.replace('product_question:', '').trim();
    const schemeKey = data.scheme_key || 'sip';
    showToast(`🏛️ Opening ${topic} Scheme…`, 'info', 2000);
    if (typeof window.openSchemeAndSpeak === 'function') {
      window.openSchemeAndSpeak(schemeKey, topic, originalTranscript);
    } else {
      if (typeof window.showSection === 'function') window.showSection('learn');
      if (typeof window.runExplain === 'function') {
        window.runExplain(originalTranscript || `Explain ${topic}`, schemeKey, true);
      }
    }
    return;
  }

  // --- 6. Investment advice redirect ---
  if (data.is_advice_request) {
    showToast('Redirecting you to the product explainer — we can compare options there!', 'info', 2000);
    setTimeout(() => window.showSection('learn'), 800);
    return;
  }

  // --- 7. Entries saved (Category was explicitly mentioned) ---
  if (data.saved_count > 0) {
    showToast(`✅ Saved ${data.saved_count} entr${data.saved_count === 1 ? 'y' : 'ies'}!`, 'success', 2500);
    const quickInput = document.getElementById('expenses-quick-input');
    if (quickInput) quickInput.value = '';
    const dashInput = document.getElementById('dash-quick-input');
    if (dashInput) dashInput.value = '';

    // Audio voice confirmation in preferred language
    speakEntrySavedConfirmation(data);

    // Live feedback in Expenses Co-Pilot panel / Dashboard
    const feedbackEl = getTargetFeedbackContainer();
    if (feedbackEl) {
      feedbackEl.innerHTML = `
        <div class="live-saved-alert">
          <div class="live-saved-header">
            <span class="live-saved-icon">✨</span>
            <div>
              <strong>Saved ${data.saved_count} entr${data.saved_count === 1 ? 'y' : 'ies'} to your records!</strong>
              <div class="live-saved-sub">Watch your live dashboard and ledger update ←</div>
            </div>
          </div>
        </div>
      `;
      feedbackEl.style.display = 'block';
      setTimeout(() => {
        if (feedbackEl.innerHTML.includes('live-saved-alert')) {
          feedbackEl.style.display = 'none';
        }
      }, 5000);
    }

    if (typeof loadTransactions === 'function') loadTransactions();
    if (typeof loadDashboard === 'function') loadDashboard();
    if (typeof loadDashRecentPreview === 'function') loadDashRecentPreview();
    if (typeof loadDashGoalsPreview === 'function') loadDashGoalsPreview();
  } else if (parsed.entries && parsed.entries.length === 0) {
    const lang = window.AppState?.currentLanguage || 'en-IN';
    showToast("I didn't find any amounts in that. Try: 'I spent ₹500 on food'", 'warning', 2500);
    speakNoAmountGuidance(lang);
  }
}

function speakEntrySavedConfirmation(data) {
  if (typeof window.speakText !== 'function') return;
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const entries = data.parsed?.entries || [];

  let textToSpeak = '';
  if (entries.length === 1) {
    const entry = entries[0];
    const amt = Number(entry.amount).toLocaleString('en-IN');
    const cat = entry.category || 'expense';
    const isIncome = entry.type === 'income';

    if (lang === 'hi-IN') {
      textToSpeak = isIncome
        ? `आपके डैशबोर्ड में ${amt} रुपये की आय दर्ज कर ली गई है।`
        : `आपके डैशबोर्ड में ${cat} के लिए ${amt} रुपये का खर्च दर्ज कर लिया गया है।`;
    } else if (lang === 'kn-IN') {
      textToSpeak = isIncome
        ? `ನಿಮ್ಮ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ${amt} ರೂಪಾಯಿ ಆದಾಯವನ್ನು ಸೇವ್ ಮಾಡಲಾಗಿದೆ.`
        : `ನಿಮ್ಮ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ${cat} ಗಾಗಿ ${amt} ರೂಪಾಯಿ ಖರ್ಚು ಸೇವ್ ಮಾಡಲಾಗಿದೆ.`;
    } else if (lang === 'te-IN') {
      textToSpeak = isIncome
        ? `మీ డాష్‌బోర్డ్‌లో ${amt} రూపాయల ఆదాయం రికార్డ్ చేయబడింది.`
        : `మీ డాష్‌బోర్డ్‌లో ${cat} కోసం ${amt} రూపాయల ఖర్చు సేవ్ చేయబడింది.`;
    } else {
      textToSpeak = isIncome
        ? `Recorded ₹${amt} income to your dashboard.`
        : `Saved ₹${amt} for ${cat} to your dashboard.`;
    }
  } else {
    const count = data.saved_count || entries.length;
    if (lang === 'hi-IN') {
      textToSpeak = `आपके डैशबोर्ड में ${count} लेन-देन सफलतापूर्वक जोड़ दिए गए हैं।`;
    } else if (lang === 'kn-IN') {
      textToSpeak = `ನಿಮ್ಮ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ${count} ವಹಿವಾಟುಗಳನ್ನು ಸೇವ್ ಮಾಡಲಾಗಿದೆ.`;
    } else if (lang === 'te-IN') {
      textToSpeak = `మీ డాష్‌బోర్డ్‌లో ${count} లావాదేవీలు సేవ్ చేయబడ్డాయి.`;
    } else {
      textToSpeak = `Successfully saved ${count} entries to your dashboard.`;
    }
  }

  window.speakText(textToSpeak, lang);
}

function speakNoAmountGuidance(lang) {
  if (typeof window.speakText !== 'function') return;
  let text = '';
  if (lang === 'hi-IN') {
    text = 'मुझे कोई राशि नहीं मिली। कृपया राशि और श्रेणी बताएं, जैसे: मैंने खाने पर 500 रुपये खर्च किए।';
  } else if (lang === 'kn-IN') {
    text = 'ಯಾವುದೇ ಮೊತ್ತ ಕಂಡುಬಂದಿಲ್ಲ. ದಯವಿಟ್ಟು ಮೊತ್ತ ಮತ್ತು ವರ್ಗವನ್ನು ತಿಳಿಸಿ, ಉದಾಹರಣೆಗೆ: ನಾನು ಊಟಕ್ಕೆ 500 ರೂಪಾಯಿ ಖರ್ಚು ಮಾಡಿದೆ.';
  } else if (lang === 'te-IN') {
    text = 'ఎలాంటి మొత్తం కనిపించలేదు. దయచేసి మొత్తం మరియు వర్గాన్ని చెప్పండి, ఉదాహరణకు: నేను భోజనానికి 500 రూపాయలు ఖర్చు చేశాను.';
  } else {
    text = "I couldn't find any amounts. Please say the amount and category, like: I spent 500 rupees on food.";
  }
  window.speakText(text, lang);
}

// ---------------------------------------------------------------------------
// Helper: Resolve the active feedback container based on visible view
// ---------------------------------------------------------------------------
function getTargetFeedbackContainer() {
  const isExp = document.getElementById('section-expenses')?.classList.contains('active');
  const isDash = document.getElementById('section-dashboard')?.classList.contains('active');

  if (isExp) {
    const expEl = document.getElementById('expenses-ai-feedback');
    if (expEl) return expEl;
  }
  if (isDash) {
    const dashEl = document.getElementById('dash-response-card');
    if (dashEl) return dashEl;
  }
  return document.getElementById('expenses-ai-feedback')
    || document.getElementById('voice-response-card')
    || document.getElementById('dash-response-card')
    || document.getElementById('parse-questions');
}

// ---------------------------------------------------------------------------
// Goal Requirements Clarification Prompt (Asks with Voice & Quick Pills)
// ---------------------------------------------------------------------------
function showGoalClarificationPrompt(clarification) {
  const container = getTargetFeedbackContainer();
  if (!container) return;

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const isAmount = clarification.step === 'need_amount';
  const badgeTitle = isAmount ? '🎯 TARGET AMOUNT REQUIRED' : '⏳ TIMELINE REQUIRED';

  container.innerHTML = `
    <div class="goal-clarification-card">
      <div class="goal-clarification-header">
        <span class="clarification-badge">${badgeTitle}</span>
        <div class="goal-target-name">${escHtml(clarification.goal_name)}</div>
      </div>

      <div class="clarification-question-box">
        <div class="question-text">🤔 ${escHtml(clarification.question)}</div>
        <button type="button" class="btn btn-ghost btn-sm btn-replay-question" title="Listen to question">
          <span class="speaker-icon-lg">🔊</span> <span>Listen</span>
        </button>
      </div>

      <p class="clarification-instruction">Tap an option below, speak, or type your answer:</p>

      <div class="goal-options-pills">
        ${(clarification.quick_options || []).map(opt => `
          <button type="button" class="btn-goal-pill" data-val="${escHtml(opt)}">
            ${escHtml(opt)}
          </button>
        `).join('')}
      </div>
    </div>
  `;
  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Auto-speak the question with voice so the user hears it immediately
  if (typeof window.speakText === 'function' && clarification.spoken_question) {
    const replayBtn = container.querySelector('.btn-replay-question');
    window.speakText(clarification.spoken_question, lang, replayBtn);
    replayBtn?.addEventListener('click', () => {
      window.speakText(clarification.spoken_question, lang, replayBtn);
    });
  }

  // Bind clicks on option pills
  container.querySelectorAll('.btn-goal-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      const val = btn.dataset.val;
      parseAndSave(val);
    });
  });
}

// ---------------------------------------------------------------------------
// Render Investment Plan Card in Voice / Talk with Money response area
// ---------------------------------------------------------------------------
function renderInvestmentPlanCard(plan) {
  const container = getTargetFeedbackContainer();
  if (!container) return;

  const lang = window.AppState?.currentLanguage || 'en-IN';
  window.AppState.activeGoalPlan = plan;
  const targetFormatted = Number(plan.target_amount).toLocaleString('en-IN');
  const monthlyFormatted = Number(plan.monthly_saving).toLocaleString('en-IN');

  const m12 = Math.round(plan.monthly_saving * Math.min(12, plan.months));
  const m24 = Math.round(plan.monthly_saving * Math.min(24, plan.months));

  container.innerHTML = `
    <div class="investment-plan-result-card">
      <div class="plan-badge">🎯 SMART INVESTMENT &amp; SAVINGS PLAN</div>
      <h3 class="plan-goal-title">${escHtml(plan.goal_name)}</h3>
      
      <div class="plan-metrics-grid">
        <div class="plan-metric-box">
          <div class="metric-label">Target Amount</div>
          <div class="metric-value">₹${targetFormatted}</div>
        </div>
        <div class="plan-metric-box">
          <div class="metric-label">Timeline</div>
          <div class="metric-value">${plan.months} Months</div>
        </div>
        <div class="plan-metric-box highlight">
          <div class="metric-label">Required Monthly Saving</div>
          <div class="metric-value">₹${monthlyFormatted} / mo</div>
        </div>
      </div>

      <div class="plan-strategy-box">
        <div class="strategy-badge">📈 ${escHtml(plan.strategy_title)}</div>
        <p class="strategy-text">${escHtml(plan.strategy_desc)}</p>
      </div>

      <!-- Step-by-Step Milestones Roadmap -->
      <div class="plan-milestones-box">
        <div class="plan-milestones-title">📅 Step-by-Step Milestones Roadmap</div>
        <div class="plan-milestones-list">
          <div class="plan-milestone-row">
            <span>Year 1 Accumulation (Month 12):</span>
            <strong>₹${m12.toLocaleString('en-IN')}</strong>
          </div>
          ${plan.months > 12 ? `
          <div class="plan-milestone-row">
            <span>Year 2 Accumulation (Month 24):</span>
            <strong>₹${m24.toLocaleString('en-IN')}</strong>
          </div>` : ''}
          <div class="plan-milestone-row">
            <span>Full Target at Month ${plan.months}:</span>
            <strong style="color:var(--color-accent)">₹${targetFormatted} 🎉</strong>
          </div>
        </div>
      </div>

      <div class="plan-auto-saved-badge">
        ✅ <strong>Saved to Goals:</strong> This goal has been automatically created &amp; updated in your Goals dashboard.
      </div>

      <!-- Doubts Prompt Box: Ask through Talk with Money -->
      <div class="plan-doubts-prompt-box">
        <div class="plan-doubts-heading">💬 Have Doubts About This Plan?</div>
        <p class="plan-doubts-sub">Ask through Talk with Money (tap below, speak into mic, or type):</p>
        <div class="plan-doubt-pills-row">
          <button type="button" class="btn-plan-doubt-pill" data-doubt="How did you calculate this plan?">
            ❓ How is this calculated?
          </button>
          <button type="button" class="btn-plan-doubt-pill" data-doubt="Can I reach this goal faster?">
            ⚡ Can I reach faster?
          </button>
          <button type="button" class="btn-plan-doubt-pill" data-doubt="Is a car loan better than saving?">
            🚗 Loan vs Saving?
          </button>
          <button type="button" class="btn-plan-doubt-pill" data-doubt="What if the market drops?">
            🛡️ Is my money safe?
          </button>
          <button type="button" class="btn-plan-doubt-pill" data-doubt="What if I can only save less money?">
            💰 What if I save less?
          </button>
        </div>
      </div>

      <div class="plan-actions-row" style="margin-top:16px;">
        <button type="button" class="btn btn-primary btn-listen-plan" id="btn-listen-voice-plan">
          <span class="speaker-icon-lg">🔊</span> <span>Listen to Plan</span>
        </button>
        <button type="button" class="btn btn-secondary btn-sm" onclick="window.showSection('goals')">
          🎯 Open Goals Dashboard
        </button>
      </div>

      <div class="financial-disclaimer-sm">
        ⚖️ Educational model only. Consult a financial advisor before investing.
      </div>
    </div>
  `;
  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Bind Listen button to speak the plan, and auto-narrate with voice
  const listenBtn = document.getElementById('btn-listen-voice-plan');
  if (listenBtn && typeof window.speakText === 'function') {
    listenBtn.addEventListener('click', () => {
      window.speakText(plan.spoken_summary, lang, listenBtn);
    });
    // Automatically narrate plan on arrival
    setTimeout(() => {
      window.speakText(plan.spoken_summary, lang, listenBtn);
    }, 400);
  }

  // Bind doubt pills
  container.querySelectorAll('.btn-plan-doubt-pill').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.dataset.doubt;
      parseAndSave(q);
    });
  });
}

// ---------------------------------------------------------------------------
// Render Plan Doubt Answer Card in Talk with Money response area
// ---------------------------------------------------------------------------
function renderPlanDoubtAnswerCard(doubt) {
  const container = getTargetFeedbackContainer();
  if (!container) return;

  const lang = window.AppState?.currentLanguage || 'en-IN';

  container.innerHTML = `
    <div class="plan-doubt-answer-card">
      <div class="plan-doubt-badge">💡 CLARIFI PLAN ADVISOR • DOUBT RESOLVED</div>
      <h3 class="plan-doubt-title">${escHtml(doubt.title)}</h3>

      <div class="plan-doubt-points">
        ${(doubt.points || []).map(p => `
          <div class="plan-doubt-point">
            <span class="point-bullet">✓</span>
            <div class="point-text">${escHtml(p).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</div>
          </div>
        `).join('')}
      </div>

      <div class="plan-doubt-actions">
        <button type="button" class="btn btn-primary btn-sm btn-listen-doubt" id="btn-listen-doubt">
          <span class="speaker-icon-lg">🔊</span> <span>Listen to Explanation</span>
        </button>
        ${window.AppState?.activeGoalPlan ? `
          <button type="button" class="btn btn-ghost btn-sm btn-reopen-plan" id="btn-reopen-plan">
            🎯 View Plan Summary
          </button>
        ` : ''}
      </div>

      <div class="plan-doubt-chips-label">More questions you can ask:</div>
      <div class="plan-doubt-chips">
        ${(doubt.quick_doubt_chips || []).map(chip => `
          <button type="button" class="btn-doubt-chip" data-query="${escHtml(chip)}">
            ${escHtml(chip)}
          </button>
        `).join('')}
      </div>

      <div class="financial-disclaimer-sm">
        ⚖️ Educational model only. Consult a financial advisor before investing.
      </div>
    </div>
  `;
  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Bind listen button
  const listenBtn = document.getElementById('btn-listen-doubt');
  if (listenBtn && typeof window.speakText === 'function') {
    listenBtn.addEventListener('click', () => {
      window.speakText(doubt.spoken, lang, listenBtn);
    });
    // Auto-speak answer
    setTimeout(() => {
      window.speakText(doubt.spoken, lang, listenBtn);
    }, 350);
  }

  // Bind reopen plan
  document.getElementById('btn-reopen-plan')?.addEventListener('click', () => {
    if (window.AppState?.activeGoalPlan) {
      renderInvestmentPlanCard(window.AppState.activeGoalPlan);
    }
  });

  // Bind chips
  container.querySelectorAll('.btn-doubt-chip').forEach(btn => {
    btn.addEventListener('click', () => {
      const q = btn.dataset.query;
      parseAndSave(q);
    });
  });
}

// ---------------------------------------------------------------------------
// Mandatory Category Choice Prompt
// ---------------------------------------------------------------------------
function showCategoryChoicePrompt(pending) {
  const container = getTargetFeedbackContainer();
  if (!container) return;

  const amtFormatted = Number(pending.amount).toLocaleString('en-IN');

  container.innerHTML = `
    <div class="mandatory-category-card">
      <div class="mandatory-header">
        <span class="mandatory-icon">⚠️</span>
        <div>
          <div class="mandatory-title">Field / Category is Mandatory</div>
          <div class="mandatory-subtitle">Which category does this <strong>₹${amtFormatted}</strong> ${pending.type} belong to?</div>
        </div>
      </div>
      
      <p class="mandatory-desc">Please choose a category below before it can be added to your expenses dashboard:</p>

      <div class="category-choice-pills">
        <button type="button" class="btn-cat-choice" data-cat="food">🍛 Food</button>
        <button type="button" class="btn-cat-choice" data-cat="transport">🚇 Transport</button>
        <button type="button" class="btn-cat-choice" data-cat="rent">🏠 Rent</button>
        <button type="button" class="btn-cat-choice" data-cat="shopping">🛍️ Shopping</button>
        <button type="button" class="btn-cat-choice" data-cat="bills">📱 Bills</button>
        <button type="button" class="btn-cat-choice" data-cat="EMI">💳 EMI</button>
        <button type="button" class="btn-cat-choice" data-cat="other">📦 Other</button>
      </div>
    </div>
  `;
  container.style.display = 'block';
  container.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

  // Bind clicks
  container.querySelectorAll('.btn-cat-choice').forEach(btn => {
    btn.addEventListener('click', async () => {
      const chosenCat = btn.dataset.cat;
      await savePendingWithCategory(chosenCat);
    });
  });

  // Speak category question in user's preferred language
  const lang = window.AppState?.currentLanguage || 'en-IN';
  if (typeof window.speakText === 'function') {
    let catVoicePrompt = '';
    if (lang === 'hi-IN') {
      catVoicePrompt = `यह ${amtFormatted} रुपये का खर्च किस श्रेणी का है? कृपया खाना, यात्रा या बिल जैसी श्रेणी चुनें।`;
    } else if (lang === 'kn-IN') {
      catVoicePrompt = `ಈ ${amtFormatted} ರೂಪಾಯಿ ಯಾವ ವರ್ಗಕ್ಕೆ ಸೇರಿದೆ? ದಯವಿಟ್ಟು ಊಟ, ಪ್ರಯಾಣ ಅಥವಾ ಬಿಲ್‌ನಂತಹ ವರ್ಗವನ್ನು ಆಯ್ಕೆಮಾಡಿ.`;
    } else if (lang === 'te-IN') {
      catVoicePrompt = `ఈ ${amtFormatted} రూపాయలు ఏ వర్గానికి చెందినవి? దయచేసి భోజనం, ప్రయాణం లేదా బిల్లుల వంటి వర్గాన్ని ఎంచుకోండి.`;
    } else {
      catVoicePrompt = `Which category does this ${amtFormatted} rupees belong to? Please choose a category like food, transport, or bills.`;
    }
    window.speakText(catVoicePrompt, lang);
  }
}

// ---------------------------------------------------------------------------
// Save Pending Entry once Category is Chosen
// ---------------------------------------------------------------------------
async function savePendingWithCategory(category) {
  const pending = window.AppState?.pendingCategoryEntry;
  if (!pending) return;

  showLoading(true, `Saving ₹${pending.amount} to ${category}…`);
  try {
    const res = await fetch('/api/transactions', {
      method: 'POST',
      headers: (window.getAuthHeaders ? window.getAuthHeaders({ 'Content-Type': 'application/json' }) : { 'Content-Type': 'application/json' }),
      body: JSON.stringify({
        type: pending.type || 'expense',
        amount: parseFloat(pending.amount),
        category: category,
        description: pending.description || category,
        date: new Date().toISOString().split('T')[0],
      }),
    });

    if (!res.ok) throw new Error('Failed to save transaction');
    
    // Clear pending
    window.AppState.pendingCategoryEntry = null;

    // Update feedback container
    const container = getTargetFeedbackContainer();
    if (container) {
      container.innerHTML = `
        <div class="success-saved-card">
          ✅ <strong>Success!</strong> Added ₹${Number(pending.amount).toLocaleString('en-IN')} under <strong>${category}</strong> to your live dashboard.
        </div>
      `;
      setTimeout(() => { container.style.display = 'none'; }, 4000);
    }

    showToast(`✅ Saved ₹${pending.amount} to ${category} in Dashboard!`, 'success', 2500);

    // Speak audio confirmation in preferred language
    if (typeof window.speakText === 'function') {
      const lang = window.AppState?.currentLanguage || 'en-IN';
      const amt = Number(pending.amount).toLocaleString('en-IN');
      let confirmVoice = '';
      if (lang === 'hi-IN') {
        confirmVoice = `डैशबोर्ड में ${category} के तहत ${amt} रुपये दर्ज कर लिए गए हैं।`;
      } else if (lang === 'kn-IN') {
        confirmVoice = `ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ನಲ್ಲಿ ${category} ಅಡಿಯಲ್ಲಿ ${amt} ರೂಪಾಯಿ ಸೇವ್ ಮಾಡಲಾಗಿದೆ.`;
      } else if (lang === 'te-IN') {
        confirmVoice = `డాష్‌బోర్డ్‌లో ${category} కింద ${amt} రూపాయలు సేವ್ చేయబడింది.`;
      } else {
        confirmVoice = `Saved ₹${amt} under ${category} to your dashboard.`;
      }
      window.speakText(confirmVoice, lang);
    }

    if (typeof loadTransactions === 'function') loadTransactions();
    if (typeof loadDashboard === 'function') loadDashboard();
    if (typeof loadDashRecentPreview === 'function') loadDashRecentPreview();
    if (typeof loadDashGoalsPreview === 'function') loadDashGoalsPreview();
  } catch (err) {
    console.error('[Expenses] savePendingWithCategory error:', err);
    showToast('Failed to save transaction. Please try again.', 'error');
  } finally {
    showLoading(false);
  }
}

function showParseQuestions(questions) {
  const container = document.getElementById('voice-response-card') || document.getElementById('parse-questions');
  if (!container) return;
  container.innerHTML = questions.map(q =>
    `<div class="question-bubble">🤔 ${q}</div>`
  ).join('');
  container.style.display = 'block';
  // Auto-hide after 10s
  setTimeout(() => { container.style.display = 'none'; }, 10000);
}

// ---------------------------------------------------------------------------
// Load & Render transactions list
// ---------------------------------------------------------------------------

async function loadTransactions(filterType = null) {
  const list = document.getElementById('tx-list');
  if (!list) return;

  list.innerHTML = '<div class="tx-loading">Loading…</div>';

  try {
    const now = new Date();
    const params = new URLSearchParams({
      month: now.getMonth() + 1,
      year:  now.getFullYear(),
      limit: 100,
    });
    if (filterType) params.set('type', filterType);

    const res = await fetch(`/api/transactions?${params}`, {
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (!res.ok) throw new Error(`${res.status}`);
    const txs = await res.json();

    renderTransactionList(list, txs);
  } catch (err) {
    console.error('[Expenses] loadTransactions error:', err);
    list.innerHTML = '<div class="tx-empty">Could not load transactions.</div>';
  }
}

function renderTransactionList(container, txs) {
  const lang = window.AppState?.currentLanguage || 'en-IN';
  const dict = window.TRANSLATIONS?.[lang] || window.TRANSLATIONS?.['en-IN'] || {};

  // Compute live monthly totals for the Expenses Co-Pilot Banner
  let totalIncome = 0;
  let totalSpent  = 0;
  (txs || []).forEach(tx => {
    const amt = parseFloat(tx.amount) || 0;
    if (tx.type === 'income') totalIncome += amt;
    else totalSpent += amt;
  });
  const netSurplus = totalIncome - totalSpent;

  const incEl   = document.getElementById('exp-total-income');
  const spentEl = document.getElementById('exp-total-spent');
  const netEl   = document.getElementById('exp-total-net');
  const countEl = document.getElementById('ledger-count');

  if (incEl)   incEl.textContent   = `+₹${totalIncome.toLocaleString('en-IN')}`;
  if (spentEl) spentEl.textContent = `−₹${totalSpent.toLocaleString('en-IN')}`;
  if (netEl) {
    netEl.textContent = `${netSurplus >= 0 ? '+' : '−'}₹${Math.abs(netSurplus).toLocaleString('en-IN')}`;
    netEl.style.color = netSurplus >= 0 ? 'var(--color-success)' : 'var(--color-accent)';
  }
  if (countEl) countEl.textContent = `${(txs || []).length}`;

  if (!txs || txs.length === 0) {
    container.innerHTML = `
      <div class="tx-empty">
        <div style="font-size:2rem;margin-bottom:8px;">💸</div>
        <p>${dict['tx_empty_title'] || 'No entries this month yet.'}</p>
        <p style="font-size:0.8rem;color:var(--color-text-dim)">
          ${dict['tx_empty_sub'] || 'Use the mic on the right or type to add your income &amp; expenses.'}
        </p>
      </div>`;
    return;
  }

  // Group by date
  const grouped = {};
  txs.forEach(tx => {
    const d = tx.date || 'Unknown';
    if (!grouped[d]) grouped[d] = [];
    grouped[d].push(tx);
  });

  container.innerHTML = Object.entries(grouped)
    .sort(([a], [b]) => b.localeCompare(a))
    .map(([dateStr, entries]) => `
      <div class="tx-date-group">
        <div class="tx-date-label">${formatDate(dateStr)}</div>
        ${entries.map(tx => renderTxCard(tx)).join('')}
      </div>`)
    .join('');

  // Bind delete buttons
  container.querySelectorAll('.btn-delete-tx').forEach(btn => {
    btn.addEventListener('click', () => deleteTransaction(parseInt(btn.dataset.id)));
  });
}

function renderTxCard(tx) {
  const isIncome = tx.type === 'income';
  const icon = CATEGORY_ICONS[tx.category] || (isIncome ? '💰' : '💸');
  const sign = isIncome ? '+' : '−';
  const cls  = isIncome ? 'tx-income' : 'tx-expense';

  const lang = window.AppState?.currentLanguage || 'en-IN';
  const dict = window.TRANSLATIONS?.[lang] || window.TRANSLATIONS?.['en-IN'] || {};
  const catNames = {
    food: dict['cat_food'] || 'Food',
    rent: dict['cat_rent'] || 'Rent',
    transport: dict['cat_transport'] || 'Transport',
    shopping: dict['cat_shopping'] || 'Shopping',
    bills: dict['cat_bills'] || 'Bills',
    EMI: dict['cat_emi'] || 'EMI',
    other: dict['cat_other'] || 'Other',
    income: dict['opt_income'] || 'Income',
    expense: dict['opt_expense'] || 'Expense'
  };

  const metaLabel = tx.category ? (catNames[tx.category] || tx.category) : (isIncome ? (dict['opt_income'] || 'Income') : (dict['opt_expense'] || 'Expense'));

  return `
    <div class="tx-card ${cls}" data-id="${tx.id}">
      <div class="tx-icon">${icon}</div>
      <div class="tx-info">
        <div class="tx-desc">${tx.description || metaLabel}</div>
        <div class="tx-meta">${metaLabel}</div>
      </div>
      <div class="tx-right">
        <div class="tx-amount">${sign}₹${tx.amount.toLocaleString('en-IN')}</div>
        <button class="btn-icon btn-delete-tx" data-id="${tx.id}" title="Delete">🗑️</button>
      </div>
    </div>`;
}

const CATEGORY_ICONS = {
  rent: '🏠', food: '🍛', transport: '🚌', shopping: '🛍️',
  bills: '💡', EMI: '🏦', other: '📦',
};

function formatDate(dateStr) {
  if (!dateStr || dateStr === 'Unknown') return 'Unknown date';
  try {
    const d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short' });
  } catch { return dateStr; }
}

// ---------------------------------------------------------------------------
// Delete one transaction
// ---------------------------------------------------------------------------

async function deleteTransaction(txId) {
  if (!confirm('Delete this entry?')) return;
  try {
    const res = await fetch(`/api/transactions/${txId}`, {
      method: 'DELETE',
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (res.ok || res.status === 204) {
      showToast('Entry deleted', 'info', 2000);
      loadTransactions();
    } else {
      showToast('Could not delete entry', 'error');
    }
  } catch (err) {
    showToast('Could not delete entry', 'error');
  }
}

// ---------------------------------------------------------------------------
// Seed Demo Data
// ---------------------------------------------------------------------------

async function seedDemoData() {
  showLoading(true, 'Seeding sample data…');
  try {
    const res = await fetch('/api/seed', { method: 'POST' });
    if (res.ok) {
      showToast('✨ Demo data loaded successfully!', 'success');
      loadTransactions();
      if (typeof window.loadDashboard === 'function') window.loadDashboard();
      if (typeof window.loadGoals === 'function') window.loadGoals();
    } else {
      showToast('Failed to seed demo data', 'error');
    }
  } catch (err) {
    showToast('Error seeding demo data', 'error');
  } finally {
    showLoading(false);
  }
}

// ---------------------------------------------------------------------------
// Delete ALL data
// ---------------------------------------------------------------------------

async function deleteAllData() {
  if (!confirm('⚠️ This will permanently delete ALL your income, expense, and goal data. Are you sure?')) return;
  if (!confirm('This cannot be undone. Delete everything?')) return;

  try {
    const res = await fetch('/api/data', {
      method: 'DELETE',
      headers: (window.getAuthHeaders ? window.getAuthHeaders() : {}),
    });
    if (res.ok) {
      showToast('All your data has been deleted.', 'success');
      loadTransactions();
    } else {
      showToast('Could not delete data. Please try again.', 'error');
    }
  } catch (err) {
    showToast('Could not delete data.', 'error');
  }
}

// ---------------------------------------------------------------------------
// Manual entry form
// ---------------------------------------------------------------------------

function initManualForm() {
  const form      = document.getElementById('manual-entry-form');
  const typeSelect = document.getElementById('me-type');
  const catWrap   = document.getElementById('me-category-wrap');

  if (!form) return;

  // Show/hide category based on type
  typeSelect?.addEventListener('change', () => {
    catWrap.style.display = typeSelect.value === 'expense' ? 'block' : 'none';
  });

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const type     = document.getElementById('me-type').value;
    const amount   = parseFloat(document.getElementById('me-amount').value);
    const category = type === 'expense' ? document.getElementById('me-category').value : null;
    const desc     = document.getElementById('me-desc').value.trim();
    const dateVal  = document.getElementById('me-date').value || new Date().toISOString().split('T')[0];

    if (!amount || amount <= 0) { showToast('Please enter a valid amount', 'warning'); return; }

    try {
      const res = await fetch('/api/transactions', {
        method: 'POST',
        headers: (window.getAuthHeaders ? window.getAuthHeaders({ 'Content-Type': 'application/json' }) : { 'Content-Type': 'application/json' }),
        body: JSON.stringify({ type, amount, category, description: desc, date: dateVal }),
      });
      if (!res.ok) throw new Error(await res.text());
      showToast(`${type === 'income' ? 'Income' : 'Expense'} of ₹${amount.toLocaleString('en-IN')} saved!`, 'success');
      form.reset();
      catWrap.style.display = 'block'; // reset
      loadTransactions();
    } catch (err) {
      console.error('[Expenses] manual create error:', err);
      showToast('Could not save entry. Check the form.', 'error');
    }
  });
}

// ---------------------------------------------------------------------------
// Filter tabs (All / Income / Expense)
// ---------------------------------------------------------------------------

function initFilterTabs() {
  document.querySelectorAll('.tx-filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tx-filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      loadTransactions(btn.dataset.filter || null);
    });
  });
}

// ---------------------------------------------------------------------------
// Init — called by app.js when section becomes active
// ---------------------------------------------------------------------------

function initExpenses() {
  initManualForm();
  initFilterTabs();
  initExpensesCoPilot();
  loadTransactions();

  document.getElementById('btn-delete-all-data')?.addEventListener('click', deleteAllData);
}

// ---------------------------------------------------------------------------
// Expenses Live Co-Pilot (Talk with Money in Right Panel)
// ---------------------------------------------------------------------------
function initExpensesCoPilot() {
  const quickForm   = document.getElementById('expenses-quick-form');
  const quickInput  = document.getElementById('expenses-quick-input');
  const expMicBtn   = document.getElementById('expenses-mic-btn');

  // Fast text submission
  if (quickForm && quickInput && !quickForm._bound) {
    quickForm._bound = true;
    quickForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const text = quickInput.value.trim();
      if (!text) {
        showToast('Please type an expense or income (e.g. Spent ₹450 on food)', 'warning', 2500);
        return;
      }
      parseAndSave(text);
    });
  }

  // Voice Mic button inside right panel
  if (expMicBtn && !expMicBtn._bound) {
    expMicBtn._bound = true;
    expMicBtn.addEventListener('click', async () => {
      if (typeof window.isRecording === 'function' && window.isRecording()) {
        if (typeof window.stopRecording === 'function') window.stopRecording();
      } else {
        window._recordingFromExpenses = true;
        if (typeof window.startRecording === 'function') {
          await window.startRecording();
        } else {
          showToast('Voice service is loading…', 'info');
        }
      }
    });
  }

  // Quick Suggestion Chips (1-tap to add or ask)
  document.querySelectorAll('.btn-side-chip').forEach(btn => {
    if (!btn._bound) {
      btn._bound = true;
      btn.addEventListener('click', () => {
        const text = btn.dataset.text || btn.textContent.trim();
        if (quickInput) quickInput.value = text;
        parseAndSave(text);
      });
    }
  });

  // Mobile Screen View Toggle (<860px)
  document.querySelectorAll('.btn-exp-toggle').forEach(btn => {
    if (!btn._bound) {
      btn._bound = true;
      btn.addEventListener('click', () => {
        document.querySelectorAll('.btn-exp-toggle').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const pane = btn.dataset.pane;
        const ledgerPanel  = document.getElementById('expenses-ledger-panel');
        const copilotPanel = document.getElementById('expenses-assistant-panel');
        if (pane === 'ledger') {
          ledgerPanel?.classList.remove('mobile-hide');
          copilotPanel?.classList.add('mobile-hide');
        } else {
          copilotPanel?.classList.remove('mobile-hide');
          ledgerPanel?.classList.add('mobile-hide');
        }
      });
    }
  });
}

// ---------------------------------------------------------------------------
// Expose globals
// ---------------------------------------------------------------------------
window.parseAndSave   = parseAndSave;
window.initExpenses   = initExpenses;
window.loadTransactions = loadTransactions;
window.seedDemoData   = seedDemoData;
