# CLARIFI AI 🎙️ — 2-Minute Hackathon Demo Script

> **Setting:** Gnani AI Hackathon Pitch / Live Showcase  
> **Speaker Role:** Founder / Lead Developer presenting to judges  
> **Target Audience:** First-time earners in India (students, first-job salary earners)

---

## ⏱️ Video / Live Demo Timeline

```
[00:00 - 00:20] Hook & The Problem
[00:20 - 00:45] Feature 1: "Talk to Your Money" (Voice + Multilingual STT)
[00:45 - 01:10] Feature 2: Visual Financial Intelligence (Dashboard & Emergency Fund)
[01:10 - 01:35] Feature 3: Product Explainer + Audio Readout (Gnani Timbre TTS)
[01:35 - 01:50] Feature 4: Deterministic Goal Planning
[01:50 - 02:00] Conclusion & Compliance
```

---

### [00:00 - 00:20] Hook & Problem
*(Show the mobile app landing page at http://localhost:8000)*
> *"Over 10 million young Indians enter the workforce every year. But when their first salary credit SMS arrives, they are faced with anxiety, complex financial jargon, and confusing budgeting apps.  
> Meet **CLARIFI AI** — India's first voice-first personal finance mentor designed specifically for first-time earners. Powered by Gnani's Vachana Speech APIs, you don't type or navigate menus — you simply talk to your money in your mother tongue."*

---

### [00:20 - 00:45] Feature 1: Talk to Your Money
*(Tap the language selector, pick Hindi or Kannada, tap the microphone button 🎤)*
> *"Let's test this live. Watch the audio visualizer pulse as I speak naturally in code-mixed Hindi:"*
> 
> **Speaker says:** *"Maine aaj rent ke baarah hazaar rupaye aur Blinkit pe pandrah sau rupaye kharch kiye."*
>
> *(Transcript appears instantly via Gnani Prisma STT v3)*
> *"Gnani's Prisma model transcribes Indic speech with zero lag. I tap **Confirm** — Claude extracts the transactions with strict JSON validation, categorizes Rent and Food, and updates our local database."*

---

### [00:45 - 01:10] Feature 2: Financial Intelligence & Dashboard
*(Tap on the **📊 Dashboard** tab)*
> *"Instead of cluttered spreadsheets, CLARIFI gives first-time earners clear visual metrics:
> 1. Monthly income, expenses, and a color-coded **Savings Rate**.
> 2. An interactive **Spending Breakdown donut chart** drawn on canvas without bloated libraries.
> 3. An **EMI Debt Alert** — warning users when loan obligations cross the safe 40% income threshold.
> 4. And our **Emergency Fund Tracker** — showing exactly how close they are to a 6-month safety net."*

---

### [01:10 - 01:35] Feature 3: Financial Explainer with Gnani Timbre TTS
*(Switch to the **📚 Learn** tab and tap **Fixed Deposit (FD)** or **SIP**)*
> *"Young earners are bombarded with unsolicited investment advice. CLARIFI replaces noise with clean, unbiased financial literacy.
> Look at this comparison table: risk profile, liquidity, tax treatment, and a step-by-step worked ₹ example.
> Best of all, voice isn't decorative in CLARIFI — every single explanation has a **Listen** button powered by **Gnani Timbre TTS**."*
>
> *(Tap **🔊 Listen** — voice plays in natural Indian accent)*
> *"Notice that? High quality speech in natural Indian accent, cached locally so it loads instantly on replay."*

---

### [01:35 - 01:50] Feature 4: Deterministic Goal Planner
*(Switch to the **🎯 Goals** tab. Show Goal: 'Two-Wheeler EV' — ₹50,000 in 6 months)*
> *"Next: Goal Planning. Unlike chatbots that hallucinate numbers, CLARIFI calculates savings with **100% deterministic Python math**.
> It evaluates your real monthly surplus, tells you whether your goal is feasible, calculates the exact shortfall or buffer, and maps your time horizon to standard financial instruments."*

---

### [01:50 - 02:00] Safety, Compliance & Closing
*(Point to the persistent Amber Disclaimer banner and 'Delete All Data' button in Expenses)*
> *"Safety is built into our core:
> - Educational only — we never recommend specific stocks or funds.
> - Strict certified financial advisor redirects.
> - Zero bank credentials required, and a 1-tap **Delete My Data** button keeps user privacy supreme.
> 
> CLARIFI AI: Turning first paychecks into generational financial confidence with the power of Gnani Voice. Thank you!"*

---

## 💡 Quick Demo Tips for Judges
1. **Pre-seed Demo Data:** Tap the **✨ Load Demo Data** button in the Expenses tab before beginning to populate 3 months of rich dashboard history!
2. **Audio Check:** Test laptop speakers before playing the **🔊 Listen** button.
3. **Language Showcase:** Switch to **ಕನ್ನಡ** (Kannada) or **తెలుగు** (Telugu) to show regional voice capabilities.
