@echo off
setlocal EnableDelayedExpansion

echo.
echo =========================================
echo   CLARIFI AI - Setup and Start
echo =========================================
echo.

REM --- Find Python executable ---
set "PYTHON_EXE="

if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" (
    set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python312;%LOCALAPPDATA%\Programs\Python\Python312\Scripts;%PATH%"
    goto :FoundPython
)

if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" (
    set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python311;%LOCALAPPDATA%\Programs\Python\Python311\Scripts;%PATH%"
    goto :FoundPython
)

if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" (
    set "PYTHON_EXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
    set "PATH=%LOCALAPPDATA%\Programs\Python\Python310;%LOCALAPPDATA%\Programs\Python\Python310\Scripts;%PATH%"
    goto :FoundPython
)

py -3 -V >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_EXE=py -3"
    goto :FoundPython
)

python -c "import sys; print(sys.version)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_EXE=python"
    goto :FoundPython
)

echo ERROR: Python 3.10+ was not found on your system.
echo Please install Python from https://www.python.org/downloads/
echo Make sure to check Add Python to PATH during installation.
pause
exit /b 1

:FoundPython
echo [OK] Using Python: !PYTHON_EXE!
echo.

REM --- Create .env if missing ---
if not exist .env (
    if exist .env.example (
        copy .env.example .env >nul
    ) else (
        echo GNANI_API_KEY=your_key_here>.env
        echo ANTHROPIC_API_KEY=your_key_here>>.env
    )
    echo Created .env configuration file.
    echo Opening Notepad - please add your API keys then close Notepad.
    start /wait notepad .env
)

REM --- Create venv if missing ---
if not exist "venv\Scripts\python.exe" (
    echo [*] Creating virtual environment venv...
    !PYTHON_EXE! -m venv venv
    if errorlevel 1 (
        echo ERROR: Failed to create venv.
        pause
        exit /b 1
    )
    echo [OK] Virtual environment created.
)

REM --- Install dependencies ---
echo [*] Checking dependencies...
call venv\Scripts\pip.exe install -r requirements.txt --quiet
if errorlevel 1 (
    echo Retrying pip install...
    call venv\Scripts\pip.exe install -r requirements.txt
)

REM --- Auto seed demo data if clarifi.db is missing ---
if not exist "clarifi.db" (
    echo [*] Seeding initial demo data...
    call venv\Scripts\python.exe seed_demo_data.py
)

REM --- Start server ---
echo.
echo ===========================================================
echo  CLARIFI AI is running!
echo  Open your browser at: http://localhost:8000
echo  API Docs:             http://localhost:8000/api/docs
echo ===========================================================
echo.
echo Press Ctrl+C to stop the server.
echo.

call venv\Scripts\uvicorn.exe backend.main:app --host 0.0.0.0 --port 8000 --reload
pause
