@echo off
title CLARIFI AI - Push to GitHub
cd /d "%~dp0"
echo ===================================================
echo   CLARIFI AI - Automated Push to GitHub Repository
echo   Repo: https://github.com/bhavanamalladi/CLARIFI_AI
echo ===================================================
echo.

where git >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Git command was not found in this terminal.
    echo If Git is installed, please run this from "Git Bash" or your normal PowerShell.
    echo Alternatively, you can drag and drop the files directly on GitHub:
    echo https://github.com/bhavanamalladi/CLARIFI_AI
    pause
    exit /b 1
)

echo [1/5] Initializing Git repository...
if not exist ".git" (
    git init
    git branch -M main
)

echo [2/5] Setting remote repository origin...
git remote remove origin >nul 2>nul
git remote add origin https://github.com/bhavanamalladi/CLARIFI_AI.git

echo [3/5] Staging project files (respecting .gitignore)...
git add -A

echo [4/5] Creating commit...
git commit -m "feat: Initial release of CLARIFI AI - Voice-First Multilingual Financial Co-Pilot"

echo [5/5] Pushing to GitHub (main branch)...
echo.
git push -u origin main

if %ERRORLEVEL% equ 0 (
    echo.
    echo ===================================================
    echo   SUCCESS! All project files are pushed to GitHub:
    echo   https://github.com/bhavanamalladi/CLARIFI_AI
    echo ===================================================
) else (
    echo.
    echo [NOTE] If GitHub rejected the push because the repo contains a README or license:
    echo Running rebase and pushing again...
    git pull --rebase origin main
    git push -u origin main
)

pause
