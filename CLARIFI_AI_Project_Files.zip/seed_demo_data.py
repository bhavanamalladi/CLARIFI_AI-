"""
CLARIFI AI — Demo Data Seeder (Phase 7)

Populates realistic financial data for a first-job earner in Bengaluru/India:
- Salary: ₹45,000 / month
- Expenses: Rent (₹12,000), Food/Groceries (₹6,500), Transport (₹2,200),
  Shopping (₹3,000), Bills (₹1,800), EMI (₹4,500 for laptop loan)
- Savings Goals: Emergency Fund (₹1,50,000 in 12 mos), Goa Trip (₹25,000 in 5 mos)
- Emergency Fund Target: 6 months

Run with:
  python seed_demo_data.py
"""

import sys
import os
from datetime import date, timedelta

# Ensure project root is in path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from backend.database import SessionLocal, create_tables
from backend.models import User, Transaction, Goal, EmergencyFundTarget

def seed():
    create_tables()
    db = SessionLocal()
    try:
        # 1. Ensure user
        user = db.get(User, 1)
        if not user:
            user = User(id=1, name="Aarav Sharma", language_preference="en-IN")
            db.add(user)
        else:
            user.name = "Aarav Sharma"
        db.commit()

        # Clean existing demo transactions & goals to ensure a clean slate
        db.query(Transaction).filter(Transaction.user_id == 1).delete()
        db.query(Goal).filter(Goal.user_id == 1).delete()
        db.query(EmergencyFundTarget).filter(EmergencyFundTarget.user_id == 1).delete()
        db.commit()

        today = date.today()
        # Dates for current month and previous month
        d_today = today
        d_prev1 = today - timedelta(days=28)
        d_prev2 = today - timedelta(days=58)

        demo_transactions = [
            # --- Current Month (Month 0) ---
            Transaction(user_id=1, type="income", amount=45000.0, category=None, description="Monthly Salary - Tech Corp", date=d_today.replace(day=1)),
            Transaction(user_id=1, type="expense", amount=12000.0, category="rent", description="1BHK Rent HSR Layout", date=d_today.replace(day=2)),
            Transaction(user_id=1, type="expense", amount=4500.0, category="EMI", description="Laptop No-Cost EMI", date=d_today.replace(day=5)),
            Transaction(user_id=1, type="expense", amount=3500.0, category="food", description="Blinkit & Zepto Groceries", date=d_today.replace(day=7)),
            Transaction(user_id=1, type="expense", amount=2800.0, category="food", description="Weekend Dining & Swiggy", date=d_today.replace(day=10)),
            Transaction(user_id=1, type="expense", amount=2200.0, category="transport", description="Namma Metro & Auto", date=d_today.replace(day=12)),
            Transaction(user_id=1, type="expense", amount=1800.0, category="bills", description="Wifi & Electricity Bill", date=d_today.replace(day=14)),
            Transaction(user_id=1, type="expense", amount=3200.0, category="shopping", description="Myntra Winter Clothing", date=d_today.replace(day=15)),

            # --- Previous Month (Month -1) ---
            Transaction(user_id=1, type="income", amount=45000.0, category=None, description="Monthly Salary - Tech Corp", date=d_prev1.replace(day=1)),
            Transaction(user_id=1, type="expense", amount=12000.0, category="rent", description="1BHK Rent HSR Layout", date=d_prev1.replace(day=2)),
            Transaction(user_id=1, type="expense", amount=4500.0, category="EMI", description="Laptop No-Cost EMI", date=d_prev1.replace(day=5)),
            Transaction(user_id=1, type="expense", amount=6200.0, category="food", description="Groceries & Dining", date=d_prev1.replace(day=10)),
            Transaction(user_id=1, type="expense", amount=2400.0, category="transport", description="Metro & Cabs", date=d_prev1.replace(day=15)),
            Transaction(user_id=1, type="expense", amount=1900.0, category="bills", description="Utility Bills", date=d_prev1.replace(day=18)),

            # --- Month -2 ---
            Transaction(user_id=1, type="income", amount=42000.0, category=None, description="Salary (Before Appraisal)", date=d_prev2.replace(day=1)),
            Transaction(user_id=1, type="expense", amount=12000.0, category="rent", description="1BHK Rent HSR Layout", date=d_prev2.replace(day=2)),
            Transaction(user_id=1, type="expense", amount=4500.0, category="EMI", description="Laptop No-Cost EMI", date=d_prev2.replace(day=5)),
            Transaction(user_id=1, type="expense", amount=5800.0, category="food", description="Groceries & Meals", date=d_prev2.replace(day=12)),
            Transaction(user_id=1, type="expense", amount=2100.0, category="transport", description="Transport Pass", date=d_prev2.replace(day=16)),
        ]

        db.add_all(demo_transactions)

        # 2. Add Goals
        goals = [
            Goal(user_id=1, name="Emergency Safety Cushion", target_amount=150000.0, months=12),
            Goal(user_id=1, name="Goa Vacation with College Friends", target_amount=25000.0, months=4),
            Goal(user_id=1, name="Two-Wheeler EV Down Payment", target_amount=50000.0, months=8),
        ]
        db.add_all(goals)

        # 3. Add Emergency Fund Target (6 months default)
        ef = EmergencyFundTarget(user_id=1, months_target=6)
        db.add(ef)

        db.commit()
        print("✅ Demo data seeded successfully!")
        print(f"   - Added {len(demo_transactions)} transactions across 3 months")
        print(f"   - Added {len(goals)} financial goals")
        print("   - Set Emergency Fund target to 6 months")

    except Exception as e:
        print(f"❌ Error seeding data: {e}")
        db.rollback()
    finally:
        db.close()

if __name__ == "__main__":
    seed()
