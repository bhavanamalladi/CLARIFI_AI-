# CLARIFI AI 🎙️
### Voice-First Personal Finance Learning & Money-Management App for First-Time Earners in India
*Built for the Gnani AI Hackathon — Voice is Central, Not Decorative.*

---

## 🌟 Highlights
- 🎙️ **Voice-First Input**: Speak in **Kannada (ಕನ್ನಡ)**, **Telugu (తెలుగు)**, **Hindi (हिंदी)**, or **English** with code-mixing support.
- ⚡ **Gnani Vachana STT**: Transcribed using the official **Prisma v3.0 REST API** (`POST https://api.vachana.ai/stt/v3`).
- 🔊 **Gnani Vachana TTS**: Natural speech playback using the **Timbre v2.5 REST API** (`POST https://api.vachana.ai/api/v1/tts/inference`), with SQLite audio caching for efficiency.
- 🤖 **Structured AI Parsing**: Anthropic Claude extracts income/expense entries into strict validated JSON schemas and asks clarifying questions for ambiguous inputs.
- 📊 **Visual Financial Intelligence**: Dashboard with savings rate, canvas-rendered spending breakdown donut chart, EMI debt alerts, and emergency fund safety tracker.
- 📚 **Financial Product Explainer**: Unbiased comparison tables (FD, RD, SIP, Mutual Funds, PPF, NPS, ELSS) with worked ₹ examples and audio narration.
- 🎯 **Deterministic Goal Planner**: 100% deterministic Python math (no LLM hallucinated calculations) to evaluate goal feasibility against actual monthly cash surplus.
- 🛡️ **Safety & Financial Compliance**: Prominent educational disclaimers, zero return guarantees, automatic redirection to certified financial advisors, local-first storage, and a 1-tap "Delete My Data" privacy button.

---

## 🏗️ Architecture & Tech Stack

```
clarifi-ai/
├── backend/
│   ├── main.py                  # FastAPI server, lifespan, CORS, static mounts
│   ├── config.py                # Pydantic Settings (.env loader)
│   ├── database.py              # SQLite engine + SessionLocal
│   ├── models.py                # SQLAlchemy ORM (User, Transaction, Goal, AudioCache, etc.)
│   ├── schemas.py               # Pydantic request/response schemas
│   ├── routers/
│   │   ├── health.py            # Health check endpoint
│   │   ├── voice.py             # STT endpoint (Gnani Prisma v3)
│   │   ├── parse.py             # LLM parsing pipeline (Claude)
│   │   ├── transactions.py      # Expense/Income CRUD & Demo Seeder
│   │   ├── dashboard.py         # Summary metrics & Emergency fund
│   │   ├── explainer.py         # Financial literacy comparison tables
│   │   ├── goals.py             # Deterministic goal planner
│   │   └── tts.py               # TTS streaming & voice metadata
│   └── services/
│       ├── gnani_stt.py         # Gnani Prisma STT v3 multipart client
│       ├── gnani_tts.py         # Gnani Timbre TTS v2.5 client + DB cache
│       ├── claude_parser.py     # Claude JSON schema parser with guardrails
│       ├── transactions.py      # Transaction business logic & deletion
│       ├── dashboard.py         # Deterministic financial analytics
│       ├── explainer.py         # Educational product explainer
│       └── goals.py             # Horizon & surplus math
├── frontend/
│   ├── index.html               # Mobile-first responsive single page app
│   ├── css/style.css            # Dark indigo + Saffron theme, responsive rules
│   └── js/
│       ├── app.js               # State, routing, toasts, loading overlay
│       ├── voice.js             # MediaRecorder API + canvas visualizer
│       ├── tts.js               # Web Audio player & local playback cache
│       ├── expenses.js          # Transaction list, manual entry & demo seeder
│       ├── dashboard.js         # Donut chart & financial health meters
│       ├── learn.js             # Topic pills, comparison tables, speech readout
│       └── goals.js             # Goal calculator & time horizon recommendations
├── seed_demo_data.py            # Standalone demo data seeder script
├── DEMO_SCRIPT.md               # 2-minute hackathon pitch script
├── requirements.txt             # Backend dependencies
├── start.bat                    # One-click Windows runner
└── .env.example                 # Environment template
```

---

## ⚡ Quick Start (Windows / Mac / Linux)

### 1. Prerequisites
- **Python 3.10+**
- **Gnani API Key**: [dashboard.gnani.ai](https://dashboard.gnani.ai)
- **Anthropic API Key**: [console.anthropic.com](https://console.anthropic.com)

### 2. Configure Environment
```bash
# In the project directory:
copy .env.example .env     # Windows
# or: cp .env.example .env # Mac/Linux
```
Open `.env` and fill in your keys:
```env
GNANI_API_KEY=your_gnani_api_key_here
ANTHROPIC_API_KEY=your_anthropic_api_key_here
```

### 3. Install & Launch

#### Option A: One-Click (Windows)
Double click `start.bat` or run:
```cmd
start.bat
```

#### Option B: Manual Terminal
```bash
# Create and activate virtual environment
python -m venv venv
venv\Scripts\activate      # Windows
# source venv/bin/activate # Mac/Linux

# Install dependencies
pip install -r requirements.txt

# Start FastAPI server
uvicorn backend.main:app --reload --port 8000
```

Open your browser to: **http://localhost:8000**  
Interactive API Docs (Swagger): **http://localhost:8000/api/docs**

---

## 🎯 Testing Each Phase (Cheat Sheet)

### 1. Load Demo Data
Go to the **💸 Expenses** tab and tap **✨ Load Demo Data** (or execute `python seed_demo_data.py`). This populates 3 months of salary, rent, food, bills, EMI, and goal records.

### 2. Voice Input (STT)
1. In the **🏠 Home** tab, select your preferred language pill: **ಕನ್ನಡ**, **తెలుగు**, **हिंदी**, or **English**.
2. Tap the large 🎤 button and speak:  
   *"I spent ₹350 on petrol today"* or *"Maine ₹1500 grocery pe kharch kiye"*.
3. Tap ⏹ to stop — Gnani Prisma transcribes your speech.
4. Tap **✓ Confirm** to have Claude parse and store the transaction automatically!

### 3. Financial Intelligence Dashboard
1. Switch to the **📊 Dashboard** tab.
2. View Monthly Income, Total Spent, Net Savings, and Savings Rate percentage.
3. Inspect the **Spending Breakdown** donut chart.
4. Check the **EMI Debt Alert** (warns if EMI exceeds 40% of income).
5. Adjust the **Emergency Fund target** (e.g., 3 to 6 months) and see the progress meter update dynamically.

### 4. Financial Product Explainer (Learn)
1. Switch to the **📚 Learn** tab.
2. Tap quick pills like **Fixed Deposit**, **SIP**, **PPF**, or **NPS**, or type a custom query.
3. Review the plain-language summary, comparison table (risk, liquidity, lock-in, taxation), and illustrative worked example.
4. Click **🔊 Listen** to hear the audio synthesized via **Gnani Timbre TTS** in natural voice!

### 5. Deterministic Goal Planner
1. Switch to the **🎯 Goals** tab.
2. Enter: Goal: `Laptop Upgrade`, Target: `₹60,000`, Months: `6`.
3. Notice the live preview calculation (`≈ ₹10,000 / month needed`).
4. Click **Calculate Plan** to see feasibility based on your real cash surplus, recommended financial instruments, and horizon guidance.
5. Click **🔊 Listen to this plan** to hear audio summary.

### 6. Safety & Compliance Verification
- **Disclaimer**: Permanent amber notice on every page: *"Educational information only — not investment advice. Consult a certified financial advisor."*
- **Advice Guardrail**: Ask *"Where should I invest my money?"* — the AI redirects to educational options and advises consulting a certified financial advisor.
- **Privacy**: Tap **🗑️ Delete all my data** in the Expenses tab to permanently wipe all stored SQLite records.

---

## 📡 Gnani API Reference Implemented

### 1. Speech-to-Text (STT) — Prisma v3.0
- **Endpoint**: `POST https://api.vachana.ai/stt/v3`
- **Headers**: `X-API-Key-ID: <GNANI_API_KEY>`
- **Body (`multipart/form-data`)**:
  - `audio_file`: Binary recording (`.webm`, `.wav`)
  - `model`: `"prisma-v3.0"`
  - `language_code`: `"kn-IN" | "te-IN" | "hi-IN" | "en-IN" | "indic-auto"`

### 2. Text-to-Speech (TTS) — Timbre v2.5
- **Endpoint**: `POST https://api.vachana.ai/api/v1/tts/inference`
- **Headers**: `X-API-Key-ID: <GNANI_API_KEY>`, `Content-Type: application/json`
- **Body (`application/json`)**:
  ```json
  {
    "text": "Fixed Deposit offers capital safety with fixed returns.",
    "model": "timbre-v2.5",
    "voice": "Nalini",
    "language": "en-IN",
    "audio_config": {
      "encoding": "linear_pcm",
      "container": "wav",
      "sample_rate": 48000,
      "num_channels": 1,
      "sample_width": 2
    }
  }
  ```

---

## ⚖️ License & Hackathon Notice
Created for the **Gnani AI Hackathon**.  
Educational tool only — not a registered investment advisor. No financial guarantees provided.
