import asyncio
import httpx
from backend.config import settings

async def main():
    print("API Key prefix:", settings.gnani_api_key[:15] if settings.gnani_api_key else "None")
    # Generate 1 second of silence in 16kHz WAV PCM 16-bit
    import struct
    sample_rate = 16000
    num_samples = sample_rate * 1
    raw_pcm = b'\x00\x00' * num_samples
    
    # 44 byte WAV header
    header = struct.pack(
        '<4sI4s4sIHHIIHH4sI',
        b'RIFF',
        36 + len(raw_pcm),
        b'WAVE',
        b'fmt ',
        16,
        1, # PCM
        1, # Mono
        sample_rate,
        sample_rate * 2,
        2, # Block align
        16, # Bits per sample
        b'data',
        len(raw_pcm)
    )
    wav_bytes = header + raw_pcm

    headers = {"X-API-Key-ID": settings.gnani_api_key}
    files = {"audio_file": ("test.wav", wav_bytes, "audio/wav")}
    data = {"model": "prisma-v3.0", "language_code": "en-IN"}

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post("https://api.vachana.ai/stt/v3", headers=headers, files=files, data=data)
        print("Status:", resp.status_code)
        print("Response:", resp.text)

if __name__ == "__main__":
    asyncio.run(main())
