import os
import time
from playwright.sync_api import sync_playwright

def run_demo():
    output_dir = os.path.abspath(r"C:\Users\bhava\.gemini\antigravity\scratch\clarifi-ai\frontend\recordings")
    os.makedirs(output_dir, exist_ok=True)
    
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            record_video_dir=output_dir,
            record_video_size={"width": 1280, "height": 720},
            viewport={"width": 1280, "height": 720}
        )
        page = context.new_page()
        
        print("[Demo] Navigating to http://127.0.0.1:8000/ ...")
        page.goto("http://127.0.0.1:8000/", wait_until="networkidle")
        time.sleep(2)
        
        # 1. Login with 1-Click Demo Login
        print("[Demo] Logging in...")
        demo_btn = page.locator("#btn-demo-login, button:has-text('1-Click Demo Login')").first
        if demo_btn.is_visible():
            demo_btn.click()
            time.sleep(2)
        else:
            # fill form
            page.fill("#login-email", "aarav.sharma@example.com")
            page.fill("#login-password", "demo123")
            page.click("#btn-login-submit")
            time.sleep(2)
            if page.locator("#otp-input").is_visible():
                page.fill("#otp-input", "123456")
                page.click("#btn-verify-otp")
                time.sleep(2)
                
        page.wait_for_selector("#section-dashboard.active", timeout=10000)
        time.sleep(2)
        
        # 2. Add an expense via Talk with Money on right panel
        print("[Demo] Entering expense: Spent ₹450 on food...")
        dash_input = page.locator("#dash-quick-input")
        dash_input.fill("Spent ₹450 on food")
        time.sleep(1)
        page.click("#dash-btn-send")
        time.sleep(3)
        
        # 3. Create a goal: Buy a car
        print("[Demo] Creating goal: I want to buy a car...")
        car_chip = page.locator("button[data-query='i want to buy a car']").first
        if car_chip.is_visible():
            car_chip.click()
        else:
            dash_input.fill("I want to buy a car")
            page.click("#dash-btn-send")
        time.sleep(3)
        
        # Select Target Amount ₹8,00,000
        amt_btn = page.locator("button.goal-opt-btn:has-text('₹8,00,000')").first
        if amt_btn.is_visible():
            amt_btn.click()
            time.sleep(2)
            
        # Select Timeline 36 Mo
        time_btn = page.locator("button.goal-opt-btn:has-text('36 Mo'), button.goal-opt-btn:has-text('3 Years')").first
        if time_btn.is_visible():
            time_btn.click()
            time.sleep(3)
            
        # 4. Resolve doubts on plan
        print("[Demo] Asking doubt: How is this calculated?...")
        calc_doubt = page.locator("button.doubt-chip[data-doubt='calculation']").first
        if calc_doubt.is_visible():
            calc_doubt.click()
            time.sleep(3)
            
        loan_doubt = page.locator("button.doubt-chip[data-doubt='loan_vs_saving']").first
        if loan_doubt.is_visible():
            loan_doubt.click()
            time.sleep(3)
            
        # 5. Explore Schemes
        print("[Demo] Exploring Schemes...")
        schemes_nav = page.locator("#nav-learn, button:has-text('Schemes')").first
        if schemes_nav.is_visible():
            schemes_nav.click()
            time.sleep(2)
            
            # Click SIP scheme card
            sip_card = page.locator(".scheme-card[data-topic='sip'], .scheme-card:has-text('SIP')").first
            if sip_card.is_visible():
                sip_card.click()
                time.sleep(3)
                
        # 6. Language Switcher (Hindi)
        print("[Demo] Switching language to Hindi...")
        hi_btn = page.locator("button[data-lang='hi-IN'], .lang-btn:has-text('हिंदी')").first
        if hi_btn.is_visible():
            hi_btn.click()
            time.sleep(3)
            
        # Switch to Kannada
        print("[Demo] Switching language to Kannada...")
        kn_btn = page.locator("button[data-lang='kn-IN'], .lang-btn:has-text('ಕನ್ನಡ')").first
        if kn_btn.is_visible():
            kn_btn.click()
            time.sleep(3)
            
        # Back to Dashboard
        dash_nav = page.locator("#nav-dashboard").first
        if dash_nav.is_visible():
            dash_nav.click()
            time.sleep(2)
            
        print("[Demo] Finishing recording...")
        context.close()
        browser.close()
        
    # Find generated video
    files = [f for f in os.listdir(output_dir) if f.endswith(".webm")]
    if files:
        latest = max([os.path.join(output_dir, f) for f in files], key=os.path.getctime)
        final_video = os.path.join(output_dir, "clarifi_demo.webm")
        if os.path.exists(final_video) and latest != final_video:
            os.remove(final_video)
        if latest != final_video:
            os.rename(latest, final_video)
        print(f"[Demo] SUCCESS! Video saved to: {final_video}")
        return final_video
    return None

if __name__ == "__main__":
    run_demo()
