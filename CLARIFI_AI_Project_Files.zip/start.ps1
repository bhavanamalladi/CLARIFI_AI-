# CLARIFI AI - PowerShell Launch Script
$ErrorActionPreference = "Stop"

Write-Host "`n=========================================" -ForegroundColor Cyan
Write-Host "  CLARIFI AI - Setup and Start" -ForegroundColor Cyan
Write-Host "=========================================`n" -ForegroundColor Cyan

# Locate Python 3.10+
$pythonPath = ""
$candidates = @(
    "$env:LOCALAPPDATA\Programs\Python\Python312\python.exe",
    "$env:LOCALAPPDATA\Programs\Python\Python311\python.exe",
    "$env:LOCALAPPDATA\Programs\Python\Python310\python.exe"
)

foreach ($c in $candidates) {
    if (Test-Path $c) {
        $pythonPath = $c
        $env:PATH = "$(Split-Path $c);$(Split-Path $c)\Scripts;$env:PATH"
        break
    }
}

if (-not $pythonPath) {
    try {
        $res = & py -3 -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $res) { $pythonPath = "py -3" }
    } catch {}
}

if (-not $pythonPath) {
    try {
        $res = & python -c "import sys; print(sys.executable)" 2>$null
        if ($LASTEXITCODE -eq 0 -and $res) { $pythonPath = "python" }
    } catch {}
}

if (-not $pythonPath) {
    Write-Host "ERROR: Python 3.10+ was not found on your system." -ForegroundColor Red
    Write-Host "Please install Python from https://www.python.org/downloads/"
    pause
    exit 1
}

Write-Host "[OK] Using Python: $pythonPath" -ForegroundColor Green

# Ensure .env exists
if (-not (Test-Path ".env")) {
    if (Test-Path ".env.example") {
        Copy-Item ".env.example" ".env"
    } else {
        Set-Content -Path ".env" -Value "GNANI_API_KEY=`nANTHROPIC_API_KEY=`n"
    }
    Write-Host "[!] Created .env file. Opening Notepad..." -ForegroundColor Yellow
    Write-Host "Please enter your GNANI_API_KEY and ANTHROPIC_API_KEY, save and close Notepad.`n"
    Start-Process notepad.exe -ArgumentList ".env" -Wait
}

# Create venv if missing
if (-not (Test-Path "venv\Scripts\python.exe")) {
    Write-Host "[*] Creating virtual environment (venv)..." -ForegroundColor Yellow
    if ($pythonPath -eq "py -3") {
        & py -3 -m venv venv
    } else {
        & $pythonPath -m venv venv
    }
    Write-Host "[OK] Virtual environment created." -ForegroundColor Green
}

# Install requirements
Write-Host "[*] Checking and installing dependencies..." -ForegroundColor Yellow
& .\venv\Scripts\pip.exe install -r requirements.txt --quiet

# Seed demo data if DB missing
if (-not (Test-Path "clarifi.db")) {
    Write-Host "[*] Seeding demo data into database..." -ForegroundColor Yellow
    & .\venv\Scripts\python.exe seed_demo_data.py
}

Write-Host "`n===========================================================" -ForegroundColor Green
Write-Host "  CLARIFI AI is running!" -ForegroundColor Green
Write-Host "  Open your browser at: http://localhost:8000" -ForegroundColor Cyan
Write-Host "  API Docs (Swagger):   http://localhost:8000/api/docs" -ForegroundColor Cyan
Write-Host "===========================================================`n" -ForegroundColor Green
Write-Host "Press Ctrl+C to stop the server.`n"

& .\venv\Scripts\uvicorn.exe backend.main:app --host 0.0.0.0 --port 8000 --reload
