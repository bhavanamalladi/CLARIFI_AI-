"""
CLARIFI AI — FastAPI Application Entry Point

Runs the backend server that:
- Serves the frontend static files
- Provides REST API endpoints for all features
- Bridges the browser to Gnani STT/TTS and Anthropic Claude
- Stores data in a local SQLite database

Start with:
    uvicorn backend.main:app --reload --port 8000
"""

import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from .config import settings
from .database import create_tables
from .routers import (
    health, voice, parse,
    transactions as tx_router,
    dashboard as dash_router,
    explainer as exp_router,
    goals as goals_router,
    tts as tts_router,
    auth as auth_router,
)

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.DEBUG if settings.debug else logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lifespan: startup + shutdown
# ---------------------------------------------------------------------------
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Create DB tables on startup; nothing to teardown for SQLite."""
    logger.info("🚀 Starting %s v%s", settings.app_name, settings.app_version)
    create_tables()
    logger.info("✅ Database tables ready")
    # Phase 2: ensure the default user row exists
    from .database import SessionLocal
    from .services.transactions import ensure_default_user
    with SessionLocal() as db:
        ensure_default_user(db)
    yield
    logger.info("👋 Shutting down %s", settings.app_name)


# ---------------------------------------------------------------------------
# App instance
# ---------------------------------------------------------------------------
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Voice-first personal finance learning app for first-time earners in India. "
        "Educational use only — not investment advice."
    ),
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
)


# ---------------------------------------------------------------------------
# CORS — allow all origins in dev; tighten in production
# ---------------------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def add_no_cache_headers(request: Request, call_next):
    """Prevent aggressive browser caching for SPA files in dev."""
    response = await call_next(request)
    if request.url.path.startswith(("/js", "/css")) or request.url.path == "/" or request.url.path.endswith(".html"):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


# ---------------------------------------------------------------------------
# API Routers
# ---------------------------------------------------------------------------
app.include_router(health.router)
app.include_router(voice.router)
app.include_router(parse.router)        # Phase 2: LLM parsing
app.include_router(tx_router.router)    # Phase 2: CRUD
app.include_router(dash_router.router)  # Phase 3: Dashboard
app.include_router(exp_router.router)   # Phase 4: Explainer
app.include_router(goals_router.router) # Phase 5: Goal Planner
app.include_router(tts_router.router)   # Phase 6: TTS
app.include_router(auth_router.router)  # 2FA OTP + Google + DB Auth


# ---------------------------------------------------------------------------
# Static files — serve the frontend
# ---------------------------------------------------------------------------
FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")
FRONTEND_DIR = os.path.abspath(FRONTEND_DIR)

if os.path.isdir(FRONTEND_DIR):
    # Serve CSS, JS, assets at /css, /js, etc.
    app.mount("/css", StaticFiles(directory=os.path.join(FRONTEND_DIR, "css")), name="css")
    app.mount("/js", StaticFiles(directory=os.path.join(FRONTEND_DIR, "js")), name="js")

    @app.get("/", include_in_schema=False)
    async def serve_index():
        """Serve the SPA index.html for the root path."""
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str):
        """
        Catch-all: return index.html for any non-API path so the SPA
        handles routing client-side.
        """
        file_path = os.path.join(FRONTEND_DIR, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(FRONTEND_DIR, "index.html"))
else:
    logger.warning("Frontend directory not found at %s — static files not served", FRONTEND_DIR)
