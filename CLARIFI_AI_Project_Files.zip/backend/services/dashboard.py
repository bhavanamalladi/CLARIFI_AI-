"""
CLARIFI AI — Dashboard Service  (Phase 3)

Computes all dashboard metrics from the SQLite database using pure Python math.
No LLM involved — deterministic calculations only.

Metrics computed:
  - Monthly income, total expenses, savings, savings rate
  - Category breakdown with percentages
  - EMI obligations (sum of EMI-category expenses)
  - Emergency fund: target amount vs estimated saved, progress %
"""

import logging
from datetime import date
from sqlalchemy.orm import Session
from sqlalchemy import func, extract

from ..models import Transaction, EmergencyFundTarget
from ..schemas import DashboardData, CategoryBreakdown

logger = logging.getLogger(__name__)

USER_ID = 1

# All expense categories (matches models.py)
ALL_CATEGORIES = ["rent", "food", "transport", "shopping", "bills", "EMI", "other"]


def get_dashboard(db: Session, month: int, year: int, user_id: int = 1) -> DashboardData:
    """
    Build the complete dashboard payload for a given month/year and user_id.
    All maths is deterministic Python — no LLM calls.
    """

    # ------------------------------------------------------------------ #
    # 1. Monthly income & expenses
    # ------------------------------------------------------------------ #
    base_q = (
        db.query(Transaction)
        .filter(
            Transaction.user_id == user_id,
            extract("month", Transaction.date) == month,
            extract("year",  Transaction.date) == year,
        )
    )

    monthly_income = (
        base_q.filter(Transaction.type == "income")
        .with_entities(func.coalesce(func.sum(Transaction.amount), 0.0))
        .scalar()
    )
    total_expenses = (
        base_q.filter(Transaction.type == "expense")
        .with_entities(func.coalesce(func.sum(Transaction.amount), 0.0))
        .scalar()
    )

    monthly_income = round(float(monthly_income), 2)
    total_expenses = round(float(total_expenses), 2)
    savings        = round(monthly_income - total_expenses, 2)
    savings_rate   = round((savings / monthly_income * 100) if monthly_income > 0 else 0.0, 1)

    # ------------------------------------------------------------------ #
    # 2. Category breakdown (expenses only)
    # ------------------------------------------------------------------ #
    cat_rows = (
        base_q.filter(Transaction.type == "expense")
        .with_entities(
            Transaction.category,
            func.sum(Transaction.amount).label("total"),
        )
        .group_by(Transaction.category)
        .all()
    )

    category_breakdown: list[CategoryBreakdown] = []
    for cat, total in cat_rows:
        pct = round((float(total) / total_expenses * 100) if total_expenses > 0 else 0.0, 1)
        category_breakdown.append(
            CategoryBreakdown(
                category=cat or "other",
                total=round(float(total), 2),
                percentage=pct,
            )
        )
    # Sort largest first
    category_breakdown.sort(key=lambda x: x.total, reverse=True)

    # ------------------------------------------------------------------ #
    # 3. EMI obligations (this month)
    # ------------------------------------------------------------------ #
    emi_obligations = round(float(
        base_q.filter(Transaction.type == "expense", Transaction.category == "EMI")
        .with_entities(func.coalesce(func.sum(Transaction.amount), 0.0))
        .scalar()
    ), 2)

    # ------------------------------------------------------------------ #
    # 4. Emergency fund
    #    Target = months_target × avg monthly expenses (last 3 months)
    #    Saved  = cumulative savings (sum of all income − expenses, all time)
    # ------------------------------------------------------------------ #
    ef_target = db.query(EmergencyFundTarget).filter(
        EmergencyFundTarget.user_id == user_id
    ).first()
    months_target = ef_target.months_target if ef_target else 6

    # Average monthly expenses over the last 3 months (or current month if less)
    avg_expenses = _avg_monthly_expenses(db, month, year, user_id=user_id, lookback=3)
    ef_target_amount = round(months_target * avg_expenses, 2)

    # Cumulative savings = all-time income − all-time expenses
    all_time_income = float(
        db.query(func.coalesce(func.sum(Transaction.amount), 0.0))
        .filter(Transaction.user_id == user_id, Transaction.type == "income")
        .scalar()
    )
    all_time_expenses = float(
        db.query(func.coalesce(func.sum(Transaction.amount), 0.0))
        .filter(Transaction.user_id == user_id, Transaction.type == "expense")
        .scalar()
    )
    ef_saved = max(0.0, round(all_time_income - all_time_expenses, 2))

    ef_progress_pct = round(
        (ef_saved / ef_target_amount * 100) if ef_target_amount > 0 else 0.0, 1
    )
    ef_progress_pct = min(ef_progress_pct, 100.0)  # cap at 100%

    # ------------------------------------------------------------------ #
    # 5. Month label
    # ------------------------------------------------------------------ #
    month_label = date(year, month, 1).strftime("%B %Y")  # "November 2026"

    return DashboardData(
        monthly_income=monthly_income,
        total_expenses=total_expenses,
        savings=savings,
        savings_rate=savings_rate,
        category_breakdown=category_breakdown,
        emi_obligations=emi_obligations,
        emergency_fund_target_months=months_target,
        emergency_fund_target_amount=ef_target_amount,
        emergency_fund_saved=ef_saved,
        emergency_fund_progress_pct=ef_progress_pct,
        month=month_label,
    )


def update_ef_target(db: Session, months_target: int, user_id: int = 1) -> EmergencyFundTarget:
    """Create or update the emergency fund target for user_id."""
    ef = db.query(EmergencyFundTarget).filter(
        EmergencyFundTarget.user_id == user_id
    ).first()

    if ef:
        ef.months_target = months_target
    else:
        ef = EmergencyFundTarget(user_id=user_id, months_target=months_target)
        db.add(ef)

    db.commit()
    db.refresh(ef)
    logger.info("Updated emergency fund target to %d months for user %d", months_target, user_id)
    return ef


def _avg_monthly_expenses(db: Session, current_month: int, current_year: int, user_id: int = 1, lookback: int = 3) -> float:
    """
    Compute the average monthly expenses over the last `lookback` months
    (including the current month).  Used for emergency-fund target calculation.
    """
    # Build list of (month, year) tuples going back `lookback` months
    periods = []
    m, y = current_month, current_year
    for _ in range(lookback):
        periods.append((m, y))
        m -= 1
        if m == 0:
            m = 12
            y -= 1

    monthly_totals = []
    for mon, yr in periods:
        total = float(
            db.query(func.coalesce(func.sum(Transaction.amount), 0.0))
            .filter(
                Transaction.user_id == user_id,
                Transaction.type == "expense",
                extract("month", Transaction.date) == mon,
                extract("year",  Transaction.date) == yr,
            )
            .scalar()
        )
        monthly_totals.append(total)

    non_zero = [t for t in monthly_totals if t > 0]
    return round(sum(non_zero) / len(non_zero), 2) if non_zero else 0.0
