"""
CLARIFI AI — Email Service (Gmail SMTP + 2FA OTP)
Sends OTP verification emails via Gmail SMTP with graceful local demo fallback.
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import logging
from ..config import Settings

logger = logging.getLogger(__name__)


def send_otp_email(to_email: str, otp: str, user_name: str = "User") -> dict:
    """
    Send a 2FA OTP verification code to the recipient's email address using Gmail SMTP.
    Dynamically loads fresh settings from .env on each invocation.
    """
    try:
        cfg = Settings()
    except Exception as e:
        logger.error(f"[EmailService] Failed loading Settings: {e}")
        cfg = None

    sender_email = (cfg.smtp_user if cfg else None) or (cfg.smtp_from if cfg else None) or "noreply@clarifi.ai"
    raw_pass = cfg.smtp_password if cfg else ""
    sender_pass = raw_pass.replace(" ", "").strip() if raw_pass else ""

    if not cfg or not cfg.smtp_user or not sender_pass:
        logger.warning(
            f"⚠️ [EmailService] Gmail SMTP credentials not set in .env. "
            f"Live email cannot be sent until SMTP_USER and SMTP_PASSWORD are provided in .env."
        )
        return {
            "sent": False,
            "smtp_configured": False,
            "message": "Gmail SMTP credentials not configured in .env. Please configure SMTP_USER and SMTP_PASSWORD."
        }

    try:
        msg = MIMEMultipart("alternative")
        msg["Subject"] = f"Your CLARIFI AI Verification Code: {otp}"
        msg["From"] = f"CLARIFI AI <{sender_email}>"
        msg["To"] = to_email

        text_content = f"""
Hello {user_name},

Your CLARIFI AI 2-Factor Authentication code is:

    {otp}

This code is valid for 10 minutes. Please enter it to complete your verification.
If you did not request this code, you can safely ignore this email.

Warm regards,
CLARIFI AI Team
"""
        html_content = f"""
<!DOCTYPE html>
<html>
<head>
  <style>
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #070a12; color: #f8fafc; padding: 24px; }}
    .container {{ max-width: 480px; margin: 0 auto; background: #0f172a; border-radius: 16px; border: 1px solid #334155; padding: 28px; text-align: center; }}
    .logo {{ font-size: 24px; font-weight: 800; color: #ffffff; margin-bottom: 8px; }}
    .logo span {{ color: #06b6d4; }}
    .subtitle {{ font-size: 14px; color: #94a3b8; margin-bottom: 24px; }}
    .otp-box {{ background: #1e293b; border: 2px dashed #6366f1; border-radius: 12px; padding: 18px; font-size: 32px; font-weight: 800; letter-spacing: 8px; color: #38bdf8; margin: 20px 0; }}
    .footer {{ font-size: 12px; color: #64748b; margin-top: 24px; }}
  </style>
</head>
<body>
  <div class="container">
    <div class="logo">CLARIFI <span>AI</span></div>
    <div class="subtitle">Voice-First Financial Mentor</div>
    <p style="color:#e2e8f0; font-size: 15px;">Hello <strong>{user_name}</strong>,</p>
    <p style="color:#94a3b8; font-size: 14px;">Enter the 2-Factor verification code below to verify your account:</p>
    <div class="otp-box">{otp}</div>
    <p style="color:#94a3b8; font-size: 13px;">This code expires in <strong>10 minutes</strong>. Never share this code with anyone.</p>
    <div class="footer">Educational personal finance companion • financial compliance standard</div>
  </div>
</body>
</html>
"""
        msg.attach(MIMEText(text_content, "plain"))
        msg.attach(MIMEText(html_content, "html"))

        # Connect to Gmail SMTP
        server = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=10)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(sender_email, sender_pass)
        server.sendmail(sender_email, [to_email], msg.as_string())
        server.quit()

        logger.info(f"[EmailService] Verification OTP successfully sent to {to_email}")
        return {
            "sent": True,
            "smtp_configured": True,
            "message": f"Verification email sent to {to_email} via Gmail SMTP. Please check your inbox (and spam folder)."
        }

    except Exception as e:
        logger.error(f"[EmailService] Failed to send email via SMTP ({e})")
        return {
            "sent": False,
            "smtp_configured": False,
            "message": f"SMTP delivery failed: {str(e)}. Please check your SMTP credentials in .env.",
        }
