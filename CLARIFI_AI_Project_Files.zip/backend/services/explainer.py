"""
CLARIFI AI — Financial Product Explainer Service  (Phase 4)

Sends the user's product question to Claude with a strict system prompt that:
  • Returns a structured JSON response (explanation + comparison table + example)
  • NEVER recommends specific funds, stocks, or investment products
  • NEVER guarantees returns
  • Redirects "where should I invest?" to education + financial advisor referral
  • Marks all return figures as ILLUSTRATIVE, not guaranteed

Supported topics: FD, RD, SIP, mutual funds, PPF, NPS, savings account,
ELSS, government schemes (PM Jan Dhan, Sukanya Samriddhi, etc.)
"""

import json
import logging
import re

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# System prompt — strict educational guardrails + JSON contract
# ---------------------------------------------------------------------------
EXPLAINER_SYSTEM = """You are CLARIFI AI's financial education assistant.
You EDUCATE first-time earners in India about financial instruments.

## STRICT RULES (never violate these)
1. NEVER tell the user to buy/invest in any specific fund, stock, scheme, or product.
2. NEVER guarantee returns. All return figures must be labelled "illustrative" or "typical historical range".
3. If asked "where should I invest?" → explain evaluation factors + say "consult a certified financial advisor".
4. Keep language simple — user is likely a student or first-job earner.
5. All rupee examples must use the ₹ symbol and Indian number format (lakhs/crores).

## OUTPUT FORMAT — always return exactly this JSON (no markdown, no extra text):
{
  "topic": "<product name, e.g. FD>",
  "summary": "<2-3 sentence plain-language explanation>",
  "how_it_works": "<3-5 sentences: mechanics, who offers it, minimum amount>",
  "comparison_table": [
    {
      "aspect": "Risk",
      "value": "<low/medium/high + brief reason>"
    },
    {
      "aspect": "Liquidity",
      "value": "<can withdraw anytime / lock-in details>"
    },
    {
      "aspect": "Lock-in",
      "value": "<duration or 'None'>"
    },
    {
      "aspect": "Typical return range",
      "value": "<illustrative range, e.g. 6–7% p.a. — illustrative, not guaranteed>"
    },
    {
      "aspect": "Taxation",
      "value": "<how returns are taxed in India>"
    },
    {
      "aspect": "Best suited for",
      "value": "<short / medium / long term + risk profile>"
    }
  ],
  "worked_example": "<Step-by-step ₹ example. Use realistic but illustrative numbers. E.g. 'If you invest ₹5,000/month in an RD for 12 months at an illustrative 6.5% p.a., you would receive approximately ₹61,900 at maturity.'>",
  "key_takeaway": "<One powerful sentence the user should remember>",
  "compliance_note": "<Always include: 'This is educational information. For personalised advice, consult a certified financial advisor.'>",
  "related_topics": ["<2-3 related product names the user might want to learn about next>"]
}

Respond in: {language}
"""

# Products the explainer knows about
KNOWN_TOPICS = {
    "fd": "Fixed Deposit (FD)",
    "fixed deposit": "Fixed Deposit (FD)",
    "rd": "Recurring Deposit (RD)",
    "recurring deposit": "Recurring Deposit (RD)",
    "sip": "Systematic Investment Plan (SIP)",
    "mutual fund": "Mutual Funds",
    "mutual funds": "Mutual Funds",
    "ppf": "Public Provident Fund (PPF)",
    "public provident fund": "Public Provident Fund (PPF)",
    "nps": "National Pension System (NPS)",
    "national pension": "National Pension System (NPS)",
    "elss": "ELSS (Tax-saving Mutual Fund)",
    "savings account": "Savings Account",
    "government scheme": "Government Savings Schemes",
    "sukanya": "Sukanya Samriddhi Yojana",
    "jan dhan": "PM Jan Dhan Yojana",
    "senior citizen": "Senior Citizen Savings Scheme",
    "index fund": "Index Funds",
    "etf": "Exchange Traded Funds (ETF)",
}


def explain_product(query: str, language: str = "en-IN", topic_key: str | None = None) -> dict:
    # If explicit topic_key is provided from pill buttons, map directly
    if topic_key and topic_key in ("fd", "rd", "sip", "mutual_funds", "ppf", "nps", "elss", "savings"):
        return _get_built_in_explanation(topic_key, language)

    # Match topic from query text
    q_lower = (query or "").lower().strip()
    matched_key = "sip"

    # Precise keyword priority
    if any(k in q_lower for k in ["saving", "savings", "savings account"]):
        matched_key = "savings"
    elif any(k in q_lower for k in ["elss", "tax saving", "80c fund"]):
        matched_key = "elss"
    elif any(k in q_lower for k in ["nps", "national pension", "pension scheme", "pension"]):
        matched_key = "nps"
    elif any(k in q_lower for k in ["ppf", "public provident"]):
        matched_key = "ppf"
    elif any(k in q_lower for k in ["mutual fund", "mutual funds", "equity fund", "debt fund", "index fund"]):
        matched_key = "mutual_funds"
    elif any(k in q_lower for k in ["rd", "recurring deposit", "recurring"]):
        matched_key = "rd"
    elif any(k in q_lower for k in ["fd", "fixed deposit", "term deposit"]):
        matched_key = "fd"
    elif any(k in q_lower for k in ["sip", "systematic investment"]):
        matched_key = "sip"

    return _get_built_in_explanation(matched_key, language)


def _parse_response(raw: str) -> dict:
    """Strip markdown fences and parse JSON from Claude's response."""
    cleaned = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.MULTILINE)
    cleaned = re.sub(r"\s*```$", "", cleaned, flags=re.MULTILINE).strip()
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        logger.error("Failed to parse explainer JSON: %s", raw[:300])
        return _error_response("Could not parse explanation. Please rephrase your question.")


def _error_response(msg: str) -> dict:
    return {
        "topic": "Error",
        "summary": msg,
        "how_it_works": "",
        "comparison_table": [],
        "worked_example": "",
        "key_takeaway": "",
        "compliance_note": "This is educational information. For personalised advice, consult a certified financial advisor.",
        "related_topics": [],
        "error": True,
    }


def _lang_name(code: str) -> str:
    return {"en-IN": "English", "hi-IN": "Hindi", "kn-IN": "Kannada", "te-IN": "Telugu"}.get(code, "English")


def get_quick_topics() -> list[dict]:
    """Return the preset topic buttons shown in the Learn UI."""
    return [
        {"key": "fd",           "label": "🏦 Fixed Deposit",    "query": "Explain Fixed Deposit (FD) in simple terms"},
        {"key": "rd",           "label": "📅 Recurring Deposit", "query": "Explain Recurring Deposit (RD)"},
        {"key": "sip",          "label": "📈 SIP",               "query": "What is a SIP and how does it work?"},
        {"key": "mutual_funds", "label": "🌱 Mutual Funds",      "query": "Explain mutual funds for a beginner"},
        {"key": "ppf",          "label": "🏛️ PPF",               "query": "Explain Public Provident Fund (PPF)"},
        {"key": "nps",          "label": "👴 NPS",               "query": "Explain National Pension System (NPS)"},
        {"key": "elss",         "label": "💰 ELSS",              "query": "What is ELSS and how does it save tax?"},
        {"key": "savings",      "label": "💳 Savings Account",   "query": "How does a savings account work in India?"},
    ]


def _get_built_in_explanation(topic_key: str, language: str = "en-IN") -> dict:
    """
    Returns rich, educational-compliant educational explanations in English, Hindi, Kannada, and Telugu.
    Guarantees instant, zero-latency response even when offline or during API delays.
    """
    lang = language if language in ("en-IN", "hi-IN", "kn-IN", "te-IN") else "en-IN"

    data = {
        "sip": {
            "en-IN": {
                "topic": "Systematic Investment Plan (SIP)",
                "summary": "💡 Real-Life Analogy: Gym Membership for Wealth — Just like daily workouts build physical strength, small monthly investments compound over time to build huge financial muscle without needing a large lump sum upfront.",
                "how_it_works": "Every month on a set date, a fixed sum (e.g. ₹500 or ₹2,000) is automatically debited from your bank account and invested in units of your chosen mutual fund. Over time, you benefit from rupee-cost averaging (buying more units when prices are low and fewer when high) and the power of compounding.",
                "comparison_table": [
                    {"aspect": "Risk Level (Safety)", "value": "Moderate to High (Depends on underlying fund: Debt vs Equity)"},
                    {"aspect": "Liquidity (Withdrawal)", "value": "High (Can stop SIP or withdraw money anytime, except ELSS with 3-yr lock-in)"},
                    {"aspect": "Lock-in Period", "value": "Zero for standard open-ended funds (3 years only for ELSS tax-saving)"},
                    {"aspect": "Expected Profit Range", "value": "10%–14% p.a. illustrative historical average (Market-linked, not guaranteed)"},
                    {"aspect": "Tax on Profit", "value": "Equity: Profit above ₹1.25L/yr taxed at 12.5%; Short-term (<1 yr) taxed at 20%"},
                    {"aspect": "Who is this best for?", "value": "Medium to long-term goals (3+ years) and disciplined monthly wealth building"}
                ],
                "worked_example": "If you invest ₹3,000 per month via SIP for 5 years at an illustrative 12% p.a. return: Your total investment is ₹1,80,000. Your estimated total value could be approximately ₹2,47,460.",
                "key_takeaway": "SIP builds investing discipline and smooths out market volatility through rupee-cost averaging.",
                "compliance_note": "Educational information only — not investment advice. Mutual fund investments are subject to market risks. Consult a certified financial advisor.",
                "related_topics": ["Mutual Funds", "Recurring Deposit (RD)", "Index Funds"]
            },
            "hi-IN": {
                "topic": "सिस्टमैटिक इन्वेस्टमेंट प्लान (SIP)",
                "summary": "💡 रोजमर्रा की भाषा में: वेल्थ के लिए जिम मेंबरशिप — जैसे नियमित कसरत से शरीर मजबूत बनता है, वैसे ही हर महीने 500 या 1000 रुपये का छोटा निवेश समय के साथ बड़ा फंड तैयार कर देता है।",
                "how_it_works": "हर महीने एक तय तारीख पर आपके बैंक खाते से तय रकम कटकर म्यूचुअल फंड यूनिट्स खरीदती है। जब बाजार नीचे होता है तो ज्यादा यूनिट्स मिलती हैं और ऊपर होने पर कम (रुपी-कॉस्ट एवरेजिंग)।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "मध्यम से उच्च (फंड के प्रकार पर निर्भर)"},
                    {"aspect": "पैसे निकालने की सुविधा (Liquidity)", "value": "उच्च (कभी भी निकासी संभव, केवल ELSS में 3 साल का लॉक-इन)"},
                    {"aspect": "कंपलसरी समय (Lock-in)", "value": "कोई नहीं (ELSS में 3 वर्ष)"},
                    {"aspect": "अनुमानित मुनाफा दर", "value": "10%–14% वार्षिक सांकेतिक (बाजार आधारित, कोई गारंटी नहीं)"},
                    {"aspect": "टैक्स", "value": "इक्विटी LTCG 12.5% (₹1.25 लाख से अधिक पर), STCG 20%"},
                    {"aspect": "किसके लिए सबसे अच्छा?", "value": "मध्यम और लंबी अवधि (3+ साल) के लक्ष्यों के लिए"}
                ],
                "worked_example": "यदि आप 5 साल तक हर महीने ₹3,000 का SIP 12% वार्षिक सांकेतिक रिटर्न पर करते हैं, तो आपकी जमा राशि ₹1,80,000 होगी और अनुमानित फंड लगभग ₹2,47,460 बन सकता है।",
                "key_takeaway": "SIP छोटे निवेश से शुरू करके लंबी अवधि में बड़ा फंड बनाने का सबसे अनुशासित तरीका है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है। म्यूचुअल फंड बाजार जोखिमों के अधीन हैं। वित्तीय सलाहकार से परामर्श लें।",
                "related_topics": ["म्यूचुअल फंड", "आवर्ती जमा (RD)", "इंडेक्स फंड"]
            },
            "kn-IN": {
                "topic": "ಸಿಸ್ಟಮ್ಯಾಟಿಕ್ ಇನ್ವೆಸ್ಟ್‌ಮೆಂಟ್ ಪ್ಲಾನ್ (SIP)",
                "summary": "💡 ಸರಳ ಉದಾಹರಣೆ: ಸಂಪತ್ತಿನ ಜಿಮ್ ಸದಸ್ಯತ್ವ — ನಿತ್ಯದ ವ್ಯಾಯಾಮ ದೇಹವನ್ನು ಸದೃಢಗೊಳಿಸುವಂತೆ, ಪ್ರತಿ ತಿಂಗಳು ₹500 ಅಥವಾ ₹1,000 ದ ಸಣ್ಣ ಹೂಡಿಕೆ ದೀರ್ಘಾವಧಿಯಲ್ಲಿ ದೊಡ್ಡ ಸಂಪತ್ತನ್ನು ಸೃಷ್ಟಿಸುತ್ತದೆ.",
                "how_it_works": "ಪ್ರತಿ ತಿಂಗಳು ನಿಗದಿತ ದಿನದಂದು ನಿಮ್ಮ ಬ್ಯಾಂಕ್ ಖಾತೆಯಿಂದ ಹಣ ನೇರವಾಗಿ ಫಂಡ್‌ಗೆ ಜಮೆಯಾಗುತ್ತದೆ. ಮಾರುಕಟ್ಟೆ ಏರಿಳಿತಗಳನ್ನು ಸರಿತೂಗಿಸಲು (Rupee-cost averaging) ಇದು ಸಹಕಾರಿ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ ಮಟ್ಟ (Risk)", "value": "ಮಧ್ಯಮದಿಂದ ಗರಿಷ್ಠ (ಫಂಡ್ ಪ್ರಕಾರವನ್ನು ಅವಲಂಬಿಸಿದೆ)"},
                    {"aspect": "ಹಣ ಹಿಂಪಡೆಯುವಿಕೆ (Liquidity)", "value": "ಉತ್ತಮ (ಯಾವಾಗ ಬೇಕಾದರೂ ಹಿಂಪಡೆಯಬಹುದು)"},
                    {"aspect": "ಲಾಕ್-ಇನ್ ಅವಧಿ", "value": "ಯಾವುದೂ ಇಲ್ಲ (ELSS ತೆರಿಗೆ ಉಳಿತಾಯ ಫಂಡ್‌ಗೆ 3 ವರ್ಷ)"},
                    {"aspect": "ನಿರೀಕ್ಷಿತ ಲಾಭದ ದರ", "value": "ವಾರ್ಷಿಕ 10%–14% ವಿವರಣಾತ್ಮಕ (ಮಾರುಕಟ್ಟೆ ಆಧಾರಿತ)"},
                    {"aspect": "ತೆರಿಗೆ (Tax)", "value": "ದೀರ್ಘಾವಧಿ ಲಾಭ ₹1.25 ಲಕ್ಷ ಮೀರಿದರೆ 12.5%"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ?", "value": "ಮಧ್ಯಮ ಮತ್ತು ದೀರ್ಘಾವಧಿ (3+ ವರ್ಷ) ಹೂಡಿಕೆದಾರರಿಗೆ"}
                ],
                "worked_example": "ಪ್ರತಿ ತಿಂಗಳು ₹3,000 ರಂತೆ 5 ವರ್ಷ 12% ವಿವರಣಾತ್ಮಕ ದರದಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿದರೆ, ನಿಮ್ಮ ₹1,80,000 ಹೂಡಿಕೆಯು ಅಂದಾಜು ₹2,47,460 ಆಗಬಹುದು.",
                "key_takeaway": "ಸಣ್ಣ ಉಳಿತಾಯದಿಂದ ಶಿಸ್ತಿನ ದೀರ್ಘಾವಧಿ ಸಂಪತ್ತು ನಿರ್ಮಾಣಕ್ಕೆ SIP ಅತ್ಯುತ್ತಮ ಮಾರ್ಗ.",
                "compliance_note": "ಇದು ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ ಮಾತ್ರ, ಹೂಡಿಕೆ ಸಲಹೆಯಲ್ಲ. ಹೂಡಿಕೆಗೆ ಮುನ್ನ ಹಣಕಾಸು ಸಲಹೆಗಾರರನ್ನು ಸಂಪರ್ಕಿಸಿ.",
                "related_topics": ["ಮ್ಯೂಚುವಲ್ ಫಂಡ್‌ಗಳು", "ಆರ್‌ಡಿ (RD)", "ಇಂಡೆಕ್ಸ್ ಫಂಡ್‌ಗಳು"]
            },
            "te-IN": {
                "topic": "సిస్టమాటిక్ ఇన్వెస్ట్‌మెంట్ ప్లాన్ (SIP)",
                "summary": "💡 సులభమైన ఉదాహరణ: సంపద పెంచే జిమ్ సభ్యత్వం — క్రమం తప్పకుండా వ్యాయామం ఆరోగ్యాన్ని పెంచినట్లే, ప్రతి నెలా ₹500 లేదా ₹1,000 వంటి చిన్న మొత్తం పెట్టుబడి పెడితే చక్రవడ్డీతో భారీ సంపద సమకూరుతుంది.",
                "how_it_works": "ప్రతి నెలా ఎంచుకున్న తేదీన మీ బ్యాంక్ ఖాతా నుండి ఆటోమేటిక్‌గా డబ్బు డెబిట్ అయి యూనిట్లు కేటాయించబడతాయి. మార్కెట్ ధరలు తక్కువగా ఉన్నప్పుడు ఎక్కువ యూనిట్లు లభిస్తాయి.",
                "comparison_table": [
                    {"aspect": "రిస్క్ స్థాయి (Risk)", "value": "మధ్యస్థం నుండి ఎక్కువ (ఫండ్ రకాన్ని బట్టి)"},
                    {"aspect": "డబ్బు వెనక్కి తీసుకోవడం (Liquidity)", "value": "ఎక్కువ (ఎప్పుడైనా వెనక్కి తీసుకోవచ్చు)"},
                    {"aspect": "లాక్-ఇన్ పీరియడ్", "value": "ఏమీ లేదు (ELSS కు 3 సంవత్సరాలు)"},
                    {"aspect": "ఆశించదగిన లాభం", "value": "10%–14% ఉదాహరణ సగటు (మార్కెట్ ఆధారితం)"},
                    {"aspect": "పన్ను (Taxation)", "value": "దీర్ఘకాలిక మూలధన లాభం ₹1.25 లక్షల పైన 12.5%"},
                    {"aspect": "ఎవరికి అనుకూలం?", "value": "మధ్యస్థ మరియు దీర్ఘకాలిక లక్ష్యాల కోసం (3+ సంవత్సరాలు)"}
                ],
                "worked_example": "మీరు నెలకు ₹3,000 చొప్పున 5 సంవత్సరాలు 12% ఉదాహరణ వార్షిక రిటర్న్‌తో పెట్టుబడి చేస్తే, మీ ₹1,80,000 సుమారు ₹2,47,460 గా మారే అవకాశం ఉంది.",
                "key_takeaway": "క్రమశిక్షణతో కూడిన దీర్ಘకాలిక సంపద సృష్టికి SIP చక్కని పరిష్కారం.",
                "compliance_note": "ఇది కేవలం అవగాహన కొరకు మాత్రమే. మ్యూచువల్ ఫండ్స్ మార్కెట్ రిస్కులకు లోబడి ఉంటాయి.",
                "related_topics": ["మ్యూచువల్ ఫండ్స్", "రికరింగ్ డిపాజిట్ (RD)", "ఇండెక్స్ ఫండ్స్"]
            }
        },
        "fd": {
            "en-IN": {
                "topic": "Fixed Deposit (FD)",
                "summary": "💡 Real-Life Analogy: Bank Vault with Guaranteed Return — You deposit a lump sum for a fixed period. The bank guarantees your profit from day 1 with zero stock market risk, insured up to ₹5 Lakh by RBI DICGC.",
                "how_it_works": "You deposit a fixed amount for a chosen tenure (7 days to 10 years). The bank guarantees your interest rate throughout the tenure, and at maturity, you receive your principal plus compound interest. DICGC insures deposits up to ₹5 Lakh per bank.",
                "comparison_table": [
                    {"aspect": "Risk Level (Safety)", "value": "Very Low (100% Capital Safe, insured up to ₹5 Lakh by RBI DICGC)"},
                    {"aspect": "Liquidity (Withdrawal)", "value": "Moderate (Premature withdrawal allowed with a small 0.5%–1% penalty)"},
                    {"aspect": "Lock-in Period", "value": "Flexible choice (7 days to 10 years; 5 years for tax-saving FD)"},
                    {"aspect": "Expected Profit Range", "value": "6.5%–7.5% p.a. (Higher for senior citizens, bank-guaranteed)"},
                    {"aspect": "Tax on Profit", "value": "Interest added to your income and taxed at your applicable slab rate (TDS applies if > ₹40,000/yr)"},
                    {"aspect": "Who is this best for?", "value": "Capital preservation, emergency funds, and goals within 1 to 3 years"}
                ],
                "worked_example": "If you deposit ₹1,00,000 in an FD for 2 years at 7.0% p.a. compounded quarterly: Your maturity amount will be approximately ₹1,14,888 (interest earned: ₹14,888).",
                "key_takeaway": "FD offers complete peace of mind and guaranteed returns, making it ideal for capital protection.",
                "compliance_note": "Educational information only — not investment advice. Bank deposits are insured up to ₹5 Lakh under RBI's DICGC scheme.",
                "related_topics": ["Recurring Deposit (RD)", "Liquid Fund", "Public Provident Fund (PPF)"]
            },
            "hi-IN": {
                "topic": "फिक्स्ड डिपॉजिट (FD)",
                "summary": "💡 रोजमर्रा की भाषा में: गारंटीड बैंक तिजोरी — आप एकमुश्त पैसा एक तय समय के लिए रखते हैं। बैंक पहले दिन से ही आपका मुनाफा तय रखता है और इसमें कोई शेयर बाजार का खतरा नहीं होता।",
                "how_it_works": "आप 7 दिन से 10 साल तक की अवधि चुनकर एकमुश्त रकम जमा करते हैं। बैंक अवधि पूरी होने पर गारंटीड मूलधन और ब्याज लौटाता है। RBI की DICGC योजना के तहत ₹5 लाख तक का बीमा होता है।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "अत्यंत कम (100% सुरक्षित, DICGC द्वारा ₹5 लाख तक बीमित)"},
                    {"aspect": "पैसे निकालने की सुविधा", "value": "मध्यम (0.5%–1% पेनाल्टी देकर कभी भी पैसे निकाल सकते हैं)"},
                    {"aspect": "कंपलसरी समय (Lock-in)", "value": "आपकी पसंद अनुसार (7 दिन से 10 वर्ष)"},
                    {"aspect": "अनुमानित मुनाफा दर", "value": "6.5%–7.5% वार्षिक (गारंटीड बैंक रिटर्न)"},
                    {"aspect": "टैक्स", "value": "ब्याज आपकी आय में जुड़ता है और स्लैब अनुसार टैक्स लगता है"},
                    {"aspect": "किसके लिए सबसे अच्छा?", "value": "पूंजी की सुरक्षा और 1 से 3 साल के अल्पकालिक लक्ष्यों के लिए"}
                ],
                "worked_example": "यदि आप 2 साल के लिए ₹1,00,000 की FD 7.0% की दर पर कराते हैं, तो मैच्योरिटी पर आपको लगभग ₹1,14,888 मिलेंगे।",
                "key_takeaway": "FD में कोई बाजार जोखिम नहीं होता और गारंटीड रिटर्न मिलता है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है। निवेश से पूर्व वित्तीय सलाहकार से परामर्श लें।",
                "related_topics": ["आवर्ती जमा (RD)", "लिक्विड फंड", "पब्लिक प्रोविडेंट फंड (PPF)"]
            },
            "kn-IN": {
                "topic": "ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ (FD)",
                "summary": "💡 ಸರಳ ಉದಾಹರಣೆ: ಖಾತರಿ ಲಾಭದ ಬ್ಯಾಂಕ್ ವಾಲ್ಟ್ — ಒಂದು ನಿಗದಿತ ಅವಧಿಗೆ ಬ್ಯಾಂಕ್‌ನಲ್ಲಿ ಒಟ್ಟಿಗೆ ಹಣ ಠೇವಣಿ ಇರಿಸಿ ಖಾತರಿಯ ಬಡ್ಡಿ ಪಡೆಯುವ ಅತ್ಯಂತ ಸುರಕ್ಷಿತ ಹೂಡಿಕೆಯಾಗಿದೆ.",
                "how_it_works": "ಒಂದು ನಿರ್ದಿಷ್ಟ ಮೊತ್ತವನ್ನು 7 ದಿನಗಳಿಂದ 10 ವರ್ಷಗಳ ಅವಧಿಗೆ ಇರಿಸಲಾಗುತ್ತದೆ. ಅವಧಿ ಮುಗಿದ ನಂತರ ಮೂಲಧನದ ಜೊತೆಗೆ ಬಡ್ಡಿಯನ್ನು ನೀಡಲಾಗುತ್ತದೆ. ₹5 ಲಕ್ಷದವರೆಗೆ DICGC ವಿಮೆ ಇರುತ್ತದೆ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ ಮಟ್ಟ (Risk)", "value": "ಅತ್ಯಂತ ಕಡಿಮೆ (₹5 ಲಕ್ಷದವರೆಗೆ ಸರ್ಕಾರಿ ವಿಮೆ)"},
                    {"aspect": "ಹಣ ಹಿಂಪಡೆಯುವಿಕೆ", "value": "ಮಧ್ಯಮ (ಸ್ವಲ್ಪ ದಂಡದೊಂದಿಗೆ ಮುಂಚಿತವಾಗಿ ಹಿಂಪಡೆಯಬಹುದು)"},
                    {"aspect": "ಲಾಕ್-ಇನ್ ಅವಧಿ", "value": "7 ದಿನಗಳಿಂದ 10 ವರ್ಷಗಳವರೆಗೆ"},
                    {"aspect": "ನಿರೀಕ್ಷಿತ ಲಾಭದ ದರ", "value": "ವಾರ್ಷಿಕ 6.5%–7.5% (ಬ್ಯಾಂಕ್ ಗ್ಯಾರಂಟಿ)"},
                    {"aspect": "ತೆರಿಗೆ (Tax)", "value": "ಬಡ್ಡಿ ಆದಾಯಕ್ಕೆ ನಿಮ್ಮ ಸ್ಲ್ಯಾಬ್ ಪ್ರಕಾರ ತೆರಿಗೆ ಅನ್ವಯಿಸುತ್ತದೆ"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ?", "value": "ಬಂಡವಾಳ ಸುರಕ್ಷತೆ ಮತ್ತು 1-3 ವರ್ಷಗಳ ಗುರಿಗಳಿಗೆ"}
                ],
                "worked_example": "₹1,00,000 ಅನ್ನು 7.0% ದರದಲ್ಲಿ 2 ವರ್ಷ FD ಇಟ್ಟರೆ, ಮೆಚ್ಯೂರಿಟಿಗೆ ಅಂದಾಜು ₹1,14,888 ಲಭಿಸುತ್ತದೆ.",
                "key_takeaway": "ಬಂಡವಾಳದ ಸಂಪೂರ್ಣ ಸುರಕ್ಷತೆ ಮತ್ತು ಗ್ಯಾರಂಟಿ ಆದಾಯಕ್ಕೆ FD ಸೂಕ್ತ.",
                "compliance_note": "ಇದು ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ.",
                "related_topics": ["ಆರ್‌ಡಿ (RD)", "ಲಿಕ್ವಿಡ್ ಫಂಡ್", "ಪಿಪಿಎಫ್ (PPF)"]
            },
            "te-IN": {
                "topic": "ఫిక్స్‌డ్ డిపాజిట్ (FD)",
                "summary": "💡 సులభమైన ఉదాహరణ: గ్యారెంటీ లాభమిచ్చే బ్యాంక్ వాల్ట్ — బ్యాంకులో ఒక నిర్దిష్ట కాలానికి ఒకేసారి డబ్బును స్థిర వడ్డీ రేటుతో దాచుకునే అత్యంత సురక్షితమైన మార్గం.",
                "how_it_works": "మీరు ఎంచుకున్న కాలపరిమితికి (7 రోజుల నుండి 10 సంవత్సరాలు) ఒకేసారి మొత్తాన్ని డిపాజిట్ చేస్తారు. ఆర్బీఐ నియమాల ప్రకారం ₹5 లక్షల వరకు డిపాజిట్ ఇన్సూరెన్స్ ఉంటుంది.",
                "comparison_table": [
                    {"aspect": "రిస్క్ స్థాయి (Risk)", "value": "చాలా తక్కువ (100% సురక్షితం, ₹5 లక్షల వరకు DICGC ఇన్సూరెన్స్)"},
                    {"aspect": "డబ్బు వెనక్కి తీసుకోవడం", "value": "మధ్యస్థం (చిన్న పెనాల్టీతో ఎప్పుడైనా విత్‌డ్రా చేయవచ్చు)"},
                    {"aspect": "లాక్-ఇన్ పీరియడ్", "value": "7 రోజుల నుండి 10 సంవత్సరాలు"},
                    {"aspect": "ఆశించదగిన లాభం", "value": "వార్షికంగా 6.5%–7.5% (గ్యారెంటీడ్ రిటర్న్)"},
                    {"aspect": "పన్ను (Taxation)", "value": "వడ్డీ మొత్తం మీ వార్షిక ఆదాయంలో కలిసి పన్ను పడుతుంది"},
                    {"aspect": "ఎవరికి అనుకూలం?", "value": "పెట్టుబడి భద్రత కోరుకునే వారికి, 1-3 ఏళ్ల స్వల్పకాలిక లక్ష్యాలకు"}
                ],
                "worked_example": "మీరు ₹1,00,000 ను 7.0% వడ్డీతో 2 సంవత్సరాలు FD చేస్తే, గడువు ముగిసేసరికి సుమారు ₹1,14,888 లభిస్తుంది.",
                "key_takeaway": "రిస్క్ లేకుండా స్థిరమైన రాబడి కోరుకునే వారికి FD అత్యుత్తమమైనది.",
                "compliance_note": "ఇది కేవలం సమాచార ప్రయోజనాల కొరకు మాత్రమే.",
                "related_topics": ["రికరింగ్ డిపాజిట్ (RD)", "లిక్విడ్ ఫండ్స్", "పీపీఎఫ్ (PPF)"]
            }
        },
        "rd": {
            "en-IN": {
                "topic": "Recurring Deposit (RD)",
                "summary": "A Recurring Deposit (RD) helps you build savings by depositing a fixed amount every month for a chosen tenure at a guaranteed interest rate.",
                "how_it_works": "You commit to depositing a fixed amount (e.g., ₹1,000 or ₹5,000) every month for 6 months to 10 years. You earn guaranteed interest compounded quarterly, and get the lump sum back at maturity.",
                "comparison_table": [
                    {"aspect": "Risk", "value": "Very Low (Guaranteed bank deposit, covered under ₹5L DICGC insurance)"},
                    {"aspect": "Liquidity", "value": "Moderate (Premature closure allowed with penalty)"},
                    {"aspect": "Lock-in", "value": "Tenure chosen by you (6 months to 10 years)"},
                    {"aspect": "Typical return range", "value": "6.5%–7.25% p.a. (Bank guaranteed)"},
                    {"aspect": "Taxation", "value": "Interest is taxable according to your income slab"},
                    {"aspect": "Best suited for", "value": "Disciplined monthly savings for short-term goals within 1 to 2 years"}
                ],
                "worked_example": "Depositing ₹5,000/month in an RD for 12 months at an illustrative 7.0% p.a. yields approximately ₹62,310 at maturity (Your deposit: ₹60,000, Interest: ₹2,310).",
                "key_takeaway": "RD turns monthly savings into a guaranteed lump sum without any market risk.",
                "compliance_note": "Educational information only — not investment advice.",
                "related_topics": ["Fixed Deposit (FD)", "SIP", "Savings Account"]
            },
            "hi-IN": {
                "topic": "आवर्ती जमा (Recurring Deposit / RD)",
                "summary": "आवर्ती जमा (RD) हर महीने एक निश्चित राशि बैंक में जमा करके गारंटीड ब्याज के साथ बड़ा फंड बनाने का सुरक्षित तरीका है।",
                "how_it_works": "आप 6 महीने से 10 साल तक की अवधि चुनकर हर महीने एक तय रकम (जैसे ₹1,000 या ₹5,000) जमा करते हैं। बैंक तिमाही चक्रवृद्धि ब्याज जोड़कर मैच्योरिटी पर पूरी राशि लौटाता है।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "अत्यंत कम (आरबीआई डीआईसीजीसी द्वारा ₹5 लाख तक सुरक्षित)"},
                    {"aspect": "तरलता", "value": "मध्यम (मामूली पेनाल्टी देकर समय पूर्व बंद कर सकते हैं)"},
                    {"aspect": "अवधि", "value": "6 महीने से 10 वर्ष तक"},
                    {"aspect": "ब्याज दर", "value": "6.5%–7.25% वार्षिक (गारंटीड बैंक रिटर्न)"},
                    {"aspect": "टैक्स", "value": "ब्याज आय पर आपके इनकम टैक्स स्लैब के अनुसार टैक्स लगता है"},
                    {"aspect": "किसके लिए उपयुक्त", "value": "1 से 2 साल के अल्पकालिक लक्ष्यों के लिए अनुशासित बचत"}
                ],
                "worked_example": "यदि आप 1 साल तक हर महीने ₹5,000 की RD 7.0% की दर पर करते हैं, तो आपको मैच्योरिटी पर लगभग ₹62,310 मिलेंगे।",
                "key_takeaway": "RD हर महीने बिना किसी जोखिम के गारंटीड पूंजी जमा करने का सबसे अच्छा साधन है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है।",
                "related_topics": ["फिक्स्ड डिपॉजिट (FD)", "SIP", "बचत खाता"]
            },
            "kn-IN": {
                "topic": "ರಿಕರಿಂಗ್ ಡೆಪಾಸಿಟ್ (RD)",
                "summary": "ಪ್ರತಿ ತಿಂಗಳು ನಿರ್ದಿಷ್ಟ ಮೊತ್ತವನ್ನು ಬ್ಯಾಂಕ್‌ನಲ್ಲಿ ಉಳಿಸಿ ಗ್ಯಾರಂಟಿ ಬಡ್ಡಿಯೊಂದಿಗೆ ದೊಡ್ಡ ಮೊತ್ತವನ್ನು ನಿರ್ಮಿಸಲು RD ಅತ್ಯುತ್ತಮ ಮಾರ್ಗ.",
                "how_it_works": "6 ತಿಂಗಳಿಂದ 10 ವರ್ಷಗಳ ಅವಧಿಗೆ ತಿಂಗಳಿಗೆ ₹1,000 ಅಥವಾ ₹5,000 ರಂತೆ ಜಮಾ ಮಾಡಲಾಗುತ್ತದೆ. ತ್ರೈಮಾಸಿಕ ಚಕ್ರಬಡ್ಡಿಯೊಂದಿಗೆ ಮೆಚ್ಯೂರಿಟಿಗೆ ಸಂಪೂರ್ಣ ಹಣ ಲಭಿಸುತ್ತದೆ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ", "value": "ಅತ್ಯಂತ ಕಡಿಮೆ (₹5 ಲಕ್ಷದವರೆಗೆ ಡಿಐಸಿಜಿಸಿ ವಿಮೆ)"},
                    {"aspect": "ನಗದು ಸೌಲಭ್ಯ", "value": "ಮಧ್ಯಮ (ಸ್ವಲ್ಪ ದಂಡದೊಂದಿಗೆ ಮುಂಚಿತವಾಗಿ ಮುಕ್ತಾಯಗೊಳಿಸಬಹುದು)"},
                    {"aspect": "ಅವಧಿ", "value": "6 ತಿಂಗಳಿಂದ 10 ವರ್ಷಗಳು"},
                    {"aspect": "ನಿರೀಕ್ಷಿತ ಬಡ್ಡಿ", "value": "ವಾರ್ಷಿಕ 6.5%–7.25% (ಬ್ಯಾಂಕ್ ಗ್ಯಾರಂಟಿ)"},
                    {"aspect": "ತೆರಿಗೆ", "value": "ಬಡ್ಡಿ ಮೊತ್ತವು ನಿಮ್ಮ ವಾರ್ಷಿಕ ಆದಾಯದ ಪ್ರಕಾರ ತೆರಿಗೆಗೆ ಒಳಪಡುತ್ತದೆ"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ", "value": "1 ರಿಂದ 2 ವರ್ಷಗಳ ಅಲ್ಪಾವಧಿ ಗುರಿಗಳಿಗೆ ಶಿಸ್ತಿನ ಮಾಸಿಕ ಉಳಿತಾಯ"}
                ],
                "worked_example": "ಪ್ರತಿ ತಿಂಗಳು ₹5,000 ರಂತೆ 12 ತಿಂಗಳು 7.0% ಬಡ್ಡಿಯಲ್ಲಿ RD ಇಟ್ಟರೆ, ಮೆಚ್ಯೂರಿಟಿಗೆ ಅಂದಾಜು ₹62,310 ದೊರೆಯುತ್ತದೆ.",
                "key_takeaway": "ಮಾರುಕಟ್ಟೆ ಅಪಾಯವಿಲ್ಲದೆ ಮಾಸಿಕ ಉಳಿತಾಯವನ್ನು ದೊಡ್ಡ ನಿಧಿಯನ್ನಾಗಿ ಪರಿವರ್ತಿಸಲು RD ಸೂಕ್ತ.",
                "compliance_note": "ಇದು ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ.",
                "related_topics": ["ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ (FD)", "SIP", "ಉಳಿತಾಯ ಖಾತೆ"]
            },
            "te-IN": {
                "topic": "రికరింగ్ డిపాజిట్ (RD)",
                "summary": "ప్రతి నెలా కొంత నిర్దిష్ట మొత్తాన్ని బ్యాంకులో దాచుకుంటూ స్థిరమైన గ్యారెంటీడ్ వడ్డీతో పెద్ద మొత్తాన్ని నిర్మించుకోవడానికి RD తోడ్పడుతుంది.",
                "how_it_works": "మీరు ఎంచుకున్న కాలపరిమితికి (6 నెలల నుండి 10 సంవత్సరాలు) ప్రతి నెలా ఒక నిర్దిష్ట మొత్తం జమ చేస్తారు. గడువు ముగిసిన తర్వాత చక్రవడ్డీతో కలిపి మొత్తం డబ్బు చేతికి వస్తుంది.",
                "comparison_table": [
                    {"aspect": "రిస్క్", "value": "చాలా తక్కువ (ఆర్బీఐ నిబంధనల ప్రకారం ₹5 లక్షల వరకు బీమా)"},
                    {"aspect": "లిక్విడిటీ", "value": "మధ్యస్థం (స్వల్ప పెనాల్టీతో ముందే ముగించవచ్చు)"},
                    {"aspect": "కాలపరిమితి", "value": "6 నెలల నుండి 10 సంవత్సరాలు"},
                    {"aspect": "వడ్డీ రేటు", "value": "వార్షికంగా 6.5%–7.25% (బ్యాంకు గ్యారెంటీ)"},
                    {"aspect": "పన్ను", "value": "వడ్డీ మొత్తంపై మీ వ్యక్తిగత ఆదాయ స్లాబ్ ప్రకారం పన్ను ఉంటుంది"},
                    {"aspect": "ఎవరికి అనుకూలం", "value": "1-2 ఏళ్ల స్వల్పకాలిక లక్ష్యాల కోసం క్రమశిక్షణతో కూడిన నెలవారీ పొదుపు"}
                ],
                "worked_example": "నెలకు ₹5,000 చొప్పున 12 నెలలు 7.0% వడ్డీతో RD చేస్తే, గడువు ముగిసేసరికి సుమారు ₹62,310 అందుతాయి.",
                "key_takeaway": "మార్కెట్ రిస్క్ లేకుండా సురక్షితంగా నెలవారీ పొదుపు పెంచుకోవడానికి RD ఉత్తమమైనది.",
                "compliance_note": "ఇది కేవలం అవగాహన కొరకు మాత్రమే.",
                "related_topics": ["ఫిక్స్‌డ్ డిపాజిట్ (FD)", "SIP", "సేవింగ్స్ ఖాతా"]
            }
        },
        "ppf": {
            "en-IN": {
                "topic": "Public Provident Fund (PPF)",
                "summary": "Public Provident Fund (PPF) is a government-backed, 15-year long-term savings scheme offering guaranteed, tax-free returns under Section 80C.",
                "how_it_works": "You can invest between ₹500 and ₹1,50,000 per financial year in a PPF account at a bank or post office. The interest rate is declared quarterly by the Government of India. It has Sovereign backing with the coveted EEE (Exempt-Exempt-Exempt) tax status.",
                "comparison_table": [
                    {"aspect": "Risk", "value": "Virtually Zero (Sovereign guarantee by Government of India)"},
                    {"aspect": "Liquidity", "value": "Low (Partial withdrawals permitted after 7th year; loans available from 3rd to 6th year)"},
                    {"aspect": "Lock-in", "value": "15 years (Can be extended in 5-year blocks indefinitely)"},
                    {"aspect": "Typical return range", "value": "7.1% p.a. (Government-declared, compounded annually)"},
                    {"aspect": "Taxation", "value": "EEE Status: Deposit deductible under 80C, Interest is tax-free, Maturity is completely tax-free"},
                    {"aspect": "Best suited for", "value": "Long-term goals (retirement, child's higher education) and complete safety"}
                ],
                "worked_example": "Investing ₹1,00,000 annually in PPF for 15 years at an illustrative 7.1% p.a. yields approximately ₹27.12 Lakh completely tax-free on total deposits of ₹15 Lakh.",
                "key_takeaway": "PPF is India's most secure long-term compounding vehicle with 100% tax-free maturity.",
                "compliance_note": "Educational information only — not investment advice.",
                "related_topics": ["National Pension System (NPS)", "ELSS", "Fixed Deposit (FD)"]
            },
            "hi-IN": {
                "topic": "पब्लिक प्रोविडेंट फंड (PPF)",
                "summary": "पब्लिक प्रोविडेंट फंड (PPF) भारत सरकार द्वारा समर्थित 15 साल की बचत योजना है, जो धारा 80C के तहत 100% टैक्स-फ्री रिटर्न देती है।",
                "how_it_works": "एक वित्तीय वर्ष में ₹500 से ₹1,50,000 तक बैंक या पोस्ट ऑफिस में जमा किया जा सकता है। सरकार हर तिमाही ब्याज दर तय करती है। इसमें EEE (जमा, ब्याज और मैच्योरिटी तीनों टैक्स-फ्री) लाभ मिलता है।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "शून्य (भारत सरकार की संप्रभु गारंटी)"},
                    {"aspect": "तरलता", "value": "कम (7वें वर्ष के बाद आंशिक निकासी संभव)"},
                    {"aspect": "लॉक-इन", "value": "15 वर्ष (5-5 साल के ब्लॉक में आगे बढ़ा सकते हैं)"},
                    {"aspect": "ब्याज दर", "value": "7.1% वार्षिक (सरकारी घोषणा अनुसार, वार्षिक चक्रवृद्धि)"},
                    {"aspect": "टैक्स छूट", "value": "EEE स्टेटस: निवेश, ब्याज और निकासी तीनों पूरी तरह टैक्स-फ्री"},
                    {"aspect": "किसके लिए उपयुक्त", "value": "रिटायरमेंट और बच्चों की उच्च शिक्षा जैसे दीर्घकालिक लक्ष्यों के लिए"}
                ],
                "worked_example": "यदि आप हर साल ₹1,00,000 PPF में 15 साल तक 7.1% की दर से जमा करते हैं, तो ₹15 लाख के कुल निवेश पर लगभग ₹27.12 लाख पूरी तरह टैक्स-फ्री मिलेंगे।",
                "key_takeaway": "PPF भारत में पूरी तरह सुरक्षित और टैक्स-फ्री वेल्थ बनाने की सर्वोत्तम सरकारी योजना है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है।",
                "related_topics": ["राष्ट्रीय पेंशन प्रणाली (NPS)", "ELSS", "फिक्स्ड डिपॉजिट (FD)"]
            },
            "kn-IN": {
                "topic": "ಪಬ್ಲಿಕ್ ಪ್ರಾವಿಡೆಂಟ್ ಫಂಡ್ (PPF)",
                "summary": "PPF ಕೇಂದ್ರ ಸರ್ಕಾರದ 15 ವರ್ಷಗಳ ದೀರ್ಘಾವಧಿ ಉಳಿತಾಯ ಯೋಜನೆಯಾಗಿದ್ದು, ಸೆಕ್ಷನ್ 80C ಅಡಿಯಲ್ಲಿ ಸಂಪೂರ್ಣ ತೆರಿಗೆ ಮುಕ್ತ ಆದಾಯವನ್ನು ನೀಡುತ್ತದೆ.",
                "how_it_works": "ಪ್ರತಿ ಆರ್ಥಿಕ ವರ್ಷದಲ್ಲಿ ₹500 ರಿಂದ ₹1,50,000 ವರೆಗೆ ಬ್ಯಾಂಕ್ ಅಥವಾ ಅಂಚೆ ಕಚೇರಿಯಲ್ಲಿ ಠೇವಣಿ ಮಾಡಬಹುದು. ಇದಕ್ಕೆ EEE ತೆರಿಗೆ ವಿನಾಯಿತಿ ಇದ್ದು, ಹೂಡಿಕೆ, ಬಡ್ಡಿ ಮತ್ತು ಮೆಚ್ಯೂರಿಟಿ ಹಣಕ್ಕೆ ಸಂಪೂರ್ಣ ತೆರಿಗೆ ವಿನಾಯಿತಿ ಇದೆ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ", "value": "ಶೂನ್ಯ (ಕೇಂದ್ರ ಸರ್ಕಾರದ ನೇರ ಭದ್ರತೆ)"},
                    {"aspect": "ನಗದು ಸೌಲಭ್ಯ", "value": "ಕಡಿಮೆ (7 ನೇ ವರ್ಷದ ನಂತರ ಭಾಗಶಃ ಹಿಂಪಡೆಯಲು ಅವಕಾಶ)"},
                    {"aspect": "ಲಾಕ್-ಇನ್", "value": "15 ವರ್ಷಗಳು (ಮುಂದೆ 5 ವರ್ಷಗಳ ಬ್ಲಾಕ್‌ನಲ್ಲಿ ವಿಸ್ತರಿಸಬಹುದು)"},
                    {"aspect": "ಬಡ್ಡಿ ದರ", "value": "ವಾರ್ಷಿಕ 7.1% (ಸರ್ಕಾರಿ ನಿಗದಿತ)"},
                    {"aspect": "ತೆರಿಗೆ ವಿನಾಯಿತಿ", "value": "EEE ಸ್ಥಾನಮಾನ: ಹೂಡಿಕೆ, ಬಡ್ಡಿ, ಮೆಚ್ಯೂರಿಟಿ ಎಲ್ಲವೂ ತೆರಿಗೆ ಮುಕ್ತ"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ", "value": "ನಿವೃತ್ತಿ ಮತ್ತು ಮಕ್ಕಳ ಶಿಕ್ಷಣದಂತಹ ದೀರ್ಘಾವಧಿ ಸುರಕ್ಷಿತ ಗುರಿಗಳಿಗೆ"}
                ],
                "worked_example": "ವರ್ಷಕ್ಕೆ ₹1,00,000 ರಂತೆ 15 ವರ್ಷ 7.1% ದರದಲ್ಲಿ PPF ನಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿದರೆ, ನಿಮ್ಮ ₹15 ಲಕ್ಷಕ್ಕೆ ಅಂದಾಜು ₹27.12 ಲಕ್ಷ ತೆರಿಗೆ ಮುಕ್ತವಾಗಿ ಲಭಿಸುತ್ತದೆ.",
                "key_takeaway": "ಸರ್ಕಾರಿ ಗ್ಯಾರಂಟಿಯೊಂದಿಗೆ ಸಂಪೂರ್ಣ ತೆರಿಗೆ ಮುಕ್ತ ದೀರ್ಘಾವಧಿ ಉಳಿತಾಯಕ್ಕೆ PPF ಅತ್ಯುತ್ತಮ.",
                "compliance_note": "ಇದು ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ.",
                "related_topics": ["ರಾಷ್ಟ್ರೀಯ ಪಿಂಚಣಿ ಯೋಜನೆ (NPS)", "ELSS", "FD"]
            },
            "te-IN": {
                "topic": "పబ్లిక్ ప్రావిడెంట్ ఫండ్ (PPF)",
                "summary": "PPF అనేది కేంద్ర ప్రభుత్వ మద్దతు ఉన్న 15 సంవత్సరాల దీర్ఘకాలిక పొదుపు పథకం. ఇది సెక్షన్ 80C కింద పూర్తి పన్ను రహిత రాబడిని అందిస్తుంది.",
                "how_it_works": "సంవత్సరానికి ₹500 నుండి ₹1,50,000 వరకు బ్యాంకు లేదా పోస్టాఫీసులో డిపాజిట్ చేయవచ్చు. దీనికి EEE హోదా ఉంటుంది — పెట్టుబడి, వడ్డీ, గడువు ముగిసిన తర్వాత వచ్చే మొత్తం మూడూ పన్ను రహితం.",
                "comparison_table": [
                    {"aspect": "రిస్క్", "value": "సున్నా (భారత ప్రభుత్వ సార్వభౌమ హామీ)"},
                    {"aspect": "లిక్విడిటీ", "value": "తక్కువ (7వ సంవత్సరం తర్వాత పాక్షిక విత్‌డ్రాయల్ అనుమతించబడుతుంది)"},
                    {"aspect": "లాక్-ఇన్", "value": "15 సంవత్సరాలు (మరో 5 సంవత్సరాల చొప్పున పొడిగించవచ్చు)"},
                    {"aspect": "వడ్డీ రేటు", "value": "వార్షికంగా 7.1% (ప్రభుత్వ ప్రకటన ప్రకారం)"},
                    {"aspect": "పన్ను ప్రయోజనం", "value": "EEE హోదా: అసలు, వడ్డీ, రాబడి అంతా 100% పన్ను రహితం"},
                    {"aspect": "ఎవరికి అనుకూలం", "value": "రిటైర్మెంట్, పిల్లల భవిష్యత్తు కోసం దీర్ఘకాలిక సురక్షిత పెట్టుబడిదారులకు"}
                ],
                "worked_example": "సంవత్సరానికి ₹1,00,000 చొప్పున 15 ఏళ్లు 7.1% వడ్డీతో PPF లో డిపాజిట్ చేస్తే, ₹15 లక్షల పెట్టుబడికి సుమారు ₹27.12 లక్షలు పూర్తి పన్ను రహితంగా అందుతాయి.",
                "key_takeaway": "పూర్తి భద్రత మరియు పన్ను రహిత దీర్ఘకాలిక సంపద సృష్టికి PPF అత్యుత్తమమైనది.",
                "compliance_note": "ఇది కేవలం విద్యా ప్రయోజనాల కొరకు మాత్రమే.",
                "related_topics": ["నేషనల్ పెన్షన్ సిస్టమ్ (NPS)", "ELSS", "FD"]
            }
        },
        "mutual_funds": {
            "en-IN": {
                "topic": "Mutual Funds",
                "summary": "A Mutual Fund pools money from thousands of investors to invest in a professionally managed diversified portfolio of stocks, bonds, or money market instruments.",
                "how_it_works": "Professional fund managers handle research and asset allocation. You buy 'units' at the fund's Net Asset Value (NAV). Types include Equity Funds (high growth, higher volatility), Debt Funds (steady income, lower risk), and Hybrid Funds (balanced mix).",
                "comparison_table": [
                    {"aspect": "Risk", "value": "Low to High (Depends on asset class: Debt vs Large Cap vs Small Cap)"},
                    {"aspect": "Liquidity", "value": "High (Redeem in T+2 business days for open-ended schemes)"},
                    {"aspect": "Lock-in", "value": "None for open-ended funds; 3 years for ELSS"},
                    {"aspect": "Typical return range", "value": "7%–9% for Debt; 11%–15% for Equity historical averages (Illustrative, not guaranteed)"},
                    {"aspect": "Taxation", "value": "Equity LTCG > ₹1.25L at 12.5%, STCG at 20%; Debt taxed as per income slab"},
                    {"aspect": "Best suited for", "value": "Diversified wealth creation for 3 to 10+ year time horizons"}
                ],
                "worked_example": "Investing ₹10,000 in an index mutual fund tracking Nifty 50 gives you fractional ownership in India's top 50 companies with a single click.",
                "key_takeaway": "Mutual funds offer instant professional diversification and accessibility for any budget.",
                "compliance_note": "Educational information only — not investment advice. Mutual fund investments are subject to market risks.",
                "related_topics": ["SIP", "Index Funds", "ELSS"]
            },
            "hi-IN": {
                "topic": "म्यूचुअल फंड (Mutual Funds)",
                "summary": "म्यूचुअल फंड कई निवेशकों से पैसा इकट्ठा करके पेशेवर फंड मैनेजरों द्वारा शेयर, बॉन्ड या मनी मार्केट में निवेश करने का माध्यम है।",
                "how_it_works": "फंड मैनेजर विभिन्न कंपनियों का अध्ययन करके निवेश करते हैं। आपको एनएवी (NAV) पर यूनिट्स मिलती हैं। इक्विटी फंड लंबी अवधि के लिए और डेट फंड स्थिरता के लिए होते हैं।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "कम से उच्च (इक्विटी बनाम डेट फंड के आधार पर)"},
                    {"aspect": "तरलता", "value": "उच्च (ओपन-एंडेड फंड में कभी भी निकासी संभव)"},
                    {"aspect": "लॉक-इन", "value": "सामान्य फंड में कोई नहीं (ELSS में 3 साल)"},
                    {"aspect": "रिटर्न संभावना", "value": "इक्विटी 11%–15%, डेट 7%–9% सांकेतिक ऐतिहासिक औसत"},
                    {"aspect": "टैक्स", "value": "इक्विटी LTCG 12.5% (₹1.25 लाख से ऊपर), STCG 20%"},
                    {"aspect": "किसके लिए उपयुक्त", "value": "3 से 10+ साल के विविधीकृत संपत्ति निर्माण के लिए"}
                ],
                "worked_example": "निफ्टी 50 इंडेक्स फंड में ₹10,000 का निवेश करने पर आपको भारत की शीर्ष 50 कंपनियों में एक साथ हिस्सेदारी मिल जाती है।",
                "key_takeaway": "म्यूचुअल फंड कम पूंजी में भी पेशेवर निवेश और विविधीकरण (Diversification) का लाभ देते हैं।",
                "compliance_note": "म्यूचुअल फंड बाजार जोखिमों के अधीन हैं। निवेश से पहले योजना दस्तावेज ध्यान से पढ़ें।",
                "related_topics": ["SIP", "इंडेक्स फंड", "ELSS"]
            },
            "kn-IN": {
                "topic": "ಮ್ಯೂಚುವಲ್ ಫಂಡ್‌ಗಳು (Mutual Funds)",
                "summary": "ಮ್ಯೂಚುವಲ್ ಫಂಡ್ ಅನೇಕ ಹೂಡಿಕೆದಾರರಿಂದ ಹಣವನ್ನು ಸಂಗ್ರಹಿಸಿ, ನುರಿತ ಫಂಡ್ ಮ್ಯಾನೇಜರ್‌ಗಳ ಮೂಲಕ ಷೇರುಗಳು ಮತ್ತು ಬಾಂಡ್‌ಗಳಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡುವ ವಿಧಾನವಾಗಿದೆ.",
                "how_it_works": "ವೃತ್ತಿಪರ ಮ್ಯಾನೇಜರ್‌ಗಳು ಹಣವನ್ನು ನಿರ್ವಹಿಸುತ್ತಾರೆ. ಹೂಡಿಕೆದಾರರಿಗೆ ಎನ್‌ಎವಿ (NAV) ದರದಲ್ಲಿ ಯೂನಿಟ್‌ಗಳನ್ನು ನೀಡಲಾಗುತ್ತದೆ. ಈಕ್ವಿಟಿ ಫಂಡ್‌ಗಳು ಬೆಳವಣಿಗೆಗೆ ಮತ್ತು ಡೆಟ್ ಫಂಡ್‌ಗಳು ಸ್ಥಿರತೆಗೆ ಸಹಕಾರಿ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ", "value": "ಕಡಿಮೆಯಿಂದ ಗರಿಷ್ಠ (ಫಂಡ್ ಪ್ರಕಾರಕ್ಕೆ ಅನುಗುಣವಾಗಿ)"},
                    {"aspect": "ನಗದು ಸೌಲಭ್ಯ", "value": "ಉತ್ತಮ (ಯಾವಾಗ ಬೇಕಾದರೂ ಹಿಂಪಡೆಯಬಹುದು)"},
                    {"aspect": "ಲಾಕ್-ಇನ್", "value": "ಯಾವುದೂ ಇಲ್ಲ (ELSS ತೆರಿಗೆ ಉಳಿತಾಯ ಫಂಡ್‌ಗೆ ಮಾತ್ರ 3 ವರ್ಷ)"},
                    {"aspect": "ನಿರೀಕ್ಷಿತ ರಿಟರ್ನ್", "value": "ಈಕ್ವಿಟಿ 11%–15%, ಡೆಟ್ 7%–9% ಐತಿಹಾಸಿಕ ವಿವರಣಾತ್ಮಕ"},
                    {"aspect": "ತೆರಿಗೆ", "value": "ದೀರ್ಘಾವಧಿ ಲಾಭ ₹1.25 ಲಕ್ಷ ಮೀರಿದರೆ 12.5%"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ", "value": "3 ರಿಂದ 10+ ವರ್ಷಗಳ ದೀರ್ಘಾವಧಿ ಸಂಪತ್ತು ಸೃಷ್ಟಿಗೆ"}
                ],
                "worked_example": "ನಿಫ್ಟಿ 50 ಇಂಡೆಕ್ಸ್ ಫಂಡ್‌ನಲ್ಲಿ ₹10,000 ಹೂಡಿಕೆ ಮಾಡುವುದರಿಂದ ಭಾರತದ ಟಾಪ್ 50 ಕಂಪನಿಗಳಲ್ಲಿ ನೇರ ಪಾಲುದಾರಿಕೆ ಲಭಿಸುತ್ತದೆ.",
                "key_takeaway": "ಕಡಿಮೆ ಮೊತ್ತದಲ್ಲೂ ತಜ್ಞರ ನಿರ್ವಹಣೆ ಮತ್ತು ಹೂಡಿಕೆ ವೈವಿಧ್ಯತೆಗೆ ಮ್ಯೂಚುವಲ್ ಫಂಡ್ ಸೂಕ್ತ.",
                "compliance_note": "ಮ್ಯೂಚುವಲ್ ಫಂಡ್ ಹೂಡಿಕೆಗಳು ಮಾರುಕಟ್ಟೆ ಅಪಾಯಗಳಿಗೆ ಒಳಪಟ್ಟಿರುತ್ತವೆ.",
                "related_topics": ["SIP", "ಇಂಡೆಕ್ಸ್ ಫಂಡ್‌ಗಳು", "ELSS"]
            },
            "te-IN": {
                "topic": "మ్యూచువల్ ఫండ్స్ (Mutual Funds)",
                "summary": "మ్యూచువల్ ఫండ్ అనేది వేలాది మంది పెట్టుబడిదారుల నుండి నిధులను సేకరించి, నిపుణులైన ఫండ్ మేనేజర్ల ద్వారా షేర్లు, బాండ్లలో పెట్టుబడి పెట్టే వ్యవస్థ.",
                "how_it_works": "ఫండ్ మేనేజర్లు మార్కెట్ పరిశోధన ఆధారంగా పెట్టుబడులను నిర్వహిస్తారు. పెట్టుబడిదారులకు ఎన్ఏవీ (NAV) వద్ద యూనిట్లు కేటాయిస్తారు.",
                "comparison_table": [
                    {"aspect": "రిస్క్", "value": "తక్కువ నుండి ఎక్కువ (ఈక్విటీ లేదా డెట్ ఫండ్ ఆధారంగా)"},
                    {"aspect": "లిక్విడిటీ", "value": "ఎక్కువ (ఎప్పుడైనా వెనక్కి తీసుకోవచ్చు)"},
                    {"aspect": "లాక్-ఇన్", "value": "ఏమీ లేదు (ELSS కు మాత్రమే 3 సంవత్సరాలు)"},
                    {"aspect": "రాబడి రేంజ్", "value": "ఈక్విటీ 11%–15%, డెట్ 7%–9% చారిత్రక సగటు"},
                    {"aspect": "పన్ను విధానం", "value": "ఈక్విటీ దీర్ఘకాలిక లాభం ₹1.25 లక్షల పైన 12.5%"},
                    {"aspect": "ఎవరికి అనుకూలం", "value": "3 నుండి 10+ సంవత్సరాల దీర్ಘకాలిక సంపద సృష్టికి"}
                ],
                "worked_example": "నిఫ్టీ 50 ఇండెక్స్ ఫండ్‌లో ₹10,000 పెట్టుబడి పెట్టడం ద్వారా భారతదేశపు అగ్రశ్రేణి 50 కంపెనీలలో ఒకేసారి వాటా లభిస్తుంది.",
                "key_takeaway": "తక్కువ మొత్తంతో కూడా వృత్తిపరమైన వైవిధ్యభరిత పెట్టుబడికి మ్యూచువల్ ఫండ్స్ ఉత్తమం.",
                "compliance_note": "మ్యూచువల్ ఫండ్ పెట్టుబడులు మార్కెట్ రిస్కులకు లోబడి ఉంటాయి.",
                "related_topics": ["SIP", "ఇండెక్స్ ఫండ్స్", "ELSS"]
            }
        },
        "nps": {
            "en-IN": {
                "topic": "National Pension System (NPS)",
                "summary": "A government-sponsored voluntary retirement savings scheme that allows you to invest systematically in a mix of equity, corporate debt, and government bonds.",
                "how_it_works": "You open a Tier-1 account. Contributions qualify for exclusive tax deductions up to ₹50,000 under Section 80CCD(1B) beyond the ₹1.5L 80C limit. At age 60, up to 60% can be withdrawn completely tax-free, while the remaining 40% purchases a monthly pension annuity.",
                "comparison_table": [
                    {"aspect": "Risk", "value": "Low to Moderate (Regulated by PFRDA with market-linked asset choices)"},
                    {"aspect": "Liquidity", "value": "Low (Locked until age 60; partial withdrawal allowed under strict conditions)"},
                    {"aspect": "Lock-in", "value": "Until age 60"},
                    {"aspect": "Typical return range", "value": "9%–11% p.a. illustrative historical average"},
                    {"aspect": "Taxation", "value": "Exclusive extra ₹50,000 deduction under 80CCD(1B); 60% lump sum tax-free at retirement"},
                    {"aspect": "Best suited for", "value": "Retirement corpus building and additional tax savings for working professionals"}
                ],
                "worked_example": "Investing ₹5,000/month in NPS for 25 years at an illustrative 10% p.a. can build a retirement corpus of approximately ₹67.9 Lakh.",
                "key_takeaway": "NPS provides the lowest-cost retirement compounding with exclusive tax savings beyond 80C.",
                "compliance_note": "Educational information only — not investment advice. PFRDA regulates NPS.",
                "related_topics": ["Public Provident Fund (PPF)", "ELSS", "Mutual Funds"]
            },
            "hi-IN": {
                "topic": "राष्ट्रीय पेंशन प्रणाली (NPS)",
                "summary": "NPS एक सरकारी सेवानिवृत्ति बचत योजना है जो आपको शेयर, कॉर्पोरेट बॉन्ड और सरकारी प्रतिभूतियों में निवेश कर सुरक्षित पेंशन फंड बनाने में मदद करती है।",
                "how_it_works": "आप टियर-1 खाता खोलते हैं। इसमें धारा 80C के ₹1.5 लाख के अतिरिक्त ₹50,000 की विशेष टैक्स छूट (धारा 80CCD(1B)) मिलती है। 60 वर्ष की आयु में 60% राशि टैक्स-फ्री मिलती है और 40% से मासिक पेंशन मिलती है।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "कम से मध्यम (PFRDA द्वारा विनियमित)"},
                    {"aspect": "तरलता", "value": "कम (60 वर्ष की आयु तक लॉक)"},
                    {"aspect": "लॉक-इन", "value": "60 वर्ष की आयु तक"},
                    {"aspect": "अनुमानित रिटर्न", "value": "9%–11% वार्षिक सांकेतिक ऐतिहासिक औसत"},
                    {"aspect": "टैक्स लाभ", "value": "धारा 80CCD(1B) के तहत ₹50,000 की अतिरिक्त छूट; 60% निकासी टैक्स-फ्री"},
                    {"aspect": "किसके लिए उपयुक्त", "value": "रिटायरमेंट प्लानिंग और टैक्स बचाने वाले वेतनभोगी व पेशेवरों के लिए"}
                ],
                "worked_example": "यदि आप 25 वर्ष तक हर महीने ₹5,000 NPS में 10% की सांकेतिक दर से जमा करते हैं, तो लगभग ₹67.9 लाख का बड़ा रिटायरमेंट फंड बन सकता है।",
                "key_takeaway": "NPS धारा 80C से अलग ₹50,000 की अतिरिक्त टैक्स छूट और बुढ़ापे की सुरक्षा देता है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है।",
                "related_topics": ["पब्लिक प्रोविडेंट फंड (PPF)", "ELSS", "म्यूचुअल फंड"]
            },
            "kn-IN": {
                "topic": "ರಾಷ್ಟ್ರೀಯ ಪಿಂಚಣಿ ಯೋಜನೆ (NPS)",
                "summary": "NPS ಕೇಂದ್ರ ಸರ್ಕಾರದ ದೀರ್ಘಾವಧಿ ನಿವೃತ್ತಿ ಉಳಿತಾಯ ಯೋಜನೆಯಾಗಿದ್ದು, ನಿವೃತ್ತಿಯ ನಂತರ ನಿಯಮಿತ ಮಾಸಿಕ ಪಿಂಚಣಿ ಮತ್ತು ಒಟ್ಟು ನಿಧಿಯನ್ನು ಒದಗಿಸುತ್ತದೆ.",
                "how_it_works": "ಟಿಯರ್-1 ಖಾತೆ ತೆರೆಯುವ ಮೂಲಕ ಹೂಡಿಕೆ ಮಾಡಲಾಗುತ್ತದೆ. ಸೆಕ್ಷನ್ 80C ಗಿಂತ ಹೆಚ್ಚುವರಿಯಾಗಿ ₹50,000 ತೆರಿಗೆ ವಿನಾಯಿತಿ (80CCD(1B)) ಸಿಗುತ್ತದೆ. 60 ವರ್ಷ ತುಂಬಿದಾಗ 60% ಹಣ ತೆರಿಗೆ ಮುಕ್ತವಾಗಿ ಬರುತ್ತದೆ, ಉಳಿದ 40% ಹಣದಿಂದ ಮಾಸಿಕ ಪಿಂಚಣಿ ದೊರೆಯುತ್ತದೆ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ", "value": "ಕಡಿಮೆಯಿಂದ ಮಧ್ಯಮ (PFRDA ನಿಯಂತ್ರಿತ)"},
                    {"aspect": "ನಗದು ಸೌಲಭ್ಯ", "value": "ಕಡಿಮೆ (60 ವರ್ಷದವರೆಗೆ ಲಾಕ್)"},
                    {"aspect": "ಅವಧಿ", "value": "60 ವರ್ಷಗಳವರೆಗೆ"},
                    {"aspect": "ನಿರೀಕ್ಷಿತ ರಿಟರ್ನ್", "value": "ವಾರ್ಷಿಕ 9%–11% ಐತಿಹಾಸಿಕ ವಿವರಣಾತ್ಮಕ"},
                    {"aspect": "ತೆರಿಗೆ ಲಾಭ", "value": "ಸೆಕ್ಷನ್ 80CCD(1B) ಅಡಿಯಲ್ಲಿ ಹೆಚ್ಚುವರಿ ₹50,000 ತೆರಿಗೆ ವಿನಾಯಿತಿ"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ", "value": "ನಿವೃತ್ತಿ ಯೋಜನೆ ಮತ್ತು ತೆರಿಗೆ ಉಳಿಸುವ ಉದ್ಯೋಗಿಗಳಿಗೆ"}
                ],
                "worked_example": "ತಿಂಗಳಿಗೆ ₹5,000 ರಂತೆ 25 ವರ್ಷ 10% ದರದಲ್ಲಿ NPS ನಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿದರೆ ಅಂದಾಜು ₹67.9 ಲಕ್ಷ ನಿವೃತ್ತಿ ನಿಧಿ ಸೃಷ್ಟಿಯಾಗುತ್ತದೆ.",
                "key_takeaway": "80C ಹೊರತಾಗಿ ಹೆಚ್ಚುವರಿ ತೆರಿಗೆ ವಿನಾಯಿತಿ ಮತ್ತು ಪಿಂಚಣಿ ಭದ್ರತೆಗೆ NPS ಅತ್ಯುತ್ತಮ.",
                "compliance_note": "ಇದು ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ.",
                "related_topics": ["PPF", "ELSS", "ಮ್ಯೂಚುವಲ್ ಫಂಡ್‌ಗಳು"]
            },
            "te-IN": {
                "topic": "నేషనల్ పెన్షన్ సిస్టమ్ (NPS)",
                "summary": "NPS అనేది కేంద్ర ప్రభుత్వ ఆధ్వర్యంలో నడిచే పదవీ విరమణ పొదుపు పథకం. ఇది రిటైర్మెంట్ తర్వాత నెలవారీ పెన్షన్ మరియు ఏకమొత్తం నిధిని అందిస్తుంది.",
                "how_it_works": "టైర్-1 ఖాతా ద్వారా ఈక్విటీ, బాండ్లలో పెట్టుబడి పెడతారు. సెక్షన్ 80C కి అదనంగా ₹50,000 ప్రత్యేక పన్ను మినహాయింపు (80CCD(1B)) లభిస్తుంది. 60 ఏళ్ల వయస్సులో 60% మొత్తం పన్ను రహితంగా అందుతుంది, 40% ద్వారా జీవితాంతం పెన్షన్ లభిస్తుంది.",
                "comparison_table": [
                    {"aspect": "రిస్క్", "value": "తక్కువ నుండి మధ్యస్థం (PFRDA నిబంధనలు)"},
                    {"aspect": "లిక్విడిటీ", "value": "తక్కువ (60 ఏళ్ల వరకు లాక్ చేయబడుతుంది)"},
                    {"aspect": "కాలపరిమితి", "value": "60 సంవత్సరాల వయస్సు వరకు"},
                    {"aspect": "రాబడి రేంజ్", "value": "వార్షికంగా 9%–11% చారిత్రక సగటు"},
                    {"aspect": "పన్ను ప్రయోజనం", "value": "సెక్షన్ 80CCD(1B) కింద అదనంగా ₹50,000 తగ్గింపు; 60% రిటైర్మెంట్ కార్పస్ పన్ను రహితం"},
                    {"aspect": "ఎవరికి అనుకూలం", "value": "పదవీ విరమణ ప్రణాళిక మరియు పన్ను ఆదా చేసుకోవాలనుకునే ఉద్యోగులకు"}
                ],
                "worked_example": "నెలకు ₹5,000 చొప్పున 25 సంవత్సరాలు 10% వడ్డీతో NPS లో జమ చేస్తే సుమారు ₹67.9 లక్షల రిటైర్మెంట్ ఫండ్ సమకూరుతుంది.",
                "key_takeaway": "అదనపు పన్ను మినహాయింపుతో వృద్ధాప్య ఆర్థిక భద్రతకు NPS తిరుగులేని సాధనం.",
                "compliance_note": "ఇది కేవలం సమాచార ప్రయోజనాల కొరకు మాత్రమే.",
                "related_topics": ["పీపీఎఫ్ (PPF)", "ELSS", "మ్యూచువల్ ఫండ్స్"]
            }
        },
        "elss": {
            "en-IN": {
                "topic": "ELSS (Tax-Saving Mutual Fund)",
                "summary": "Equity Linked Savings Scheme (ELSS) is a diversified equity mutual fund offering tax deductions up to ₹1.5 Lakh under Section 80C with India's shortest lock-in period of 3 years.",
                "how_it_works": "At least 80% of funds are invested in diversified equities for high wealth creation potential. Each installment (in case of SIP) has an independent 3-year lock-in from the date of investment.",
                "comparison_table": [
                    {"aspect": "Risk", "value": "High (Direct equity market linked)"},
                    {"aspect": "Liquidity", "value": "Moderate (Shortest lock-in of 3 years among all 80C options)"},
                    {"aspect": "Lock-in", "value": "3 years per investment/SIP installment"},
                    {"aspect": "Typical return range", "value": "12%–15% p.a. illustrative historical average"},
                    {"aspect": "Taxation", "value": "Deduction up to ₹1.5L under Sec 80C; LTCG above ₹1.25L taxed at 12.5% upon redemption"},
                    {"aspect": "Best suited for", "value": "Tax planning with higher long-term compounding potential (3 to 5+ years)"}
                ],
                "worked_example": "Investing ₹12,500/month (₹1.5 Lakh/year) in ELSS can save up to ₹46,800 in tax (at 30% slab) while building equity wealth over time.",
                "key_takeaway": "ELSS combines tax saving under 80C with equity wealth growth and the shortest 3-year lock-in.",
                "compliance_note": "Educational information only — not investment advice. Mutual fund investments are subject to market risks.",
                "related_topics": ["Public Provident Fund (PPF)", "SIP", "Mutual Funds"]
            },
            "hi-IN": {
                "topic": "ईएलएसएस (टैक्स-सेविंग म्यूचुअल फंड)",
                "summary": "ELSS एक इक्विटी म्यूचुअल फंड है जो धारा 80C के तहत ₹1.5 लाख तक की टैक्स छूट देता है और इसमें केवल 3 साल का सबसे कम लॉक-इन होता है।",
                "how_it_works": "फंड का कम से कम 80% पैसा शेयर बाजार में लगाया जाता है। इसमें टैक्स बचत के साथ-साथ लंबी अवधि में संपदा निर्माण का दोहरा लाभ मिलता है। SIP के प्रत्येक किस्त का 3 साल का स्वतंत्र लॉक-इन होता है।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "उच्च (शेयर बाजार आधारित)"},
                    {"aspect": "तरलता", "value": "मध्यम (धारा 80C विकल्पों में सबसे कम 3 साल का लॉक-इन)"},
                    {"aspect": "लॉक-इन", "value": "3 वर्ष (प्रत्येक किस्त के लिए)"},
                    {"aspect": "अनुमानित रिटर्न", "value": "12%–15% वार्षिक सांकेतिक ऐतिहासिक औसत"},
                    {"aspect": "टैक्स लाभ", "value": "धारा 80C के तहत ₹1.5 लाख तक छूट; निकासी पर ₹1.25 लाख से अधिक LTCG पर 12.5% टैक्स"},
                    {"aspect": "किसके लिए उपयुक्त", "value": "टैक्स बचत के साथ उच्च रिटर्न चाहने वाले युवा निवेशकों के लिए"}
                ],
                "worked_example": "ELSS में सालाना ₹1.5 लाख का निवेश करने पर 30% स्लैब वाले व्यक्ति को ₹46,800 तक की सीधी टैक्स बचत हो सकती है।",
                "key_takeaway": "ELSS सभी टैक्स सेविंग विकल्पों में सबसे कम 3 साल के लॉक-इन के साथ सबसे ज्यादा रिटर्न की संभावना देता है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है।",
                "related_topics": ["पब्लिक प्रोविडेंट फंड (PPF)", "SIP", "म्यूचुअल फंड"]
            },
            "kn-IN": {
                "topic": "ಇಎಲ್ಎಸ್ಎಸ್ (ತೆರಿಗೆ ಉಳಿತಾಯ ಮ್ಯೂಚುವಲ್ ಫಂಡ್)",
                "summary": "ELSS ಈಕ್ವಿಟಿ ಮ್ಯೂಚುವಲ್ ಫಂಡ್ ಆಗಿದ್ದು, ಸೆಕ್ಷನ್ 80C ಅಡಿಯಲ್ಲಿ ₹1.5 ಲಕ್ಷದವರೆಗೆ ತೆರಿಗೆ ವಿನಾಯಿತಿ ಮತ್ತು ಕೇವಲ 3 ವರ್ಷಗಳ ಅತಿ ಕಡಿಮೆ ಲಾಕ್-ಇನ್ ಅವಧಿಯನ್ನು ಹೊಂದಿದೆ.",
                "how_it_works": "ಕನಿಷ್ಠ 80% ಹಣವನ್ನು ಷೇರು ಮಾರುಕಟ್ಟೆಯಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಲಾಗುತ್ತದೆ. ಇದು ತೆರಿಗೆ ಉಳಿತಾಯದ ಜೊತೆಗೆ ದೀರ್ಘಾವಧಿಯಲ್ಲಿ ಹೆಚ್ಚಿನ ಸಂಪತ್ತು ಸೃಷ್ಟಿಸಲು ನೆರವಾಗುತ್ತದೆ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ", "value": "ಹೆಚ್ಚು (ಷೇರು ಮಾರುಕಟ್ಟೆ ಆಧಾರಿತ)"},
                    {"aspect": "ನಗದು ಸೌಲಭ್ಯ", "value": "ಮಧ್ಯಮ (80C ಆಯ್ಕೆಗಳಲ್ಲಿ ಅತ್ಯಂತ ಕಡಿಮೆ 3 ವರ್ಷಗಳ ಲಾಕ್-ಇನ್)"},
                    {"aspect": "ಲಾಕ್-ಇನ್", "value": "3 ವರ್ಷಗಳು"},
                    {"aspect": "ನಿರೀಕ್ಷಿತ ರಿಟರ್ನ್", "value": "ವಾರ್ಷಿಕ 12%–15% ಐತಿಹಾಸಿಕ ವಿವರಣಾತ್ಮಕ"},
                    {"aspect": "ತೆರಿಗೆ ವಿನಾಯಿತಿ", "value": "ಸೆಕ್ಷನ್ 80C ಅಡಿಯಲ್ಲಿ ₹1.5 ಲಕ್ಷದವರೆಗೆ ವಿನಾಯಿತಿ"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ", "value": "ತೆರಿಗೆ ಉಳಿತಾಯ ಮತ್ತು ದೀರ್ಘಾವಧಿ ಬೆಳವಣಿಗೆ ಬಯಸುವ ಹೂಡಿಕೆದಾರರಿಗೆ"}
                ],
                "worked_example": "ELSS ನಲ್ಲಿ ವರ್ಷಕ್ಕೆ ₹1.5 ಲಕ್ಷ ಹೂಡಿಕೆ ಮಾಡುವ ಮೂಲಕ ತೆರಿಗೆ ಸ್ಲ್ಯಾಬ್ ಪ್ರಕಾರ ₹46,800 ರವರೆಗೆ ತೆರಿಗೆ ಉಳಿಸಬಹುದು.",
                "key_takeaway": "ಕೇವಲ 3 ವರ್ಷಗಳ ಲಾಕ್-ಇನ್ ಮತ್ತು ಹೆಚ್ಚಿನ ಆದಾಯ ಸಾಮರ್ಥ್ಯಕ್ಕೆ ELSS ಅತ್ಯುತ್ತಮ ತೆರಿಗೆ ಉಳಿತಾಯ ಫಂಡ್.",
                "compliance_note": "ಇದು ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ.",
                "related_topics": ["PPF", "SIP", "ಮ್ಯೂಚುವಲ್ ಫಂಡ್‌ಗಳು"]
            },
            "te-IN": {
                "topic": "ఈఎల్ఎస్ఎస్ (పన్ను ఆదా మ్యూచువల్ ఫండ్)",
                "summary": "ELSS అనేది సెక్షన్ 80C కింద ₹1.5 లక్షల వరకు పన్ను మినహాయింపును అందించే ఈక్విటీ మ్యూచువల్ ఫండ్. దీనికి కేవలం 3 సంవత్సరాల లాక్-ఇన్ పీరియడ్ మాత్రమే ఉంటుంది.",
                "how_it_works": "ఈ ఫండ్‌లో 80% కంటే ఎక్కువ మొత్తం షేర్ మార్కెట్‌లో పెట్టుబడి పెట్టబడుతుంది. పన్ను ఆదా చేసుకోవడంతో పాటు దీర్ఘకాలంలో మంచి సంపద సృష్టించుకోవడానికి ఇది తోడ్పడుతుంది.",
                "comparison_table": [
                    {"aspect": "రిస్క్", "value": "ఎక్కువ (మార్కెట్ ఆధారితం)"},
                    {"aspect": "లిక్విడిటీ", "value": "మధ్యస్థం (అన్ని పన్ను ఆదా పథకాలలో అతి తక్కువ 3 ఏళ్ల లాక్-ఇన్)"},
                    {"aspect": "లాక్-ఇన్", "value": "3 సంవత్సరాలు"},
                    {"aspect": "రాబడి రేంజ్", "value": "వార్షికంగా 12%–15% చారిత్రక సగటు"},
                    {"aspect": "పన్ను ప్రయోజనం", "value": "సెక్షన్ 80C కింద ₹1.5 లక్షల వరకు తగ్గింపు; లాభం ₹1.25 లక్షల దాటితే 12.5% LTCG"},
                    {"aspect": "ఎవరికి అనుకూలం", "value": "పన్ను ఆదాతో పాటు ఎక్కువ రాబడిని కోరుకునే యువ పెట్టుబడిదారులకు"}
                ],
                "worked_example": "ELSS లో సంవత్సరానికి ₹1.5 లక్షలు పెట్టుబడి పెడితే 30% టాక్స్ స్లాబ్‌లో ఉన్న వ్యక్తికి ₹46,800 వరకు పన్ను ఆదా అవుతుంది.",
                "key_takeaway": "కేవలం 3 సంవత్సరాల లాక్-ఇన్‌తో అధిక రాబడినిచ్చే అత్యుత్తమ పన్ను ఆదా మార్గం ELSS.",
                "compliance_note": "ఇది కేవలం సమాచార ప్రయోజనాల కొరకు మాత్రమే.",
                "related_topics": ["పీపీఎఫ్ (PPF)", "SIP", "మ్యూచువల్ ఫండ్స్"]
            }
        },
        "savings": {
            "en-IN": {
                "topic": "Savings Account",
                "summary": "A foundational bank account that keeps your money secure while providing instant liquidity, debit card access, UPI connectivity, and modest interest.",
                "how_it_works": "Your money earns 2.7%–4.0% p.a. interest calculated on daily balances and credited quarterly. You can deposit and withdraw anytime through ATMs, UPI, and NetBanking. Deposits up to ₹5,00,000 are insured per bank under RBI's DICGC.",
                "comparison_table": [
                    {"aspect": "Risk", "value": "Extremely Low (Insured up to ₹5 Lakh per bank by RBI DICGC)"},
                    {"aspect": "Liquidity", "value": "Instant (UPI, ATM, Netbanking 24x7)"},
                    {"aspect": "Lock-in", "value": "None"},
                    {"aspect": "Typical return range", "value": "2.7%–4.0% p.a. (Calculated on daily balance)"},
                    {"aspect": "Taxation", "value": "Interest up to ₹10,000/yr is completely tax-free under Section 80TTA"},
                    {"aspect": "Best suited for", "value": "Daily living expenses, monthly bill payments, and immediate emergency buffer"}
                ],
                "worked_example": "Maintaining ₹50,000 in your savings account at 3.5% p.a. earns approximately ₹1,750 interest annually completely tax-free under Section 80TTA.",
                "key_takeaway": "A savings account is your primary hub for everyday cash flow, UPI payments, and emergency funds.",
                "compliance_note": "Educational information only — not investment advice. Bank deposits are insured up to ₹5 Lakh under RBI's DICGC scheme.",
                "related_topics": ["Fixed Deposit (FD)", "Recurring Deposit (RD)", "Liquid Fund"]
            },
            "hi-IN": {
                "topic": "बचत खाता (Savings Account)",
                "summary": "बचत खाता बैंक में पैसे सुरक्षित रखने, UPI और डेबिट कार्ड से तुरंत भुगतान करने और ब्याज कमाने का सबसे बुनियादी साधन है।",
                "how_it_works": "बैंक दैनिक शेष राशि पर 2.7% से 4% तक वार्षिक ब्याज देते हैं। आप UPI, ATM या नेटबैंकिंग द्वारा कभी भी पैसे निकाल या ट्रांसफर कर सकते हैं। ₹5 लाख तक का बीमा RBI की DICGC योजना के तहत होता है।",
                "comparison_table": [
                    {"aspect": "जोखिम (Risk)", "value": "अत्यंत कम (DICGC द्वारा ₹5 लाख तक पूर्ण सुरक्षित)"},
                    {"aspect": "तरलता", "value": "तत्काल (24x7 UPI, ATM, ऑनलाइन बैंकिंग)"},
                    {"aspect": "लॉक-इन", "value": "कोई नहीं"},
                    {"aspect": "ब्याज दर", "value": "2.7%–4.0% वार्षिक"},
                    {"aspect": "टैक्स लाभ", "value": "धारा 80TTA के तहत सालाना ₹10,000 तक का ब्याज पूरी तरह टैक्स-फ्री"},
                    {"aspect": "किसके लिए उपयुक्त", "value": "दैनिक खर्च, बिल भुगतान और आपातकालीन फंड (Emergency Fund) के लिए"}
                ],
                "worked_example": "बचत खाते में ₹50,000 पर 3.5% की दर से सालाना ₹1,750 ब्याज मिलता है, जिस पर धारा 80TTA के तहत शून्य टैक्स लगता है।",
                "key_takeaway": "बचत खाता आपके पैसे का मुख्य आधार है जो 24x7 लिक्विडिटी और UPI की सुविधा देता है।",
                "compliance_note": "यह केवल शैक्षिक जानकारी है।",
                "related_topics": ["फिक्स्ड डिपॉजिट (FD)", "आवर्ती जमा (RD)", "लिक्विड फंड"]
            },
            "kn-IN": {
                "topic": "ಉಳಿತಾಯ ಖಾತೆ (Savings Account)",
                "summary": "ದೈನಂದಿನ ಖರ್ಚುಗಳು, ಯುಪಿಐ ಪಾವತಿಗಳು ಮತ್ತು ತಕ್ಷಣದ ನಗದು ಅಗತ್ಯಗಳಿಗೆ ಬ್ಯಾಂಕ್‌ನಲ್ಲಿ ಹಣ ಸುರಕ್ಷಿತವಾಗಿಡಲು ಉಳಿತಾಯ ಖಾತೆ ಅತ್ಯಗತ್ಯ.",
                "how_it_works": "ದೈನಂದಿನ ಬ್ಯಾಲೆನ್ಸ್ ಆಧಾರದ ಮೇಲೆ ವಾರ್ಷಿಕ 2.7%–4% ಬಡ್ಡಿ ಸಿಗುತ್ತದೆ. ಯುಪಿಐ, ಎಟಿಎಂ ಮತ್ತು ನೆಟ್‌ಬ್ಯಾಂಕಿಂಗ್ ಮೂಲಕ ಯಾವುದೇ ಸಮಯದಲ್ಲಿ ಹಣವನ್ನು ಬಳಸಬಹುದು. ₹5 ಲಕ್ಷದವರೆಗೆ ವಿಮೆ ಇರುತ್ತದೆ.",
                "comparison_table": [
                    {"aspect": "ಅಪಾಯ", "value": "ಅತ್ಯಂತ ಕಡಿಮೆ (₹5 ಲಕ್ಷದವರೆಗೆ ಡಿಐಸಿಜಿಸಿ ವಿಮೆ)"},
                    {"aspect": "ನಗದು ಸೌಲಭ್ಯ", "value": "ತತ್ಕ್ಷಣ (24x7 UPI, ATM ಲಭ್ಯ)"},
                    {"aspect": "ಲಾಕ್-ಇನ್", "value": "ಯಾವುದೂ ಇಲ್ಲ"},
                    {"aspect": "ಬಡ್ಡಿ ದರ", "value": "ವಾರ್ಷಿಕ 2.7%–4.0%"},
                    {"aspect": "ತೆರಿಗೆ ಲಾಭ", "value": "ಸೆಕ್ಷನ್ 80TTA ಅಡಿಯಲ್ಲಿ ₹10,000 ವರೆಗಿನ ಬಡ್ಡಿಗೆ ತೆರಿಗೆ ಮುಕ್ತ"},
                    {"aspect": "ಯಾರಿಗೆ ಸೂಕ್ತ", "value": "ದೈನಂದಿನ ಖರ್ಚುಗಳು, ಬಿಲ್ ಪಾವತಿಗಳು ಮತ್ತು ತುರ್ತು ನಿಧಿಗಾಗಿ"}
                ],
                "worked_example": "ಖಾತೆಯಲ್ಲಿ ₹50,000 ಇರಿಸಿದರೆ 3.5% ದರದಲ್ಲಿ ವಾರ್ಷಿಕ ಸುಮಾರು ₹1,750 ತೆರಿಗೆ ಮುಕ್ತ ಬಡ್ಡಿ ಸಿಗುತ್ತದೆ.",
                "key_takeaway": "ತಕ್ಷಣದ ನಗದು ಅಗತ್ಯತೆ ಮತ್ತು ಸುಲಭ ಯುಪಿಐ ಪಾವತಿಗೆ ಉಳಿತಾಯ ಖಾತೆ ಪ್ರಮುಖ ಸಾಧನ.",
                "compliance_note": "ಇದು ಕೇವಲ ಶೈಕ್ಷಣಿಕ ಮಾಹಿತಿ.",
                "related_topics": ["ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್ (FD)", "ಆರ್‌ಡಿ (RD)", "ಲಿಕ್ವಿಡ್ ಫಂಡ್"]
            },
            "te-IN": {
                "topic": "పొదుపు ఖాతా (Savings Account)",
                "summary": "బ్యాంకులో డబ్బును భద్రంగా దాచుకోవడానికి, యూపీఐ మరియు ఏటీఎం ద్వారా తక్షణమే ఖర్చు చేయడానికి సేవింగ్స్ ఖాతా అత్యంత అనుకూలమైనది.",
                "how_it_works": "రోజువారీ బ్యాలెన్స్‌పై 2.7%–4.0% వార్షిక వడ్డీ లభిస్తుంది. ఎప్పుడైనా యూపీఐ లేదా ఏటీఎం ద్వారా డబ్బు విత్‌డ్రా చేసుకోవచ్చు. ₹5 లక్షల వరకు ప్రభుత్వ బీమా ఉంటుంది.",
                "comparison_table": [
                    {"aspect": "రిస్క్", "value": "చాలా తక్కువ (ఆర్బీఐ DICGC ద్వారా ₹5 లక్షల వరకు బీమా)"},
                    {"aspect": "లిక్విడిటీ", "value": "తక్షణం (24x7 UPI, ఏటీఎం అందుబాటులో ఉంటాయి)"},
                    {"aspect": "లాక్-ఇన్", "value": "ఏమీ లేదు"},
                    {"aspect": "వడ్డీ రేటు", "value": "వార్షికంగా 2.7%–4.0%"},
                    {"aspect": "పన్ను ప్రయోజనం", "value": "సెక్షన్ 80TTA కింద సంవత్సరానికి ₹10,000 వరకు వడ్డీపై పన్ను మినహాయింపు"},
                    {"aspect": "ఎవరికి అనుకూలం", "value": "రోజువారీ ఖర్చులు, బిల్లుల చెల్లింపులు మరియు అత్యవసర నిధి కోసం"}
                ],
                "worked_example": "ఖాతాలో ₹50,000 బ్యాలెన్స్ ఉంటే 3.5% చొప్పున సంవత్సరానికి ₹1,750 వరకు పన్ను రహిత వడ్డీ లభిస్తుంది.",
                "key_takeaway": "నిరంతర లిక్విడిటీ, యూపీఐ లావాదేవీలకు సేవింగ్స్ ఖాతా కేంద్ర బిందువు.",
                "compliance_note": "ఇది కేవలం సమాచార ప్రయోజనాల కొరకు మాత్రమే.",
                "related_topics": ["ఫిక్స్‌డ్ డిపాజిట్ (FD)", "రికరింగ్ డిపాజిట్ (RD)", "లిక్విడ్ ఫండ్స్"]
            }
        }
    }

    # Resolve topic key
    item = data.get(topic_key, data["sip"])
    localized = item.get(lang, item.get("en-IN", data["sip"]["en-IN"]))
    return {**localized, "error": False}
