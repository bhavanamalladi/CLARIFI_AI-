"""
CLARIFI AI — Gnani Timbre TTS Service  (Phase 6)

Wraps the Gnani Vachana TTS inference REST API.

API Reference (from docs.gnani.ai):
  POST https://api.vachana.ai/api/v1/tts/inference
  Header: X-API-Key-ID: <key>
  Body (JSON):
    text         : str   — text to synthesize (max ~2000 chars recommended)
    model        : str   — "timbre-v2.5"
    voice        : str   — voice name (language-dependent, see VOICES dict below)
    language     : str   — "en-IN" | "hi-IN" | "kn-IN" | "te-IN"
    audio_config : dict  — { encoding, container, sample_rate, num_channels, sample_width }
  Response: raw audio bytes (WAV)

Caching:
  Audio is cached in the SQLite `audio_cache` table keyed on
  SHA-256(text + language).  Same text+language hit → no API call.
"""

import hashlib
import logging
import httpx
from sqlalchemy.orm import Session

from ..config import settings
from ..models import AudioCache

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Gnani TTS endpoint (from docs — do not change)
# ---------------------------------------------------------------------------
GNANI_TTS_URL = "https://api.vachana.ai/api/v1/tts/inference"

# ---------------------------------------------------------------------------
# Voice catalogue per language (timbre-v2.5)
# Using one clear, natural-sounding voice per language.
# ---------------------------------------------------------------------------
VOICES = {
    "en-IN": "Nalini",
    "hi-IN": "Nalini",
    "kn-IN": "Kaveri",
    "te-IN": "Kaveri",
}

# ---------------------------------------------------------------------------
# Audio config (per docs)
# ---------------------------------------------------------------------------
AUDIO_CONFIG = {
    "encoding":     "linear_pcm",
    "container":    "wav",
    "sample_rate":  48000,
    "num_channels": 1,
    "sample_width": 2,
}

TTS_MODEL = "timbre-v2.5"
MAX_TEXT_LENGTH = 2000  # chars — keep TTS calls reasonable in length


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

async def synthesize(
    text: str,
    language: str,
    db: Session,
) -> bytes | None:
    """
    Convert text to speech using Gnani Timbre TTS.
    Returns raw WAV bytes, or None on failure (caller shows text-only).

    Flow:
      1. Check SQLite audio cache (hash of text+language)
      2. If cache hit → return cached bytes immediately
      3. Call Gnani TTS API
      4. Store result in cache
      5. Return WAV bytes
    """
    if not settings.gnani_api_key or settings.gnani_api_key == "your_gnani_api_key_here":
        logger.error("GNANI_API_KEY not configured — TTS unavailable")
        return None

    # Truncate very long text to avoid huge API calls
    text = text.strip()[:MAX_TEXT_LENGTH]
    if not text:
        return None

    # Normalise language code
    if language not in VOICES:
        logger.warning("Unknown TTS language '%s', defaulting to en-IN", language)
        language = "en-IN"

    # --- Cache lookup ---
    cache_key = _make_hash(text, language)
    cached = db.query(AudioCache).filter(
        AudioCache.text_hash == cache_key,
        AudioCache.language  == language,
    ).first()

    if cached:
        logger.debug("TTS cache hit for hash=%s lang=%s", cache_key[:8], language)
        return cached.audio_data

    # --- Call Gnani TTS ---
    logger.info("TTS API call: lang=%s text_len=%d", language, len(text))
    audio_bytes = await _call_gnani_tts(text, language)

    if audio_bytes is None:
        return None

    # --- Store in cache ---
    _store_cache(db, cache_key, language, audio_bytes)

    return audio_bytes


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

async def _call_gnani_tts(text: str, language: str) -> bytes | None:
    """Single HTTP call to Gnani Timbre TTS. Returns WAV bytes or None."""
    payload = {
        "text":         text,
        "model":        TTS_MODEL,
        "voice":        VOICES[language],
        "language":     language,
        "audio_config": AUDIO_CONFIG,
    }
    headers = {
        "X-API-Key-ID": settings.gnani_api_key,
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(GNANI_TTS_URL, json=payload, headers=headers)

        if response.status_code == 429:
            logger.warning("Gnani TTS rate limit (429)")
            return None

        response.raise_for_status()

        # Gnani returns raw audio bytes for the /inference endpoint
        audio_bytes = response.content
        if not audio_bytes:
            logger.error("Gnani TTS returned empty body")
            return None

        logger.info("TTS success: %d bytes received", len(audio_bytes))
        return audio_bytes

    except httpx.TimeoutException:
        logger.warning("Gnani TTS request timed out — retrying once")
        # One retry on timeout
        try:
            async with httpx.AsyncClient(timeout=30.0) as client:
                response = await client.post(GNANI_TTS_URL, json=payload, headers=headers)
            response.raise_for_status()
            return response.content or None
        except Exception as e:
            logger.error("TTS retry also failed: %s", e)
            return None

    except httpx.HTTPStatusError as e:
        logger.error("Gnani TTS HTTP error %s: %s", e.response.status_code, e)
        return None

    except Exception as e:
        logger.exception("Unexpected TTS error: %s", e)
        return None


def _make_hash(text: str, language: str) -> str:
    """SHA-256 hex digest of text + language — used as cache key."""
    payload = f"{language}:{text}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _store_cache(db: Session, text_hash: str, language: str, audio_data: bytes) -> None:
    """Persist synthesized audio to the SQLite cache table."""
    try:
        entry = AudioCache(
            text_hash  = text_hash,
            language   = language,
            audio_data = audio_data,
        )
        db.add(entry)
        db.commit()
        logger.debug("TTS cached %d bytes for hash=%s", len(audio_data), text_hash[:8])
    except Exception as e:
        logger.error("Failed to cache TTS audio: %s", e)
        db.rollback()
