"""
CLARIFI AI — Gnani Prisma STT Service
Wraps the Gnani Vachana STT v3 REST API (Prisma model).

API Reference (from docs.gnani.ai):
  POST https://api.vachana.ai/stt/v3
  Header: X-API-Key-ID: <key>
  Body (multipart/form-data):
    - audio_file: (binary) — WAV, MP3, OGG, FLAC, AAC, or M4A, max 30s
    - model: "prisma-v3.0"
    - language_code: "hi-IN" | "kn-IN" | "te-IN" | "en-IN" | "indic-auto"
  Response JSON:
    { "success": true, "transcript": "...", "detected_language_code": "...",
      "request_id": "...", "processing_time": 0.62, "end_to_end_latency": 0.71 }
"""

import logging
import httpx
from ..config import settings
from ..schemas import STTResponse

logger = logging.getLogger(__name__)

# Gnani STT endpoint (from official docs — do not change)
GNANI_STT_URL = "https://api.vachana.ai/stt/v3"

# Default STT model per docs
STT_MODEL = "prisma-v3.0"

# Language codes supported by the app
SUPPORTED_LANGUAGE_CODES = {"kn-IN", "te-IN", "hi-IN", "en-IN", "indic-auto"}


async def transcribe(
    audio_bytes: bytes,
    filename: str,
    language_code: str = "indic-auto",
) -> STTResponse:
    """
    Send audio bytes to Gnani Prisma STT and return the transcription.

    Args:
        audio_bytes: Raw audio data (webm/wav/mp3 etc.)
        filename: Original filename hint (e.g. "recording.webm")
        language_code: One of SUPPORTED_LANGUAGE_CODES

    Returns:
        STTResponse with transcript (empty string on failure)

    Raises:
        Does NOT raise — returns STTResponse(success=False, fallback=True) on error
        so the router can return a friendly fallback to the browser.
    """
    api_key = (settings.gnani_api_key or "").strip()
    if not api_key or api_key == "your_gnani_api_key_here":
        logger.error("GNANI_API_KEY is not configured")
        return STTResponse(
            success=False,
            fallback=True,
            error="Speech recognition service is currently unavailable. Please type your input.",
        )

    if language_code not in SUPPORTED_LANGUAGE_CODES:
        logger.warning("Unsupported language_code '%s', defaulting to indic-auto", language_code)
        language_code = "indic-auto"

    headers = {
        "X-API-Key-ID": api_key,
        # Note: do NOT set Content-Type here — httpx sets it automatically for multipart
    }

    # Build multipart form — field name must be "audio_file" per docs
    files = {
        "audio_file": (filename, audio_bytes, _guess_mime(filename)),
    }
    data = {
        "model": STT_MODEL,
        "language_code": language_code,
    }

    # --- First attempt (prisma-v3.0) ---
    result = await _post_to_gnani(headers, files, data)
    if result is not None:
        return result

    # --- Fallback attempt (prisma model) ---
    logger.info("STT first attempt failed, retrying with prisma model...")
    data["model"] = "prisma"
    files = {
        "audio_file": (filename, audio_bytes, _guess_mime(filename)),
    }
    result = await _post_to_gnani(headers, files, data)
    if result is not None:
        return result

    return STTResponse(
        success=False,
        fallback=True,
        error="Could not transcribe audio. Please speak clearly or type your input.",
    )


async def _post_to_gnani(headers: dict, files: dict, data: dict) -> STTResponse | None:
    """
    Single HTTP call to Gnani STT.
    Returns STTResponse on success, None on any error (so caller can retry).
    """
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                GNANI_STT_URL,
                headers=headers,
                files=files,
                data=data,
            )

        if response.status_code == 429:
            logger.warning("Gnani STT rate limit hit (429)")
            return STTResponse(
                success=False,
                fallback=True,
                error="Speech service is busy. Please wait a moment and try again.",
            )

        response.raise_for_status()
        body = response.json()

        if not body.get("success"):
            logger.error("Gnani STT returned success=false: %s", body)
            return None  # Trigger retry

        transcript = body.get("transcript", "").strip()
        if not transcript:
            logger.warning("Gnani STT returned empty transcript")
            return STTResponse(
                success=False,
                fallback=True,
                error="Could not understand the audio. Please try speaking clearly or type your input.",
            )

        return STTResponse(
            success=True,
            transcript=transcript,
            detected_language=body.get("detected_language_code", ""),
            request_id=body.get("request_id", ""),
            processing_time=body.get("processing_time"),
        )

    except httpx.TimeoutException:
        logger.warning("Gnani STT request timed out")
        return None  # Trigger retry

    except httpx.HTTPStatusError as e:
        logger.error("Gnani STT HTTP error: %s", e)
        return None

    except Exception as e:
        logger.exception("Unexpected error calling Gnani STT: %s", e)
        return None


def _guess_mime(filename: str) -> str:
    """Return a MIME type based on file extension."""
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    return {
        "webm": "audio/webm",
        "wav": "audio/wav",
        "mp3": "audio/mpeg",
        "ogg": "audio/ogg",
        "flac": "audio/flac",
        "aac": "audio/aac",
        "m4a": "audio/mp4",
    }.get(ext, "audio/webm")
