"""
CLARIFI AI — Financial Data Parser (Pure Local Engine)

Extracts income/expense amounts, categories, and identifies financial product
queries instantly with zero external API dependencies or latency.
"""

import logging
import re
from datetime import date

from ..schemas import ParseResult, ParsedEntry
from .indic_numbers import convert_indic_numbers_in_text

logger = logging.getLogger(__name__)


def parse_transcript(transcript: str, language: str = "en-IN") -> ParseResult:
    """
    Parse the user's transcript using a high-reliability local parser engine.

    Args:
        transcript: The user's spoken or typed text.
        language:   Language code for the response (e.g. "hi-IN", "kn-IN").

    Returns:
        ParseResult with entries, questions, and raw_intent.
    """
    return _parse_local(transcript, language)


def _parse_local(transcript: str, language: str = "en-IN") -> ParseResult:
    """
    High-reliability deterministic parser that runs locally with zero external API dependencies.
    Extracts expense/income amounts, categories, or identifies financial product questions.
    Supports Hindi, Kannada, Telugu, and English native numerals and spoken words.
    """
    raw_text = transcript.strip()
    # Normalize Indic numerals (Devanagari, Kannada, Telugu) and spoken words into digits
    text = convert_indic_numbers_in_text(raw_text)
    text_lower = text.lower()

    # -----------------------------------------------------------------------
    # 0. Goal Plan Doubt & Follow-Up Q&A Intent Check
    #    When user has questions or doubts about a plan (calculation, speed,
    #    taking loan vs saving, market safety, or budget adjustments),
    #    explain clearly and answer their exact doubt.
    # -----------------------------------------------------------------------
    doubt_type = None
    if any(p in text_lower for p in [
        "how did you calculate", "how is this calculated", "how calculated", "explain calculation",
        "how do you calculate", "calculation formula", "calculate this", "how this plan is calculated",
        "math behind", "formula for", "calculation",
        "कैलकुलेशन कैसे किया", "गणना कैसे हुई", "कैलकुलेशन कैसे", "गणना",
        "ಲೆಕ್ಕಾಚಾರ ಹೇಗೆ", "ಲೆಕ್ಕ ಹಾಕಿದ್ದು ಹೇಗೆ", "ಲೆಕ್ಕಾಚಾರ",
        "లెక్కింపు ఎలా", "కాలిక్యులేషన్ ఎలా", "లెక్కింపు"
    ]):
        doubt_type = "calculation"
    elif any(p in text_lower for p in [
        "reach faster", "achieve faster", "faster", "sooner", "speed up", "quickly",
        "how to reach faster", "can i reach faster", "can i reach this faster", "can i get it faster",
        "जल्दी कैसे", "तेजी से कैसे", "जल्दी पूरा",
        "ಬೇಗ ತಲುಪುವುದು ಹೇಗೆ", "ಬೇಗ ಮುಗಿಸುವುದು ಹೇಗೆ", "ಬೇಗ",
        "త్వరగా ఎలా చేరుకోవాలి", "వేగంగా ఎలా", "త్వరగా"
    ]):
        doubt_type = "faster"
    elif any(p in text_lower for p in [
        "loan", "car loan", "bike loan", "home loan", "loan or save", "loan vs saving",
        "take a loan", "better to take loan", "should i take loan", "should i take a loan",
        "emi vs save", "finance vs cash", "taking loan", "taking a loan",
        "लोन लेना सही", "लोन या बचत", "कर्ज", "ऋण", "लोन",
        "ಸಾಲ ತಗೋಬೇಕಾ", "ಸಾಲ ಅಥವಾ ಉಳಿತಾಯ", "ಸಾಲ",
        "రుణం తీసుకోవాలా", "లోన్ తీసుకోవడం మంచిదా", "రుణం"
    ]):
        doubt_type = "loan_vs_saving"
    elif any(p in text_lower for p in [
        "market drops", "market crash", "stock market falls", "market down", "is it safe",
        "is sip safe", "is my money safe", "safety", "loss", "risk",
        "बाजार गिर गया", "शेयर बाजार", "सुरक्षित है क्या", "नुकसान", "जोखिम", "सुरक्षित",
        "ಮಾರುಕಟ್ಟೆ ಕುಸಿದರೆ", "ಸುರಕ್ಷಿತವೇ", "ನಷ್ಟ", "ಅಪಾಯ",
        "మార్కెట్ పడిపోతే", "సురక్షితమేనా", "నష్టం", "రిస్క్"
    ]):
        doubt_type = "market_risk"
    elif any(p in text_lower for p in [
        "save less", "cannot save", "cant save", "only save", "reduce monthly", "budget tight",
        "afford less", "less money", "if i save less",
        "कम बचत", "कम पैसे", "इतना नहीं बचा सकता",
        "ಕಡಿಮೆ ಉಳಿತಾಯ", "ಅಷ್ಟು ಉಳಿಸಲು ಸಾಧ್ಯವಿಲ್ಲ",
        "తక్కువ పొదుపు", "అంత ఆదా చేయలేను"
    ]):
        doubt_type = "save_less"
    elif any(p in text_lower for p in [
        "doubt", "question about plan", "explain plan", "plan doubt", "tell me about the plan",
        "clarify plan", "explain this plan", "doubts about plan",
        "योजना समझाएं", "संदेह", "शंका",
        "ಯೋಜನೆ ವಿವರಿಸಿ", "ಸಂಶಯ",
        "ప్లాన్ వివరించండి", "సందేహం"
    ]):
        doubt_type = "general"

    if doubt_type:
        return ParseResult(
            raw_intent=f"plan_doubt:{doubt_type}:plan",
            entries=[],
            questions=[],
        )

    # -----------------------------------------------------------------------
    # 1. Investment Plan / Savings Plan intent check
    #    When user asks for an investment plan or savings plan, do NOT redirect to Learn.
    #    Generate the plan, calculate monthly savings, and auto-save to Goals.
    # -----------------------------------------------------------------------
    plan_keywords = [
        "investment plan", "investing plan", "invest plan", "plan my investment",
        "plan an investment", "plan investment", "savings plan", "saving plan",
        "plan my savings", "plan savings", "plan for", "plan to invest",
        "plan to save", "plan my goal", "plan goal", "financial plan",
        "save for", "invest for", "plan to buy", "want to buy", "wanna buy", "wish to buy",
        "planning to buy", "need to buy", "would like to buy", "buy a", "buying a",
        "purchase a", "purchasing a", "save to buy", "planning for a", "planning a",
        "save for a", "saving for a", "buy", "purchase",
        "निवेश योजना", "बचत योजना", "योजना", "हೂಡಿಕೆ ಯೋಜನೆ", "ಉಳಿತಾಯ ಯೋಜನೆ",
        "ಯೋಜನೆ", "పెట్టుబడి ప్రణాళిక", "పొదుపు ప్రణాళిక", "ప్రణాళిక", "ప్లాన్",
        "खरीदना", "खरीदनी", "खरीदना है", "लेना है", "लेनी है",
        "ಖರೀದಿಸಲು", "ಖರೀದಿ", "ತಗೋಬೇಕು",
        "కొనాలి", "కొనుగోలు"
    ]
    buy_asset_intent = (
        bool(re.search(r"\b(want|planning|plan|wanna|wish|need|going|like|save|saving|invest|investing)\b.*?\b(buy|purchase|get|own|take|kharid|khareed)\b.*?\b(car|bike|motorcycle|scooter|laptop|phone|mobile|house|home|flat|vehicle)\b", text_lower))
        or bool(re.search(r"\b(buy|buying|purchase|purchasing)\b.*?\b(car|bike|motorcycle|scooter|laptop|phone|mobile|house|home|flat|vehicle)\b", text_lower))
        or bool(re.search(r"\b(want|planning|plan|wish|need)\b.*?\b(a|to buy|buying)?\s*(car|bike|laptop|phone|mobile|house|flat|vehicle)\b", text_lower))
        or bool(re.search(r"\b(car|bike|laptop|phone|mobile|house|flat|vehicle)\b.*?\b(खरीद|लेना|ಖರೀದಿ|ತಗೋ|కొనాలి|కొనుగోలు)\b", text_lower))
        or bool(re.search(r"\b(खरीद|लेना|ಖರೀದಿ|ತಗೋ|కొనాలి)\b.*?\b(गाड़ी|कार|ಕಾರು|बाइक|ಬೈಕ್|బైక్)\b", text_lower))
        or text_lower.strip() in ["car", "a car", "buy a car", "buy car", "new car", "car goal", "car plan", "car purchase", "want car", "want to buy a car"]
    )
    is_plan_intent = (
        buy_asset_intent
        or any(kw in text_lower for kw in plan_keywords)
        or bool(re.search(r"\b(save|invest|saving|investing)\b.*?\bfor\b", text_lower))
        or bool(re.search(r"\b(save|saving)\b.*?\b(buy|purchase)\b", text_lower))
        or (
            ("plan" in text_lower or "योजना" in text_lower or "ಯೋಜನೆ" in text_lower or "ప్రణాళిక" in text_lower or "goal" in text_lower or "लक्ष्य" in text_lower)
            and ("invest" in text_lower or "save" in text_lower or "money" in text_lower or "रुपये" in text_lower or "₹" in text_lower or "buying" in text_lower or "buy" in text_lower)
        )
    )

    if is_plan_intent:
        # 1. Extract goal name — automatically detected as "Car" if car-related
        goal_name = "Smart Investment Plan"
        if any(w in text_lower for w in ["car", "vehicle", "automobile", "sedan", "suv", "गाड़ी", "कार", "ಕಾರು", "కారు"]):
            goal_name = "Car"
        elif any(w in text_lower for w in ["bike", "motorcycle", "scooter", "बाइक", "ಬೈಕ್", "బైక్"]):
            goal_name = "New Bike Fund"
        elif any(w in text_lower for w in ["laptop", "computer", "macbook", "लैपटॉप", "ಲ್ಯಾಪ್‌ಟಾಪ್"]):
            goal_name = "Laptop Upgrade"
        elif any(w in text_lower for w in ["phone", "mobile", "iphone", "फ़ोन", "ಮೊಬೈಲ್", "ఫోన్"]):
            goal_name = "Smartphone Goal"
        elif any(w in text_lower for w in ["emergency", "cushion", "आपातकालीन", "ತುರ್ತು", "అత్యవసర"]):
            goal_name = "Emergency Cushion Fund"
        elif any(w in text_lower for w in ["house", "home", "flat", "घर", "ಮನೆ", "ఇల్లు"]):
            goal_name = "Home Down-Payment"
        elif any(w in text_lower for w in ["trip", "vacation", "holiday", "travel", "यात्रा", "ಪ್ರವಾಸ", "ట్రిప్"]):
            goal_name = "Vacation & Travel Fund"
        elif any(w in text_lower for w in ["wedding", "marriage", "शादी", "ಮದುವೆ", "పెళ్లి"]):
            goal_name = "Wedding Fund"
        elif any(w in text_lower for w in ["education", "course", "college", "fees", "शिक्षा", "ಶಿಕ್ಷಣ", "చదువు"]):
            goal_name = "Education & Skill Fund"

        # 2. Extract timeline (months)
        months = None
        yr_m = re.search(r"(\d+)\s*(?:year|years|yr|yrs|साल|वर्ष|ವರ್ಷ|సంవత్సరాలు|సంవత్సరం)", text_lower)
        if yr_m:
            try:
                months = int(yr_m.group(1)) * 12
            except ValueError:
                pass
        if months is None:
            mo_m = re.search(r"(\d+)\s*(?:month|months|mo|mos|महीने|महीना|ತಿಂಗಳು|ನెలలు|నెల)", text_lower)
            if mo_m:
                try:
                    months = max(1, int(mo_m.group(1)))
                except ValueError:
                    pass

        # 3. Extract target amount (ensure we do not confuse duration numbers with amount)
        target_amount = None
        lakh_m = re.search(r"(\d+(?:\.\d+)?)\s*(?:lakh|lakhs|lac|lacs|लाख|ಲಕ್ಷ|లక్ష)", text_lower)
        if lakh_m:
            try:
                target_amount = float(lakh_m.group(1)) * 100000.0
            except ValueError:
                pass

        if target_amount is None:
            k_m = re.search(r"(\d+(?:\.\d+)?)\s*k\b", text_lower)
            if k_m:
                try:
                    target_amount = float(k_m.group(1)) * 1000.0
                except ValueError:
                    pass

        if target_amount is None:
            # Check numbers that have explicit currency symbol or word
            cur_amt_m = re.search(r"(?:₹|rs\.?|inr|रुपये|रुपया|रू|ರೂಪಾಯಿ|ರೂ|రూపాయలు|రూ)\s*(\d+(?:,\d+)*(?:\.\d+)?)", text_lower)
            if cur_amt_m:
                try:
                    target_amount = float(cur_amt_m.group(1).replace(",", ""))
                except ValueError:
                    pass

        if target_amount is None:
            # Check any number >= 500 whose immediately following token is not a time unit
            all_nums = re.finditer(r"\b(\d+(?:,\d+)*(?:\.\d+)?)\b", text_lower)
            for num_m in all_nums:
                val_str = num_m.group(1).replace(",", "")
                try:
                    val = float(val_str)
                    after_text = text_lower[num_m.end():]
                    is_immediate_time = bool(re.match(r"^\s*(?:months?|years?|yrs?|mos?|साल|वर्ष|महीने|महीना|ವರ್ಷ|ತಿಂಗಳು|నెలలు|నెల)\b", after_text))
                    if not is_immediate_time and val >= 500:
                        target_amount = val
                        break
                except ValueError:
                    pass

        # 4. Check if Amount or Time requirements are missing
        # Amount and Time are essential requirements for Goal Planning!
        if target_amount is None and months is None:
            amt_eg = "₹5,00,000 or ₹10,00,000" if goal_name.lower() == "car" else "₹50,000 or ₹1,00,000"
            return ParseResult(
                entries=[],
                questions=[
                    f"🎯 Great! To create your customized plan for {goal_name}, what is your target amount? (e.g. {amt_eg})"
                ],
                raw_intent=f"goal_clarification:need_amount:{goal_name}:",
            )
        elif target_amount is None:
            amt_eg = "₹5,00,000 or ₹10,00,000" if goal_name.lower() == "car" else "₹50,000 or ₹1,00,000"
            return ParseResult(
                entries=[],
                questions=[
                    f"🎯 Target timeline of {months} months for {goal_name} noted! What is the target amount you wish to save? (e.g. {amt_eg})"
                ],
                raw_intent=f"goal_clarification:need_amount:{goal_name}:{months}",
            )
        elif months is None:
            time_eg = "1 year, 2 years, 3 years" if goal_name.lower() == "car" else "6 months, 1 year, 2 years"
            return ParseResult(
                entries=[],
                questions=[
                    f"⏳ Target of ₹{int(target_amount):,} for {goal_name} noted! Over how many months or years would you like to achieve this? (e.g. {time_eg})"
                ],
                raw_intent=f"goal_clarification:need_time:{goal_name}:{int(target_amount)}",
            )

        # 5. All requirements available (both Amount and Time) -> Generate plan & auto-update Goals!
        return ParseResult(
            entries=[],
            questions=[],
            raw_intent=f"investment_plan:{goal_name}:{int(target_amount)}:{months}",
        )

    # 2. Product questions check (Schemes / Schemas explainer intent)
    product_catalog = [
        # FD
        (["fixed deposit", "fd", "सावधि जमा", "एफडी", "ಫಿಕ್ಸೆಡ್ ಡೆಪಾಸಿಟ್", "ಫಿಕ್ಸೆಡ್", "ఫిక్స్‌డ్ డిపాజిట్", "ఫిక్స్‌డ్"], "Fixed Deposit (FD)", "fd"),
        # RD
        (["recurring deposit", "rd", "आवर्ती जमा", "आरडी", "ರಿಕರಿಂಗ್ ಡೆಪಾಸಿಟ್", "ರಿಕರಿಂಗ್", "రికరింగ్ డిపాజిట్", "రికరింగ్"], "Recurring Deposit (RD)", "rd"),
        # SIP
        (["systematic investment", "sip", "एसआईपी", "सिप", "ಎಸ್‌ಐಪಿ", "ಸಿಪ್", "సిప్"], "Systematic Investment Plan (SIP)", "sip"),
        # PPF
        (["public provident", "ppf", "पीपीएफ", "ಪಿಪಿಎಫ್", "పీపీఎఫ్"], "Public Provident Fund (PPF)", "ppf"),
        # NPS
        (["national pension", "nps", "एनपीएस", "ಎನ್‌ಪಿಎಸ್", "ఎన్‌పీఎస్"], "National Pension System (NPS)", "nps"),
        # ELSS
        (["elss", "tax saving fund", "ईएलएसएस", "ಇಎಲ್‌ಎಸ್‌ಎಸ್", "ఈఎల్ఎస్ఎస్"], "ELSS (Tax-Saving Mutual Fund)", "elss"),
        # Mutual Funds
        (["mutual fund", "mutual funds", "म्यूचुअल फंड", "म्यूचुअल", "ಮ್ಯೂಚುಯಲ್ ಫಂಡ್", "ಮ್ಯೂಚುಯಲ್", "మ్యూచువల్ ఫండ్స్", "మ్యూచువల్"], "Mutual Funds", "mutual_funds"),
        # Savings Account
        (["savings account", "saving account", "बचत खाता", "ಉಳಿತಾಯ ಖಾತೆ", "సేవింగ్స్ ఖాతా"], "Savings Bank Account", "savings"),
        # Generic Schemes / Schemas queries
        (["scheme", "schemes", "schema", "schemas", "योजना", "योजनाएं", "ಯೋಜನೆ", "ಯೋಜನೆಗಳು", "పథకం", "పథకాలు"], "Investment Schemes", "sip"),
    ]

    question_indicators = [
        "what is", "what are", "explain", "how does", "tell me about", "tell me",
        "show me", "open", "details", "info", "information", "about",
        "kya hai", "kya hota", "batao", "bataiye", "jaanna",
        "yenidu", "yenu", "helu", "tilis", "tilisi", "maahiti",
        "enti", "ela", "cheppu", "vivarinchu", "thelusukovali",
        "which", "best", "compare", "rate", "interest", "returns"
    ]
    is_explainer_question = any(q in text_lower for q in question_indicators)

    for keywords, topic_name, scheme_key in product_catalog:
        if any(kw in text_lower for kw in keywords):
            # If explicit question indicator or short query (<= 6 words, e.g. "FD details", "What is SIP", "schemas")
            if is_explainer_question or len(text_lower.split()) <= 6:
                return ParseResult(
                    entries=[],
                    questions=[],
                    raw_intent=f"product_question:{topic_name}:{scheme_key}",
                )

    # 2. Investment advice query check
    if any(p in text_lower for p in ["where should i invest", "where to invest", "best stock", "recommend fund", "buy stock"]):
        return ParseResult(
            entries=[],
            questions=["I can explain how different instruments work and what factors to consider — which topic interests you: FD, SIP, PPF, NPS, or mutual funds?"],
            raw_intent="investment_advice_request",
        )

    # 3. Extract amount: e.g. ₹500, Rs. 1500, 200, 50,000, ₹50000, 450 रुपये, 500 ರೂಪಾಯಿ, 250 రూపాయలు
    amt_match = re.search(r"(?:₹|rs\.?|inr|रुपये|रुपया|रू|ರೂಪಾಯಿ|ರೂ|రూపాయలు|రూ)?\s*(\d+(?:,\d+)*(?:\.\d+)?)", text_lower)
    if not amt_match:
        amt_match = re.search(r"(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:₹|rs\.?|inr|रुपये|रुपया|रू|ರೂಪಾಯಿ|ರೂ|రూపాయలు|రూ)?", text_lower)
    if not amt_match:
        amt_match = re.search(r"\b(\d+(?:\.\d{1,2})?)\b", text_lower)

    if not amt_match:
        return ParseResult(
            entries=[],
            questions=["I couldn't detect an amount. E.g. 'I spent ₹500 on food today'."],
            raw_intent="parse_clarification",
        )

    try:
        amount = float(amt_match.group(1).replace(",", ""))
    except ValueError:
        amount = 0.0

    if amount <= 0:
        return ParseResult(
            entries=[],
            questions=["Please specify an amount greater than zero."],
            raw_intent="invalid_amount",
        )

    # 4. Income vs Expense
    specific_income_keywords = [
        "salary", "freelance", "stipend", "bonus", "pension",
        "सैलरी", "वेतन", "पगार", "बोनस",
        "ಸಂಬಳ", "ಗಳಿಕೆ", "sambala",
        "జీతం", "సంపాదన", "jeetam"
    ]
    general_income_keywords = [
        "credited", "earned", "income", "got paid", "received", "आया", "मिला",
        "ಆದಾಯ", "ಬಂತು", "వచ్చింది", "ఆదాయం"
    ]
    is_income = any(kw in text_lower for kw in specific_income_keywords) or any(kw in text_lower for kw in general_income_keywords)

    if is_income:
        income_cat = None
        if any(kw in text_lower for kw in ["salary", "सैलरी", "ಸಂಬಳ", "జీతం", "वेतन", "sambala", "jeetam"]):
            income_cat = "salary"
        elif any(kw in text_lower for kw in ["freelance", "client", "gig", "contract"]):
            income_cat = "freelance"
        elif any(kw in text_lower for kw in ["bonus", "incentive", "बोनस"]):
            income_cat = "bonus"
        elif any(kw in text_lower for kw in ["stipend", "internship"]):
            income_cat = "stipend"
        elif any(kw in text_lower for kw in ["interest", "dividend", "investment"]):
            income_cat = "investments"

        # If income field/category was NOT specified: Mandatory check!
        if not income_cat and not any(kw in text_lower for kw in specific_income_keywords):
            return ParseResult(
                entries=[],
                questions=[
                    f"Which field/source does this ₹{int(amount):,} income belong to? (Category is mandatory: e.g. 💼 Salary, 💻 Freelance, 🎁 Bonus, or 📦 Other)"
                ],
                raw_intent=f"missing_category:income:{amount}:{text[:50]}",
            )

        return ParseResult(
            entries=[
                ParsedEntry(
                    type="income",
                    amount=amount,
                    category=income_cat or "salary",
                    description=text[:60],
                    date=date.today().isoformat(),
                )
            ],
            questions=[],
            raw_intent="income_logged",
        )

    # 5. Expense Category keywords (Multilingual support: English, Hindi, Kannada, Telugu)
    categories = {
        "food": [
            "food", "lunch", "dinner", "breakfast", "swiggy", "zomato", "grocer", "tea", "coffee", "snack",
            "cafe", "restaurant", "burger", "pizza", "meal", "chai",
            "खाना", "भोजन", "चाय", "नाश्ता", "रोटी", "सब्जी", "दूध", "मिठाई",
            "ಊಟ", "ತಿಂಡಿ", "ಚಹಾ", "ಕಾಫಿ", "ಹಾಲು", "ಹೋಟೆಲ್", "oota", "thindi",
            "భోజనం", "అల్పాహారం", "టీ", "కాఫీ", "పాలు", "హోటల్", "bhojanam"
        ],
        "rent": [
            "rent", "room rent", "house rent", "flat rent", "pg", "hostel",
            "किराया", "घर किराया", "कमरा",
            "ಬಾಡಿಗೆ", "ಮನೆ ಬಾಡಿಗೆ", "badige",
            "అద్దె", "ఇంటి అద్దె", "adde"
        ],
        "transport": [
            "travel", "transport", "uber", "ola", "auto", "cab", "metro", "bus", "petrol", "diesel", "fuel", "train", "flight", "rapido",
            "ऑटो", "बस", "मेट्रो", "पेट्रोल", "डीजल", "ट्रेन", "सफर",
            "ಆಟೋ", "ಬಸ್", "ಮೆಟ್ರೋ", "ಪೆಟ್ರೋಲ್", "ಡೀಸೆಲ್", "ರೈಲು", "ಸಾರಿಗೆ", "saarige",
            "ఆటో", "బస్సు", "మెట్రో", "పెట్రోల్", "డీజిల్", "రైలు", "రవాణా", "ప్రయాణం", "ravaana"
        ],
        "shopping": [
            "shopping", "clothes", "amazon", "flipkart", "myntra", "shoes", "dress", "shirt", "mall", "gadget", "watch",
            "कपड़े", "दुकान", "खरीदारी",
            "ಬಟ್ಟೆ", "ಅಂಗಡಿ", "ಖರೀದಿ",
            "బట్టలు", "షాపింగ్"
        ],
        "bills": [
            "bill", "electricity", "wifi", "internet", "recharge", "water", "dth", "broadband", "mobile",
            "बिजली", "करंट", "पानी", "रिचार्ज",
            "ವಿದ್ಯುತ್", "ರೀಚಾರ್ಜ್", "ಕರೆಂಟ್", "ವಿದ್ಯುತ್ ಬಿಲ್",
            "కరెంట్", "రీఛార్జ్", "విద్యుత్", "కరెంట్ బిల్లు"
        ],
        "EMI": [
            "emi", "loan", "installment", "credit card",
            "ईएमआई", "लोन", "किस्त",
            "ಸಾಲ", "ಇಎಂಐ",
            "రుణం", "కిస్తీ"
        ],
    }
    matched_category = None
    for cat, kws in categories.items():
        if any(kw in text_lower for kw in kws):
            matched_category = cat
            break

    # Check if user explicitly stated "other" or "misc"
    if not matched_category and any(kw in text_lower for kw in ["other", "misc", "miscellaneous", "अन्य"]):
        matched_category = "other"

    # Category is MANDATORY for expenses: If not mentioned, ask the user!
    if not matched_category:
        return ParseResult(
            entries=[],
            questions=[
                f"Which field/category does this ₹{int(amount):,} belong to? (Category is mandatory: e.g. 🍛 Food, 🚇 Transport, 🏠 Rent, 🛍️ Shopping, 📱 Bills, or 💳 EMI)"
            ],
            raw_intent=f"missing_category:expense:{amount}:{text[:50]}",
        )

    return ParseResult(
        entries=[
            ParsedEntry(
                type="expense",
                amount=amount,
                category=matched_category,
                description=text[:60],
                date=date.today().isoformat(),
            )
        ],
        questions=[],
        raw_intent="expense_logged",
    )


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_claude_response(raw_text: str, original_transcript: str) -> ParseResult:
    """
    Parse and validate Claude's JSON response into a ParseResult.
    Strips markdown fences if Claude added them despite instructions.
    """
    # Strip ```json ... ``` fences if present
    cleaned = re.sub(r"^```(?:json)?\s*", "", raw_text, flags=re.MULTILINE)
    cleaned = re.sub(r"\s*```$", "", cleaned, flags=re.MULTILINE).strip()

    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError as e:
        logger.error("Failed to parse Claude JSON: %s\nRaw: %s", e, raw_text)
        return ParseResult(
            questions=["I didn't understand that. Could you rephrase? E.g. 'I spent ₹500 on food today'."],
            raw_intent="parse_error",
        )

    # Validate and coerce entries
    validated_entries: list[ParsedEntry] = []
    for item in data.get("entries", []):
        try:
            amount = float(item.get("amount", 0))
            entry_type = item.get("type", "expense").lower()
            if entry_type not in ("income", "expense"):
                entry_type = "expense"

            category = item.get("category")
            valid_categories = {"rent", "food", "transport", "shopping", "bills", "EMI", "other"}
            if entry_type == "expense" and category not in valid_categories:
                category = "other"
            if entry_type == "income":
                category = None

            validated_entries.append(ParsedEntry(
                type=entry_type,
                amount=amount,
                category=category,
                description=item.get("description", ""),
                date=item.get("date"),
            ))
        except Exception as e:
            logger.warning("Skipping malformed entry %s: %s", item, e)

    questions = [str(q) for q in data.get("questions", [])]
    raw_intent = str(data.get("raw_intent", ""))

    return ParseResult(
        entries=validated_entries,
        questions=questions,
        raw_intent=raw_intent,
    )


def _language_name(code: str) -> str:
    """Convert language code to human-readable name for the system prompt."""
    return {
        "en-IN": "English",
        "hi-IN": "Hindi",
        "kn-IN": "Kannada",
        "te-IN": "Telugu",
    }.get(code, "English")
