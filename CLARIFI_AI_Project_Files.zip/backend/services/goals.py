"""
CLARIFI AI — Goal Planner Service  (Phase 5)

ALL maths is deterministic Python — the LLM is NOT used for any calculation.

Computes:
  - required_monthly_saving = target_amount / months  (simple division, no interest)
  - current_monthly_surplus  = avg income − avg expenses over last 3 months
  - feasibility              = surplus >= required_monthly_saving
  - shortfall / buffer       = difference in ₹
  - instrument suggestions   = rule-based, by time horizon (not personalised advice)

The instrument suggestions are EDUCATIONAL ONLY — they explain which broad
category of products financial literature associates with each horizon.
No specific fund, stock, or scheme is ever recommended.
"""

import logging
from datetime import date
from sqlalchemy.orm import Session
from sqlalchemy import func, extract

from ..models import Goal, Transaction
from ..schemas import GoalCreate, GoalOut

logger = logging.getLogger(__name__)

USER_ID = 1

# ---------------------------------------------------------------------------
# Horizon thresholds (months) — standard financial planning heuristics
# ---------------------------------------------------------------------------
SHORT_TERM_MAX  = 12   # ≤ 1 year
MEDIUM_TERM_MAX = 60   # 1–5 years
# > 60 months = long term

# ---------------------------------------------------------------------------
# Instrument guidance per horizon (educational text, not personalised advice)
# ---------------------------------------------------------------------------
HORIZON_GUIDANCE = {
    "short": {
        "label": "Short-term (up to 1 year)",
        "instruments": [
            "💳 Savings Account / Liquid Fund — instant access, low risk",
            "📅 Recurring Deposit (RD) — fixed monthly savings, bank-guaranteed",
            "🏦 Short-term Fixed Deposit (FD) — slightly higher interest, low risk",
        ],
        "rationale": (
            "For goals under 1 year, capital safety and liquidity matter most. "
            "Market-linked instruments can fluctuate over short periods, "
            "so low-risk, stable options are generally preferred."
        ),
    },
    "medium": {
        "label": "Medium-term (1–5 years)",
        "instruments": [
            "🏦 Fixed Deposit (FD) — predictable returns, bank-guaranteed",
            "📈 Debt Mutual Funds — higher potential than FD, some market risk",
            "🏛️ PPF (partial) — tax-free, but 15-year lock-in applies to full amount",
            "💰 ELSS Mutual Funds — 3-year lock-in, tax benefit under Sec 80C",
        ],
        "rationale": (
            "Medium-term goals can tolerate a little more risk for potentially "
            "better returns. A mix of stable instruments and low-to-medium risk "
            "options is commonly used for this horizon."
        ),
    },
    "long": {
        "label": "Long-term (more than 5 years)",
        "instruments": [
            "📈 Equity Mutual Funds / SIP — higher growth potential over long periods, higher risk",
            "🏛️ PPF — 15-year lock-in, tax-free returns, government-backed",
            "👴 NPS — pension-focused, tax benefits, long-term wealth building",
            "💰 ELSS — 3-year lock-in, tax benefit, equity exposure",
            "🌱 Index Funds — diversified equity at low cost",
        ],
        "rationale": (
            "Long-term goals allow time to ride out market ups and downs. "
            "Equity-oriented instruments have historically offered higher growth "
            "over long periods, though past performance does not guarantee future returns. "
            "Diversification across instruments is a common principle."
        ),
    },
}

DISCLAIMER = (
    "⚠️ Instrument suggestions above are general educational information based on "
    "typical time horizons — not personalised investment advice. Actual suitability "
    "depends on your risk profile, tax bracket, and financial situation. "
    "Please consult a certified financial advisor before investing."
)


# ---------------------------------------------------------------------------
# CRUD
# ---------------------------------------------------------------------------

def create_goal(db: Session, data: GoalCreate, user_id: int = 1) -> Goal:
    goal = Goal(
        user_id=user_id,
        name=data.name,
        target_amount=data.target_amount,
        months=data.months,
    )
    db.add(goal)
    db.commit()
    db.refresh(goal)
    logger.info("Created goal id=%d user=%d name='%s' target=%.0f months=%d",
                goal.id, user_id, goal.name, goal.target_amount, goal.months)
    return goal


def get_goals(db: Session, user_id: int = 1) -> list[Goal]:
    return (
        db.query(Goal)
        .filter(Goal.user_id == user_id)
        .order_by(Goal.created_at.desc())
        .all()
    )


def get_goal(db: Session, goal_id: int, user_id: int = 1) -> Goal | None:
    return db.query(Goal).filter(Goal.id == goal_id, Goal.user_id == user_id).first()


def delete_goal(db: Session, goal_id: int, user_id: int = 1) -> bool:
    goal = get_goal(db, goal_id, user_id=user_id)
    if not goal:
        return False
    db.delete(goal)
    db.commit()
    return True


# ---------------------------------------------------------------------------
# Planner — pure deterministic Python maths
# ---------------------------------------------------------------------------

def compute_plan(db: Session, goal: Goal, user_id: int = 1) -> dict:
    """
    Compute the goal plan for a given Goal ORM object and user.

    Returns a dict with:
      required_monthly_saving  — ₹ needed per month (simple division)
      current_monthly_surplus  — avg (income − expenses) over last 3 months
      is_feasible              — bool
      shortfall_or_buffer      — positive = buffer, negative = shortfall
      horizon                  — "short" | "medium" | "long"
      horizon_guidance         — educational instrument list for the horizon
      disclaimer               — always included
      months_remaining         — same as goal.months (for display)
      target_date_estimate     — ISO date string of estimated completion
    """

    # --- Required monthly saving (deterministic: no interest assumed) ---
    # Simple division: user saves a fixed amount each month
    required = round(goal.target_amount / goal.months, 2)

    # --- Current monthly surplus (last 3 months average) ---
    surplus = _avg_monthly_surplus(db, user_id=user_id)

    # --- Feasibility ---
    is_feasible = surplus >= required
    diff        = round(surplus - required, 2)  # positive = buffer, negative = shortfall

    # --- Horizon classification ---
    horizon = (
        "short"  if goal.months <= SHORT_TERM_MAX  else
        "medium" if goal.months <= MEDIUM_TERM_MAX else
        "long"
    )

    # --- Estimated target date ---
    today = date.today()
    # Add `months` months to today
    target_month = today.month + goal.months
    target_year  = today.year + (target_month - 1) // 12
    target_month = ((target_month - 1) % 12) + 1
    try:
        target_date = date(target_year, target_month, min(today.day, 28))
    except ValueError:
        target_date = date(target_year, target_month, 28)

    return {
        "goal_id":               goal.id,
        "goal_name":             goal.name,
        "target_amount":         goal.target_amount,
        "months":                goal.months,
        "required_monthly_saving": required,
        "current_monthly_surplus": surplus,
        "is_feasible":           is_feasible,
        "shortfall_or_buffer":   diff,
        "horizon":               horizon,
        "horizon_label":         HORIZON_GUIDANCE[horizon]["label"],
        "horizon_instruments":   HORIZON_GUIDANCE[horizon]["instruments"],
        "horizon_rationale":     HORIZON_GUIDANCE[horizon]["rationale"],
        "target_date_estimate":  target_date.isoformat(),
        "disclaimer":            DISCLAIMER,
    }


def _avg_monthly_surplus(db: Session, user_id: int = 1, lookback: int = 3) -> float:
    """
    Average monthly surplus (income − expenses) over the last `lookback` months.
    Returns 0.0 if no data exists yet.
    """
    today = date.today()
    m, y  = today.month, today.year
    surpluses = []

    for _ in range(lookback):
        income = float(
            db.query(func.coalesce(func.sum(Transaction.amount), 0.0))
            .filter(
                Transaction.user_id == user_id,
                Transaction.type == "income",
                extract("month", Transaction.date) == m,
                extract("year",  Transaction.date) == y,
            ).scalar()
        )
        expenses = float(
            db.query(func.coalesce(func.sum(Transaction.amount), 0.0))
            .filter(
                Transaction.user_id == user_id,
                Transaction.type == "expense",
                extract("month", Transaction.date) == m,
                extract("year",  Transaction.date) == y,
            ).scalar()
        )
        surpluses.append(income - expenses)

        # Step back one month
        m -= 1
        if m == 0:
            m = 12
            y -= 1

    # Use only months with any data; fall back to 0 if truly empty
    non_zero = [s for s in surpluses if s != 0]
    if not non_zero:
        return 0.0
    return round(sum(non_zero) / len(non_zero), 2)
