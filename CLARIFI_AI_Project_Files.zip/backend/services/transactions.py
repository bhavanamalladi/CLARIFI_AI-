"""
CLARIFI AI — Transaction CRUD Service  (Phase 2)

Handles database reads/writes for income and expense transactions.
All operations target user_id=1 (single-user app).
"""

import logging
from datetime import date, datetime
from sqlalchemy.orm import Session
from sqlalchemy import func, extract

from ..models import Transaction, User
from ..schemas import TransactionCreate, TransactionOut, ParsedEntry

logger = logging.getLogger(__name__)

USER_ID = 1  # Single-user app — always user 1


# ---------------------------------------------------------------------------
# Bootstrap: ensure the default user exists
# ---------------------------------------------------------------------------

def ensure_default_user(db: Session) -> None:
    """Create user id=1 if it doesn't exist yet. Called at startup."""
    user = db.get(User, USER_ID)
    if not user:
        db.add(User(id=USER_ID, name="Friend", language_preference="en-IN"))
        db.commit()
        logger.info("Created default user (id=1)")


# ---------------------------------------------------------------------------
# Create
# ---------------------------------------------------------------------------

def create_transaction(db: Session, data: TransactionCreate, user_id: int = 1) -> Transaction:
    """Insert a new transaction and return the ORM object."""
    tx = Transaction(
        user_id=user_id,
        type=data.type,
        amount=data.amount,
        category=data.category,
        description=data.description,
        date=data.date,
    )
    db.add(tx)
    db.commit()
    db.refresh(tx)
    logger.info("Created transaction id=%d user=%d type=%s amount=%.2f", tx.id, user_id, tx.type, tx.amount)
    return tx


def create_transactions_from_parsed(
    db: Session, entries: list[ParsedEntry], user_id: int = 1
) -> list[Transaction]:
    """
    Bulk-insert transactions extracted by the LLM parser.
    Skips entries with amount=0 (ambiguous amounts that need clarification).
    """
    created = []
    for entry in entries:
        if entry.amount <= 0:
            logger.debug("Skipping entry with zero/negative amount: %s", entry)
            continue

        # Parse date string — fall back to today if missing or malformed
        tx_date = date.today()
        if entry.date:
            try:
                tx_date = date.fromisoformat(entry.date)
            except ValueError:
                logger.warning("Could not parse date '%s', using today", entry.date)

        tx = Transaction(
            user_id=user_id,
            type=entry.type,
            amount=entry.amount,
            category=entry.category,
            description=entry.description or "",
            date=tx_date,
        )
        db.add(tx)
        created.append(tx)

    if created:
        db.commit()
        for tx in created:
            db.refresh(tx)
        logger.info("Bulk-created %d transactions for user %d", len(created), user_id)

    return created


# ---------------------------------------------------------------------------
# Read
# ---------------------------------------------------------------------------

def get_transactions(
    db: Session,
    user_id: int = 1,
    skip: int = 0,
    limit: int = 50,
    tx_type: str | None = None,
    month: int | None = None,
    year: int | None = None,
) -> list[Transaction]:
    """
    Fetch transactions for user_id, with optional filters.
    """
    query = db.query(Transaction).filter(Transaction.user_id == user_id)

    if tx_type in ("income", "expense"):
        query = query.filter(Transaction.type == tx_type)

    if year:
        query = query.filter(extract("year", Transaction.date) == year)
    if month:
        query = query.filter(extract("month", Transaction.date) == month)

    return (
        query.order_by(Transaction.date.desc(), Transaction.id.desc())
        .offset(skip)
        .limit(limit)
        .all()
    )


def get_transaction(db: Session, tx_id: int, user_id: int = 1) -> Transaction | None:
    """Fetch a single transaction by id for user_id."""
    return (
        db.query(Transaction)
        .filter(Transaction.id == tx_id, Transaction.user_id == user_id)
        .first()
    )


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------

def update_transaction(
    db: Session, tx_id: int, data: TransactionCreate, user_id: int = 1
) -> Transaction | None:
    """Update a transaction. Returns None if not found."""
    tx = get_transaction(db, tx_id, user_id=user_id)
    if not tx:
        return None

    tx.type        = data.type
    tx.amount      = data.amount
    tx.category    = data.category
    tx.description = data.description
    tx.date        = data.date
    db.commit()
    db.refresh(tx)
    logger.info("Updated transaction id=%d", tx_id)
    return tx


# ---------------------------------------------------------------------------
# Delete
# ---------------------------------------------------------------------------

def delete_transaction(db: Session, tx_id: int, user_id: int = 1) -> bool:
    """Delete a transaction. Returns True if deleted, False if not found."""
    tx = get_transaction(db, tx_id, user_id=user_id)
    if not tx:
        return False
    db.delete(tx)
    db.commit()
    logger.info("Deleted transaction id=%d", tx_id)
    return True


def delete_all_user_data(db: Session, user_id: int = 1) -> dict:
    """
    Wipe ALL data for user_id (GDPR-style delete button).
    Returns count of deleted records per table.
    """
    tx_count = db.query(Transaction).filter(Transaction.user_id == user_id).delete()
    db.commit()
    logger.warning("Deleted all data for user_id=%d: %d transactions", user_id, tx_count)
    return {"transactions_deleted": tx_count}


# ---------------------------------------------------------------------------
# Aggregates (used by dashboard in Phase 3 too)
# ---------------------------------------------------------------------------

def get_monthly_summary(db: Session, month: int, year: int, user_id: int = 1) -> dict:
    """
    Returns total income, total expenses, and savings for a given month.
    """
    base = db.query(Transaction).filter(
        Transaction.user_id == user_id,
        extract("month", Transaction.date) == month,
        extract("year",  Transaction.date) == year,
    )

    income   = base.filter(Transaction.type == "income" ).with_entities(func.sum(Transaction.amount)).scalar() or 0.0
    expenses = base.filter(Transaction.type == "expense").with_entities(func.sum(Transaction.amount)).scalar() or 0.0
    savings  = income - expenses

    return {
        "month":     month,
        "year":      year,
        "income":    round(income,   2),
        "expenses":  round(expenses, 2),
        "savings":   round(savings,  2),
        "savings_rate": round((savings / income * 100) if income > 0 else 0.0, 1),
    }
