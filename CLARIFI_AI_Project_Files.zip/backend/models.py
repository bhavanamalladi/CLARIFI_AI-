"""
CLARIFI AI — Database Models
All ORM models for all 7 phases, defined upfront so the schema is stable.
SQLite tables are created at startup via create_tables().
"""

from datetime import datetime, date
from sqlalchemy import (
    Integer, String, Float, Date, DateTime, Boolean,
    ForeignKey, LargeBinary, Text, Enum
)
from sqlalchemy.orm import Mapped, mapped_column, relationship
from .database import Base
import enum


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class TransactionType(str, enum.Enum):
    income = "income"
    expense = "expense"


class ExpenseCategory(str, enum.Enum):
    rent = "rent"
    food = "food"
    transport = "transport"
    shopping = "shopping"
    bills = "bills"
    emi = "EMI"
    other = "other"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class User(Base):
    """
    User model supporting email/password with OTP 2FA verification and Google sign-in.
    """
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(100), default="Friend")
    email: Mapped[str | None] = mapped_column(String(255), unique=True, index=True, nullable=True)
    password_hash: Mapped[str | None] = mapped_column(String(255), nullable=True)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False)
    auth_provider: Mapped[str] = mapped_column(String(50), default="local")  # "local" or "google"
    otp_code: Mapped[str | None] = mapped_column(String(10), nullable=True)
    otp_expires_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    # Language code for STT / LLM responses / TTS: kn-IN, te-IN, hi-IN, en-IN
    language_preference: Mapped[str] = mapped_column(String(10), default="en-IN")
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    # Relationships
    transactions: Mapped[list["Transaction"]] = relationship(
        "Transaction", back_populates="user", cascade="all, delete-orphan"
    )
    goals: Mapped[list["Goal"]] = relationship(
        "Goal", back_populates="user", cascade="all, delete-orphan"
    )
    emergency_fund_target: Mapped["EmergencyFundTarget"] = relationship(
        "EmergencyFundTarget", back_populates="user",
        uselist=False, cascade="all, delete-orphan"
    )


class Transaction(Base):
    """
    Tracks all income and expense entries.
    Category is only relevant for expenses; income rows leave it null.
    """
    __tablename__ = "transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    # "income" or "expense"
    type: Mapped[str] = mapped_column(String(10))
    amount: Mapped[float] = mapped_column(Float, nullable=False)
    # Expense category — null for income
    category: Mapped[str | None] = mapped_column(String(20), nullable=True)
    description: Mapped[str | None] = mapped_column(String(255), nullable=True)
    # The date the transaction occurred (user-provided or today)
    date: Mapped[date] = mapped_column(Date, default=date.today)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped["User"] = relationship("User", back_populates="transactions")


class Goal(Base):
    """
    Savings goal: name + target amount + timeline.
    Monthly saving is computed deterministically in Python, NOT by the LLM.
    """
    __tablename__ = "goals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(Integer, ForeignKey("users.id"), index=True)
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    target_amount: Mapped[float] = mapped_column(Float, nullable=False)
    months: Mapped[int] = mapped_column(Integer, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped["User"] = relationship("User", back_populates="goals")


class AudioCache(Base):
    """
    TTS audio cache keyed on (text_hash, language).
    Avoids repeat Gnani TTS API calls for the same text + language pair.
    audio_data stores raw WAV bytes.
    """
    __tablename__ = "audio_cache"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    # SHA-256 hex digest of the input text
    text_hash: Mapped[str] = mapped_column(String(64), nullable=False, index=True)
    language: Mapped[str] = mapped_column(String(10), nullable=False)
    audio_data: Mapped[bytes] = mapped_column(LargeBinary, nullable=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class EmergencyFundTarget(Base):
    """
    Per-user emergency fund target, expressed as number of expense-months.
    Default = 6 months (financial planning standard).
    User can adjust this in the dashboard.
    """
    __tablename__ = "emergency_fund_targets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("users.id"), unique=True, index=True
    )
    months_target: Mapped[int] = mapped_column(Integer, default=6)

    user: Mapped["User"] = relationship("User", back_populates="emergency_fund_target")
