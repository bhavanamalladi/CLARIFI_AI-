"""
CLARIFI AI — Pydantic Schemas
Request/response models for all API endpoints.
These are separate from the SQLAlchemy ORM models in models.py.
"""

from datetime import date as dt_date, datetime as dt_datetime
from typing import Optional
from pydantic import BaseModel, Field, field_validator


# ---------------------------------------------------------------------------
# Voice / STT Schemas
# ---------------------------------------------------------------------------

class STTResponse(BaseModel):
    """Response from the /api/voice/stt endpoint."""
    success: bool
    transcript: str = ""
    detected_language: str = ""
    request_id: str = ""
    processing_time: Optional[float] = None
    # Set to True when STT fails and user should fall back to typed input
    fallback: bool = False
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# TTS Schemas
# ---------------------------------------------------------------------------

class TTSRequest(BaseModel):
    """Request body for /api/voice/tts endpoint."""
    text: str = Field(..., min_length=1, max_length=2000)
    language: str = Field(default="en-IN")


class TTSResponse(BaseModel):
    """Response: audio served as bytes; this schema is for error reporting."""
    success: bool
    error: Optional[str] = None


# ---------------------------------------------------------------------------
# Transaction Schemas
# ---------------------------------------------------------------------------

class TransactionCreate(BaseModel):
    """Body for creating a new transaction (income or expense)."""
    type: str = Field(..., pattern="^(income|expense)$")
    amount: float = Field(..., gt=0)
    category: Optional[str] = Field(
        default=None,
        description="Required for expenses. One of: rent, food, transport, shopping, bills, EMI, other"
    )
    description: Optional[str] = Field(default=None, max_length=255)
    date: dt_date = Field(default_factory=dt_date.today)

    @field_validator("category")
    @classmethod
    def validate_category(cls, v, info):
        valid = {"rent", "food", "transport", "shopping", "bills", "EMI", "other"}
        if v is not None and v not in valid:
            raise ValueError(f"category must be one of: {', '.join(valid)}")
        return v


class TransactionOut(TransactionCreate):
    """Transaction as returned from the DB."""
    id: int
    user_id: int
    created_at: dt_datetime

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# Parse / LLM Schemas  (Phase 2)
# ---------------------------------------------------------------------------

class ParsedEntry(BaseModel):
    """A single income or expense entry extracted by the LLM."""
    type: str  # "income" or "expense"
    amount: float
    category: Optional[str] = None
    description: Optional[str] = None
    date: Optional[str] = None  # ISO date string from LLM


class ParseResult(BaseModel):
    """Full structured output from LLM parsing (Phase 2)."""
    entries: list[ParsedEntry] = []
    questions: list[str] = []  # Clarifying questions when amounts are ambiguous
    raw_intent: str = ""       # What the user seems to be asking


class ParseRequest(BaseModel):
    """Request to /api/parse."""
    transcript: str = Field(..., min_length=1)
    language: str = Field(default="en-IN")


# ---------------------------------------------------------------------------
# Goal Schemas  (Phase 5)
# ---------------------------------------------------------------------------

class GoalCreate(BaseModel):
    """Body for creating a savings goal."""
    name: str = Field(..., min_length=1, max_length=200)
    target_amount: float = Field(..., gt=0)
    months: int = Field(..., ge=1, le=600)


class GoalOut(GoalCreate):
    """Goal as returned from the DB."""
    id: int
    user_id: int
    created_at: dt_datetime
    # Computed fields (filled by the goal planner, not stored)
    required_monthly_saving: Optional[float] = None
    is_feasible: Optional[bool] = None
    current_monthly_surplus: Optional[float] = None

    model_config = {"from_attributes": True}


# ---------------------------------------------------------------------------
# User / Settings Schemas
# ---------------------------------------------------------------------------

class UserOut(BaseModel):
    id: int
    name: str
    language_preference: str
    created_at: dt_datetime

    model_config = {"from_attributes": True}


class UserUpdate(BaseModel):
    name: Optional[str] = None
    language_preference: Optional[str] = None


# ---------------------------------------------------------------------------
# Emergency Fund Schemas  (Phase 3)
# ---------------------------------------------------------------------------

class EmergencyFundUpdate(BaseModel):
    months_target: int = Field(..., ge=1, le=24)


# ---------------------------------------------------------------------------
# Dashboard Schemas  (Phase 3)
# ---------------------------------------------------------------------------

class CategoryBreakdown(BaseModel):
    category: str
    total: float
    percentage: float


class DashboardData(BaseModel):
    monthly_income: float
    total_expenses: float
    savings: float
    savings_rate: float  # percentage
    category_breakdown: list[CategoryBreakdown]
    emi_obligations: float
    emergency_fund_target_months: int
    emergency_fund_target_amount: float
    # How much the user has saved (approximated as cumulative savings)
    emergency_fund_saved: float
    emergency_fund_progress_pct: float
    month: str  # "November 2026"
