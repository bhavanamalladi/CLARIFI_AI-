"""
CLARIFI AI — Voice Router (Phase 1)
Handles:
  POST /api/voice/stt  — receive browser audio, forward to Gnani Prisma STT
"""

import logging
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from ..schemas import STTResponse
from ..services import gnani_stt

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/voice", tags=["voice"])

# Max audio upload size: 10 MB (Gnani supports up to ~30s audio)
MAX_AUDIO_SIZE = 10 * 1024 * 1024  # 10 MB


@router.post("/stt", response_model=STTResponse)
async def speech_to_text(
    audio: UploadFile = File(..., description="Audio file recorded in the browser"),
    language_code: str = Form(
        default="indic-auto",
        description="Language hint: kn-IN, te-IN, hi-IN, en-IN, or indic-auto",
    ),
):
    """
    Accept browser-recorded audio (webm/wav) and return a transcript.

    - Forwards to Gnani Prisma STT v3
    - On failure: returns a friendly fallback message instead of raising
    - The browser should show the transcript for user confirmation/editing
    """
    # --- Size guard ---
    audio_bytes = await audio.read()
    if len(audio_bytes) > MAX_AUDIO_SIZE:
        raise HTTPException(status_code=413, detail="Audio file too large (max 10 MB / ~30 seconds)")

    if len(audio_bytes) == 0:
        return STTResponse(
            success=False,
            fallback=True,
            error="No audio received. Please record again or type your input.",
        )

    logger.info(
        "STT request: file=%s size=%d bytes language=%s",
        audio.filename, len(audio_bytes), language_code,
    )

    # --- Call Gnani STT service ---
    result = await gnani_stt.transcribe(
        audio_bytes=audio_bytes,
        filename=audio.filename or "recording.webm",
        language_code=language_code,
    )

    logger.info(
        "STT result: success=%s transcript_len=%d",
        result.success, len(result.transcript),
    )

    return result
