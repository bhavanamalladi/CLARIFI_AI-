"""
CLARIFI AI — Explainer Router  (Phase 4)

Endpoints:
  POST /api/explain        — explain a financial product (NLP query)
  GET  /api/explain/topics — return the preset quick-topic buttons
"""

import logging
from fastapi import APIRouter
from pydantic import BaseModel, Field

from ..services import explainer as exp_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/explain", tags=["explainer"])


class ExplainRequest(BaseModel):
    query: str = Field(default="", max_length=500,
                       description="User's natural-language question about a financial product")
    topic_key: str | None = Field(default=None, description="Exact topic key if clicked via pill")
    language: str = Field(default="en-IN")


@router.post("")
def explain(body: ExplainRequest) -> dict:
    """
    Return a structured compliant financial product explanation
    with a comparison table and a worked ₹ example.
    """
    logger.info("Explain request: query='%s' topic_key='%s' lang=%s", (body.query or '')[:80], body.topic_key, body.language)
    result = exp_service.explain_product(
        query=body.query or body.topic_key or "sip",
        language=body.language,
        topic_key=body.topic_key,
    )
    return result


@router.get("/topics")
def get_topics() -> list[dict]:
    """
    Return the preset quick-topic buttons shown on the Learn tab.
    The frontend uses these to populate the topic pill row.
    """
    return exp_service.get_quick_topics()
