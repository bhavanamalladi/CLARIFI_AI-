"""
CLARIFI AI — Health Router
Simple health check endpoint used for monitoring and testing.
"""

from fastapi import APIRouter
from ..config import settings

router = APIRouter(prefix="/api", tags=["health"])


@router.get("/health")
async def health_check():
    """Returns app status and version. Use this to verify the server is running."""
    return {
        "status": "ok",
        "app": settings.app_name,
        "version": settings.app_version,
        "gnani_configured": bool(
            settings.gnani_api_key and
            settings.gnani_api_key != "your_gnani_api_key_here"
        ),
    }
