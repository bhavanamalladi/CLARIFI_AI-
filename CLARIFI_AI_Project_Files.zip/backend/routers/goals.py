"""
CLARIFI AI — Goals Router  (Phase 5)

Endpoints:
  GET    /api/goals              list all goals
  POST   /api/goals              create a goal
  GET    /api/goals/{id}         get one goal
  GET    /api/goals/{id}/plan    compute the savings plan (deterministic math)
  DELETE /api/goals/{id}         delete a goal
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import GoalCreate, GoalOut
from ..services import goals as goal_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/goals", tags=["goals"])


def _parse_user_id(x_user_id: str | None) -> int:
    if x_user_id and x_user_id.strip().isdigit():
        return int(x_user_id.strip())
    return 1


@router.get("", response_model=list[GoalOut])
def list_goals(
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    """Return all saved goals for the user."""
    user_id = _parse_user_id(x_user_id)
    return goal_service.get_goals(db, user_id=user_id)


@router.post("", response_model=GoalOut, status_code=201)
def create_goal(
    body: GoalCreate,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    """
    Save a new savings goal.
    The monthly saving plan is computed separately via GET /api/goals/{id}/plan.
    """
    user_id = _parse_user_id(x_user_id)
    return goal_service.create_goal(db, body, user_id=user_id)


@router.get("/{goal_id}", response_model=GoalOut)
def get_goal(
    goal_id: int,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    user_id = _parse_user_id(x_user_id)
    goal = goal_service.get_goal(db, goal_id, user_id=user_id)
    if not goal:
        raise HTTPException(status_code=404, detail=f"Goal {goal_id} not found")
    return goal


@router.get("/{goal_id}/plan")
def get_goal_plan(
    goal_id: int,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    """
    Compute the savings plan for a goal using deterministic Python math only.
    Returns: required monthly saving, current surplus, feasibility,
             shortfall/buffer, horizon, instrument education, disclaimer.
    """
    user_id = _parse_user_id(x_user_id)
    goal = goal_service.get_goal(db, goal_id, user_id=user_id)
    if not goal:
        raise HTTPException(status_code=404, detail=f"Goal {goal_id} not found")
    return goal_service.compute_plan(db, goal, user_id=user_id)


@router.delete("/{goal_id}", status_code=204)
def delete_goal(
    goal_id: int,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    user_id = _parse_user_id(x_user_id)
    deleted = goal_service.delete_goal(db, goal_id, user_id=user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Goal {goal_id} not found")
