"""
CLARIFI AI — Dashboard Router  (Phase 3)

Endpoints:
  GET  /api/dashboard          full dashboard payload for a given month
  PUT  /api/emergency-fund     update emergency fund target (months)
"""

import logging
from datetime import date
from fastapi import APIRouter, Depends, Query, Header
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import DashboardData, EmergencyFundUpdate
from ..services import dashboard as dash_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["dashboard"])


def _parse_user_id(x_user_id: str | None) -> int:
    if x_user_id and x_user_id.strip().isdigit():
        return int(x_user_id.strip())
    return 1


@router.get("/dashboard", response_model=DashboardData)
def get_dashboard(
    month: int = Query(default=date.today().month, ge=1,    le=12),
    year:  int = Query(default=date.today().year,  ge=2000, le=2100),
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db),
):
    """
    Return the complete dashboard payload for the given month/year and user.
    All calculations are deterministic Python — no LLM involved.
    """
    user_id = _parse_user_id(x_user_id)
    return dash_service.get_dashboard(db, month=month, year=year, user_id=user_id)


@router.put("/emergency-fund")
def update_emergency_fund_target(
    body: EmergencyFundUpdate,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db),
):
    """
    Update the emergency fund target (number of months of expenses to save).
    Default is 6 months per financial planning standards.
    """
    user_id = _parse_user_id(x_user_id)
    ef = dash_service.update_ef_target(db, months_target=body.months_target, user_id=user_id)
    return {
        "status": "updated",
        "months_target": ef.months_target,
    }
