"""
CLARIFI AI — Transactions Router  (Phase 2)
Full CRUD for income and expense entries.

Endpoints:
  GET    /api/transactions          list (paginated, filterable)
  POST   /api/transactions          create one manually
  GET    /api/transactions/{id}     get one
  PUT    /api/transactions/{id}     update one
  DELETE /api/transactions/{id}     delete one
  DELETE /api/data                  delete ALL user data ("delete my data" button)
  GET    /api/summary               monthly income/expense/savings summary
"""

import logging
from datetime import date
from fastapi import APIRouter, Depends, HTTPException, Query, Header
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import TransactionCreate, TransactionOut
from ..services import transactions as tx_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["transactions"])


def _parse_user_id(x_user_id: str | None) -> int:
    if x_user_id and x_user_id.strip().isdigit():
        return int(x_user_id.strip())
    return 1


# ---------------------------------------------------------------------------
# List
# ---------------------------------------------------------------------------
@router.get("/transactions", response_model=list[TransactionOut])
def list_transactions(
    type: str | None   = Query(default=None, description="income | expense"),
    month: int | None  = Query(default=None, ge=1, le=12),
    year: int | None   = Query(default=None, ge=2000, le=2100),
    skip: int          = Query(default=0,  ge=0),
    limit: int         = Query(default=50, ge=1, le=200),
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session        = Depends(get_db),
):
    """Return transactions for the current user, newest first."""
    user_id = _parse_user_id(x_user_id)
    return tx_service.get_transactions(
        db, user_id=user_id, skip=skip, limit=limit,
        tx_type=type, month=month, year=year,
    )


# ---------------------------------------------------------------------------
# Create (manual entry — voice-parsed entries go through /api/parse)
# ---------------------------------------------------------------------------
@router.post("/transactions", response_model=TransactionOut, status_code=201)
def create_transaction(
    body: TransactionCreate,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db),
):
    """Manually create a single income or expense entry."""
    user_id = _parse_user_id(x_user_id)
    return tx_service.create_transaction(db, body, user_id=user_id)


# ---------------------------------------------------------------------------
# Read one
# ---------------------------------------------------------------------------
@router.get("/transactions/{tx_id}", response_model=TransactionOut)
def get_transaction(
    tx_id: int,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    user_id = _parse_user_id(x_user_id)
    tx = tx_service.get_transaction(db, tx_id, user_id=user_id)
    if not tx:
        raise HTTPException(status_code=404, detail=f"Transaction {tx_id} not found")
    return tx


# ---------------------------------------------------------------------------
# Update
# ---------------------------------------------------------------------------
@router.put("/transactions/{tx_id}", response_model=TransactionOut)
def update_transaction(
    tx_id: int,
    body: TransactionCreate,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db),
):
    user_id = _parse_user_id(x_user_id)
    tx = tx_service.update_transaction(db, tx_id, body, user_id=user_id)
    if not tx:
        raise HTTPException(status_code=404, detail=f"Transaction {tx_id} not found")
    return tx


# ---------------------------------------------------------------------------
# Delete one
# ---------------------------------------------------------------------------
@router.delete("/transactions/{tx_id}", status_code=204)
def delete_transaction(
    tx_id: int,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    user_id = _parse_user_id(x_user_id)
    deleted = tx_service.delete_transaction(db, tx_id, user_id=user_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Transaction {tx_id} not found")


# ---------------------------------------------------------------------------
# DELETE ALL — "delete my data" button  (compliance feature)
# ---------------------------------------------------------------------------
@router.delete("/data", status_code=200)
def delete_all_data(
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db)
):
    """
    Permanently wipe all user data from the local SQLite database.
    Corresponds to the 'Delete my data' button in the UI.
    """
    user_id = _parse_user_id(x_user_id)
    result = tx_service.delete_all_user_data(db, user_id=user_id)
    return {"status": "deleted", **result}


@router.post("/seed", status_code=200)
def seed_demo_endpoint():
    """
    Seed realistic demo transactions and goals for the hackathon demo.
    """
    from seed_demo_data import seed
    seed()
    return {"status": "success", "message": "Demo data seeded successfully!"}


# ---------------------------------------------------------------------------
# Monthly summary
# ---------------------------------------------------------------------------
@router.get("/summary")
def monthly_summary(
    month: int = Query(default=date.today().month, ge=1, le=12),
    year:  int = Query(default=date.today().year,  ge=2000, le=2100),
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db),
):
    """Return income, expenses, savings, and savings rate for a given month."""
    user_id = _parse_user_id(x_user_id)
    return tx_service.get_monthly_summary(db, month=month, year=year, user_id=user_id)
