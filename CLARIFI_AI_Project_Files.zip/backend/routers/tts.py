"""
CLARIFI AI — TTS Router  (Phase 6)

POST /api/voice/tts
  Body: { text: str, language: str }
  Returns: audio/wav bytes  (or 503 on failure — frontend falls back to text)

GET  /api/voice/tts/voices
  Returns: available voices per language for the UI
"""

import logging
from fastapi import APIRouter, Depends
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import TTSRequest
from ..services import gnani_tts as tts_service

logger = logging.getLogger(__name__)

# TTS endpoints live under /api/voice (same prefix as STT)
router = APIRouter(prefix="/api/voice", tags=["tts"])


@router.post("/tts")
async def text_to_speech(
    body: TTSRequest,
    db: Session = Depends(get_db),
):
    """
    Convert text to speech using Gnani Timbre TTS.
    Returns raw WAV bytes with Content-Type: audio/wav.
    On failure returns HTTP 503 — the frontend should show text only.

    Audio is cached in SQLite by (text_hash, language) to save API calls.
    """
    audio_bytes = await tts_service.synthesize(
        text     = body.text,
        language = body.language,
        db       = db,
    )

    if audio_bytes is None:
        # Return 503 so the browser JS can fall back to text-only display
        return Response(
            content     = b"",
            status_code = 503,
            headers     = {"X-TTS-Error": "TTS unavailable — showing text only"},
        )

    return Response(
        content      = audio_bytes,
        media_type   = "audio/wav",
        headers      = {
            "Cache-Control": "public, max-age=86400",  # 24h browser cache
            "Content-Length": str(len(audio_bytes)),
        },
    )


@router.get("/tts/voices")
def get_voices():
    """Return available TTS voices per language for the frontend."""
    return {
        "en-IN": {"voice": "Nalini",  "model": "timbre-v2.5"},
        "hi-IN": {"voice": "Nalini",  "model": "timbre-v2.5"},
        "kn-IN": {"voice": "Kaveri",  "model": "timbre-v2.5"},
        "te-IN": {"voice": "Kaveri",  "model": "timbre-v2.5"},
    }
