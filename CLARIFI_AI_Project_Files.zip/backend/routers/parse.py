"""
CLARIFI AI — Parse Router  (Phase 2)
POST /api/parse  — transcript → Parser Engine → validated entries / goals / categories → SQLite
"""

import logging
from fastapi import APIRouter, Depends, HTTPException, Header
from sqlalchemy.orm import Session

from ..database import get_db
from ..schemas import ParseRequest, ParseResult, TransactionOut, GoalCreate
from ..services import claude_parser, transactions as tx_service, goals as goal_service

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["parse"])


@router.post("/parse")
async def parse_and_save(
    body: ParseRequest,
    x_user_id: str | None = Header(None, alias="X-User-Id"),
    db: Session = Depends(get_db),
) -> dict:
    """
    1. Send the transcript to the parser for structured understanding.
    2. If an Investment Plan was requested, calculate plan, auto-save to Goals, and provide audio narration.
    3. If an expense/income is missing category, flag it as mandatory for user selection.
    4. If entries are extracted with category, save them to SQLite for this user.
    """
    user_id = int(x_user_id.strip()) if (x_user_id and x_user_id.strip().isdigit()) else 1
    transcript = body.transcript.strip()
    if not transcript:
        raise HTTPException(status_code=422, detail="Transcript cannot be empty")

    # --- Step 1: Deterministic parser with Indic number handling ---
    result: ParseResult = claude_parser.parse_transcript(
        transcript=transcript,
        language=body.language,
    )

    # --- Step 2: Handle Investment Plan intent ---
    is_investment_plan = result.raw_intent.startswith("investment_plan:")
    investment_plan_data = None
    if is_investment_plan:
        parts = result.raw_intent.split(":")
        goal_name = parts[1] if len(parts) > 1 else "Smart Investment Plan"
        target_amt = float(parts[2]) if len(parts) > 2 else 50000.0
        months = int(parts[3]) if len(parts) > 3 else 12

        # Auto-create and save this goal into the user's Goals database
        new_goal = goal_service.create_goal(
            db,
            GoalCreate(name=goal_name, target_amount=target_amt, months=months),
            user_id=user_id,
        )
        plan_math = goal_service.compute_plan(db, new_goal, user_id=user_id)
        monthly_saving = plan_math.get("required_monthly_saving", round(target_amt / months))
        is_feasible = plan_math.get("is_feasible", True)
        surplus = plan_math.get("current_monthly_surplus", 0)

        # Strategy allocation
        if months <= 12:
            strategy_title = "Short-Term Capital Security (≤ 12 Months)"
            strategy_desc = (
                "65% in Recurring Deposit (RD) / AAA Liquid Funds (yielding 6.8%–7.2% p.a.) "
                "and 35% in High-Yield Savings Account. Zero equity volatility ensures 100% capital safety."
            )
        elif months <= 36:
            strategy_title = "Medium-Term Balanced Accumulation (1–3 Years)"
            strategy_desc = (
                "50% in Short-Duration Debt Funds / Post Office Term Deposits, "
                "35% in Large-Cap Index Funds (Nifty 50) via monthly SIP, and 15% in Liquid Reserve."
            )
        else:
            strategy_title = "Long-Term Wealth Compounding (3+ Years)"
            strategy_desc = (
                "65% in Diversified Equity Mutual Funds / Index SIP (Nifty 50 + Midcap 150), "
                "25% in Public Provident Fund (PPF / 7.1% tax-free), and 10% in Liquid Reserve."
            )

        lang = body.language or "en-IN"
        if lang == "hi-IN":
            spoken_summary = (
                f"आपके {goal_name} के लिए ₹{int(target_amt):,} का लक्ष्य {months} महीनों में पूरा करने के लिए, "
                f"आपको हर महीने लगभग ₹{int(monthly_saving):,} बचाने की आवश्यकता होगी। "
                f"यह योजना आपके गोल्स डैशबोर्ड में जोड़ दी गई है। "
                f"सुझाव: {strategy_desc}"
            )
        elif lang == "kn-IN":
            spoken_summary = (
                f"ನಿಮ್ಮ {goal_name} ಗಾಗಿ {months} ತಿಂಗಳುಗಳಲ್ಲಿ ₹{int(target_amt):,} ತಲುಪಲು, "
                f"ನೀವು ಪ್ರತಿ ತಿಂಗಳು ಸುಮಾರು ₹{int(monthly_saving):,} ಉಳಿಸಬೇಕು. "
                f"ಈ ಯೋಜನೆಯನ್ನು ನಿಮ್ಮ ಗೋಲ್ಸ್ ಡ್ಯಾಶ್‌ಬೋರ್ಡ್‌ಗೆ ಸೇರಿಸಲಾಗಿದೆ. "
                f"ಸಲಹೆ: {strategy_desc}"
            )
        elif lang == "te-IN":
            spoken_summary = (
                f"మీ {goal_name} కోసం {months} నెలల్లో ₹{int(target_amt):,} చేరుకోవడానికి, "
                f"మీరు ప్రతి నెలా సుమారు ₹{int(monthly_saving):,} ఆదా చేయాలి. "
                f"ఈ ప్లాన్ మీ గోల్స్ డాష్‌బోర్డ్‌లో సేవ్ చేయబడింది. "
                f"సలహా: {strategy_desc}"
            )
        else:
            spoken_summary = (
                f"For your {goal_name} target of ₹{int(target_amt):,} over {months} months, "
                f"you need to save approximately ₹{int(monthly_saving):,} per month. "
                f"This plan has been automatically added to your Goals dashboard. "
                f"Recommended strategy: {strategy_desc}"
            )

        investment_plan_data = {
            "goal_id": new_goal.id,
            "goal_name": goal_name,
            "target_amount": target_amt,
            "months": months,
            "monthly_saving": monthly_saving,
            "is_feasible": is_feasible,
            "current_surplus": surplus,
            "strategy_title": strategy_title,
            "strategy_desc": strategy_desc,
            "spoken_summary": spoken_summary,
        }

    # --- Step 2.5: Handle Goal Requirements Clarification (Amount & Time are important) ---
    is_goal_clarification = result.raw_intent.startswith("goal_clarification:")
    goal_clarification_data = None
    if is_goal_clarification:
        parts = result.raw_intent.split(":")
        step = parts[1] if len(parts) > 1 else "need_amount"
        goal_name = parts[2] if len(parts) > 2 else "Savings Goal"
        extra_val = parts[3] if len(parts) > 3 else ""

        lang = body.language or "en-IN"
        is_car = (goal_name.strip().lower() in ["car", "new car", "car purchase", "car purchase plan"])

        if step == "need_amount":
            known_months = int(extra_val) if (extra_val and extra_val.isdigit()) else None
            if is_car:
                if lang == "hi-IN":
                    spoken_q = f"कार (Car) के लिए आप कितनी राशि का लक्ष्य रखना चाहते हैं? जैसे 5 लाख या 10 लाख रुपये?"
                elif lang == "kn-IN":
                    spoken_q = f"ಕಾರು (Car) ಗಾಗಿ ನೀವು ಎಷ್ಟು ಮೊತ್ತದ ಗುರಿ ಹೊಂದಿದ್ದೀರಿ? ಉದಾಹರಣೆಗೆ 5 ಲಕ್ಷ ಅಥವಾ 10 ಲಕ್ಷ ರೂಪಾಯಿ?"
                elif lang == "te-IN":
                    spoken_q = f"కారు (Car) కోసం మీరు ఎంత మొత్తం లక్ష్యంగా పెట్టుకున్నారు? ఉదాహరణకు 5 లక్షలు లేదా 10 లక్షల రూపాయలు?"
                else:
                    spoken_q = f"To create your customized savings plan for Car, what is your target amount? For example, 5 lakh or 10 lakh rupees?"
                car_amount_options = ["₹5,00,000", "₹8,00,000", "₹10,00,000", "₹15,00,000", "₹20,00,000"]
            else:
                if lang == "hi-IN":
                    spoken_q = f"{goal_name} के लिए आप कितनी राशि बचाना चाहते हैं? जैसे 50,000 या 1 लाख रुपये?"
                elif lang == "kn-IN":
                    spoken_q = f"{goal_name} ಗಾಗಿ ನೀವು ಎಷ್ಟು ಮೊತ್ತವನ್ನು ಉಳಿಸಲು ಬಯಸುತ್ತೀರಿ? ಉದಾಹರಣೆಗೆ 50,000 ಅಥವಾ 1 ಲಕ್ಷ ರೂಪಾಯಿ?"
                elif lang == "te-IN":
                    spoken_q = f"{goal_name} కోసం మీరు ఎంత మొత్తం ఆదా చేయాలనుకుంటున్నారు? ఉదాహరణకు 50,000 లేదా 1 లక్ష రూపాయలు?"
                else:
                    spoken_q = f"To create your customized savings plan for {goal_name}, what is your target amount? For example, 50,000 or 1 lakh rupees?"
                car_amount_options = ["₹25,000", "₹50,000", "₹1,00,000", "₹2,00,000", "₹5,00,000"]

            goal_clarification_data = {
                "step": "need_amount",
                "goal_name": goal_name,
                "months": known_months,
                "question": result.questions[0] if result.questions else spoken_q,
                "spoken_question": spoken_q,
                "quick_options": car_amount_options,
            }
        else:  # need_time
            try:
                known_amount = float(extra_val) if extra_val else (1000000.0 if is_car else 50000.0)
            except ValueError:
                known_amount = 1000000.0 if is_car else 50000.0

            if lang == "hi-IN":
                spoken_q = f"{goal_name} के लिए ₹{int(known_amount):,} का लक्ष्य नोट कर लिया गया है। आप इसे कितने महीनों या वर्षों में पूरा करना चाहते हैं?"
            elif lang == "kn-IN":
                spoken_q = f"{goal_name} ಗಾಗಿ ₹{int(known_amount):,} ಗುರಿ ದಾಖಲಾಗಿದೆ. ನೀವು ಇದನ್ನು ಎಷ್ಟು ತಿಂಗಳು ಅಥವಾ ವರ್ಷಗಳಲ್ಲಿ ತಲುಪಲು ಬಯಸುತ್ತೀರಿ?"
            elif lang == "te-IN":
                spoken_q = f"{goal_name} కోసం ₹{int(known_amount):,} లక్ష్యం నమోదైంది. మీరు దీనిని ఎన్ని నెలలు లేదా సంవత్సరాలలో పూర్తి చేయాలనుకుంటున్నారు?"
            else:
                spoken_q = f"Target of ₹{int(known_amount):,} for {goal_name} noted! Over how many months or years would you like to achieve this? For example, 1 year or 3 years?"

            time_options = (
                ["1 Year (12 Mo)", "2 Years (24 Mo)", "3 Years (36 Mo)", "5 Years (60 Mo)"]
                if is_car else
                ["3 Months", "6 Months", "12 Months (1 Year)", "24 Months (2 Years)", "36 Months (3 Years)"]
            )

            goal_clarification_data = {
                "step": "need_time",
                "goal_name": goal_name,
                "target_amount": known_amount,
                "question": result.questions[0] if result.questions else spoken_q,
                "spoken_question": spoken_q,
                "quick_options": time_options,
            }

    # --- Step 3: Handle Mandatory Category Missing ---
    needs_category = result.raw_intent.startswith("missing_category:")
    pending_entry = None
    if needs_category:
        parts = result.raw_intent.split(":")
        entry_type = parts[1] if len(parts) > 1 else "expense"
        amt = float(parts[2]) if len(parts) > 2 else 0.0
        desc = parts[3] if len(parts) > 3 else ""
        pending_entry = {
            "type": entry_type,
            "amount": amt,
            "description": desc,
        }

    # --- Step 3.5: Handle Plan Doubts & Follow-up Q&A ---
    is_plan_doubt = result.raw_intent.startswith("plan_doubt:")
    plan_doubt_data = None
    if is_plan_doubt:
        parts = result.raw_intent.split(":")
        doubt_type = parts[1] if len(parts) > 1 else "general"
        goal_context = parts[2] if len(parts) > 2 else "plan"
        lang = body.language or "en-IN"
        plan_doubt_data = _resolve_plan_doubt(doubt_type, goal_context, lang)

    # --- Step 4: Save valid entries (only when category is specified) ---
    saved_ids: list[int] = []
    if result.entries and not result.questions and not is_investment_plan and not is_goal_clarification and not is_plan_doubt:
        saved = tx_service.create_transactions_from_parsed(db, result.entries, user_id=user_id)
        saved_ids = [t.id for t in saved]

    is_product_question = result.raw_intent.startswith("product_question:")
    product_topic = None
    scheme_key = None
    if is_product_question:
        parts = result.raw_intent.split(":")
        product_topic = parts[1] if len(parts) > 1 else "SIP"
        scheme_key = parts[2] if len(parts) > 2 else "sip"

    return {
        "parsed": result.model_dump(),
        "saved_count": len(saved_ids),
        "saved_ids": saved_ids,
        "is_product_question": is_product_question,
        "product_topic":       product_topic,
        "scheme_key":          scheme_key,
        "is_advice_request":   result.raw_intent == "investment_advice_request",
        "is_investment_plan":  is_investment_plan,
        "investment_plan":     investment_plan_data,
        "is_goal_clarification": is_goal_clarification,
        "goal_clarification":  goal_clarification_data,
        "is_plan_doubt":       is_plan_doubt,
        "plan_doubt":          plan_doubt_data,
        "needs_category":      needs_category,
        "pending_entry":       pending_entry,
    }


def _resolve_plan_doubt(doubt_type: str, goal_context: str, lang: str) -> dict:
    """
    Generate structured, plain-language explanations for doubts regarding goal investment plans.
    Provides clear mathematical logic, risk mitigation, and natural voice readout across 4 Indic languages.
    """
    doubts = {
        "calculation": {
            "title": {
                "en-IN": "🧮 How Your Goal Plan is Calculated",
                "hi-IN": "🧮 आपकी योजना की गणना कैसे की गई है",
                "kn-IN": "🧮 ನಿಮ್ಮ ಗುರಿ ಯೋಜನೆಯ ಲೆಕ್ಕಾಚಾರದ ವಿವರ",
                "te-IN": "🧮 మీ ప్రణాళిక లెక్కింపు పూర్తి వివరాలు",
            },
            "points": [
                "1. **Baseline Math**: Target Amount ÷ Timeline in Months = Baseline Required Saving.",
                "2. **Compounding Reduction**: When you invest in a safe Recurring Deposit or Index SIP earning 7% to 12% p.a., compound interest generates 15% to 25% of your final corpus, reducing what you pay from your own pocket!",
                "3. **Zero Hallucination**: All calculations follow standard deterministic financial formulas (FV = P * [((1 + r)^n - 1) / r]).",
            ],
            "spoken": {
                "en-IN": "Your plan is calculated by dividing your target amount by your timeline in months. When invested in a safe Recurring Deposit or Index SIP earning 7 to 12 percent, compound interest works for you, reducing your monthly saving burden by up to 20 percent compared to keeping cash idle.",
                "hi-IN": "आपकी योजना की गणना आपके कुल लक्ष्य को महीनों की संख्या से विभाजित करके की जाती है। जब आप इसे 7 से 12 प्रतिशत ब्याज देने वाले आरडी या इंडेक्स फंड में निवेश करते हैं, तो चक्रवृद्धि ब्याज आपकी मदद करता है और आपको अपनी जेब से कम पैसा बचाना पड़ता है।",
                "kn-IN": "ನಿಮ್ಮ ಯೋಜನೆಯನ್ನು ಒಟ್ಟು ಗುರಿ ಮೊತ್ತವನ್ನು ತಿಂಗಳುಗಳಿಂದ ಭಾಗಿಸಿ ಲೆಕ್ಕಹಾಕಲಾಗುತ್ತದೆ. ಇದನ್ನು ಶೇಕಡಾ 7 ರಿಂದ 12 ರಷ್ಟು ಬಡ್ಡಿ ನೀಡುವ ಆರ್‌ಡಿ ಅಥವಾ ಎಸ್‌ಐಪಿಯಲ್ಲಿ ಹೂಡಿಕೆ ಮಾಡಿದಾಗ, ಬಡ್ಡಿಯಿಂದಾಗಿ ನೀವು ಕಡಿಮೆ ಹಣ ಉಳಿಸಿದರೂ ಗುರಿ ಮುಟ್ಟಬಹುದು.",
                "te-IN": "మీ ప్లాన్ మొత్తం లక్ష్యాన్ని నెలల సంఖ్యతో భాగించి లెక్కించబడుతుంది. 7 నుండి 12 శాతం రాబడినిచ్చే ఆర్‌డీ లేదా సిప్‌లో పెట్టుబడి పెట్టినప్పుడు, చక్రవడ్డీ లాభం వల్ల మీరు మీ జేబు నుండి తక్కువ పొదుపు చేసినా సులభంగా లక్ష్యాన్ని చేరవచ్చు.",
            },
        },
        "faster": {
            "title": {
                "en-IN": "⚡ 3 Proven Ways to Reach Your Goal Faster",
                "hi-IN": "⚡ अपने लक्ष्य तक तेजी से पहुंचने के 3 आसान तरीके",
                "kn-IN": "⚡ ನಿಮ್ಮ ಗುರಿಯನ್ನು ಬೇಗ ತಲುಪಲು 3 ಸುಲಭ ಮಾರ್ಗಗಳು",
                "te-IN": "⚡ మీ లక్ష్యాన్ని వేగంగా చేరుకోవడానికి 3 మార్గాలు",
            },
            "points": [
                "1. **10% Annual Step-Up**: Raise your monthly contribution by 10% whenever your salary increases or upon bonus. This cuts a 36-month timeline down to 28 months!",
                "2. **Bonus Direct Allocation**: Deposit 50% of annual bonuses or festival gifts directly into this goal bucket.",
                "3. **Trim 1 Discretionary Expense**: Cutting dining out or impulse delivery twice a month frees up ₹3,000–₹5,000/mo, shaving 4 to 6 months off your goal!",
            ],
            "spoken": {
                "en-IN": "You can reach your goal faster in three simple ways: step up your monthly savings by 10 percent when income increases, deposit annual bonuses directly into the goal, and trim small discretionary expenses like dining out.",
                "hi-IN": "आप अपने लक्ष्य तक 3 तरीकों से तेजी से पहुंच सकते हैं: पहला, वेतन बढ़ने पर बचत 10 प्रतिशत बढ़ाएं; दूसरा, बोनस का पैसा सीधे इस लक्ष्य में डालें; और तीसरा, बाहर खाने के छोटे खर्चों को कम करके बचत में जोड़ें।",
                "kn-IN": "ನೀವು 3 ವಿಧಾನಗಳಿಂದ ಬೇಗ ಗುರಿ ತಲುಪಬಹುದು: ಸಂಬಳ ಹೆಚ್ಚಾದಾಗ ಉಳಿತಾಯವನ್ನು 10% ಹೆಚ್ಚಿಸಿ, ಬೋನಸ್ ಹಣವನ್ನು ನೇರವಾಗಿ ಈ ಗುರಿಗೆ ಜಮೆ ಮಾಡಿ, ಮತ್ತು ಅನಗತ್ಯ ಹೊರಗಿನ ಊಟದ ಖರ್ಚು ಕಡಿಮೆ ಮಾಡಿ.",
                "te-IN": "మీరు 3 సులభమైన మార్గాల్లో వేగంగా లక్ష్యాన్ని చేరుకోవచ్చు: జీతం పెరిగినప్పుడు పొదుపును 10% పెంచడం, వార్షిక బోనస్‌ను నేరుగా ఈ లక్ష్యానికి జమ చేయడం, మరియు అనవసరపు ఖర్చులను తగ్గించి పొదుపు చేయడం.",
            },
        },
        "loan_vs_saving": {
            "title": {
                "en-IN": "🚗 Car Loan vs. Disciplined Saving Comparison",
                "hi-IN": "🚗 कार लोन बनाम अनुशासित बचत: क्या बेहतर है?",
                "kn-IN": "🚗 ಕಾರ್ ಲೋನ್ vs ಶಿಸ್ತಿನ ಉಳಿತಾಯ: ಯಾವುದು ಉತ್ತಮ?",
                "te-IN": "🚗 కార్ లోన్ vs క్రమశిక్షణతో కూడిన పొదుపు",
            },
            "points": [
                "1. **Bank Loan Route**: An ₹8 Lakh car loan at 10% interest for 3 years costs you **₹9.3 Lakhs** in EMIs + ₹10,000 processing fees. You pay ₹1.4 Lakhs extra to the bank for an asset that drops in value 20% the moment you drive it off the lot.",
                "2. **Saving First Route**: Saving ₹20,000/month in an RD/SIP at 7–10% earns you **₹65,000 in interest**, meaning you actually pay LESS than the sticker price!",
                "3. **Smart Hybrid Approach**: Save 50% for a large down payment. Take a small 2-year loan for the remainder so your EMI stays comfortably below 15% of your salary with zero debt stress.",
            ],
            "spoken": {
                "en-IN": "When you take a car loan, you pay 9 to 11 percent interest to the bank, meaning an 8 lakh car costs you over 9.3 lakhs. When you save first in an RD or SIP, you earn interest from the bank instead. The smartest approach is saving at least 50 percent for the down payment to keep your loan EMI tiny.",
                "hi-IN": "कार लोन लेने पर आपको 9 से 11 प्रतिशत ब्याज बैंक को देना पड़ता है, जिससे 8 लाख की कार 9.3 लाख से ज्यादा की पड़ती है। वहीं बचत करने पर बैंक आपको ब्याज देता है। सबसे समझदारी भरा तरीका है कि कम से कम 50% डाउन पेमेंट जमा कर लें ताकि लोन का बोझ ना रहे।",
                "kn-IN": "ಕಾರ್ ಲೋನ್ ತೆಗೆದುಕೊಂಡರೆ ನೀವು ಬ್ಯಾಂಕಿಗೆ 9 ರಿಂದ 11 ಪ್ರತಿಶತ ಬಡ್ಡಿ ಪಾವತಿಸಬೇಕಾಗುತ್ತದೆ. ಆದರೆ ಉಳಿತಾಯ ಮಾಡಿದರೆ ಬ್ಯಾಂಕೇ ನಿಮಗೆ ಬಡ್ಡಿ ನೀಡುತ್ತದೆ. ಕನಿಷ್ಠ 50% ಡೌನ್ ಪೇಮೆಂಟ್ ಉಳಿಸಿ ನಂತರ ಸಣ್ಣ ಸಾಲ ಮಾಡುವುದು ಅತ್ಯುತ್ತಮ.",
                "te-IN": "కార్ లోన్ తీసుకుంటే మీరు బ్యాంకుకు 9 నుండి 11 శాతం వడ్డీ చెల్లించాలి, దీనివల్ల 8 లక్షల కారు 9.3 లక్షలకు పైగా ఖర్చవుతుంది. అదే పొదుపు చేస్తే బ్యాంకే మీకు వడ్డీ ఇస్తుంది. కనీసం 50 శాతం డౌన్ పేమెంట్ ఆదా చేసి మిగిలినదానికి చిన్న లోన్ తీసుకోవడం ఉత్తమం.",
            },
        },
        "market_risk": {
            "title": {
                "en-IN": "🛡️ Market Safety & Capital Protection",
                "hi-IN": "🛡️ बाजार जोखिम और पूंजी सुरक्षा",
                "kn-IN": "🛡️ ಮಾರುಕಟ್ಟೆ ಅಪಾಯ ಮತ್ತು ಬಂಡವಾಳ ಸುರಕ್ಷತೆ",
                "te-IN": "🛡️ మార్కెట్ భద్రత & మూలధన రక్షణ",
            },
            "points": [
                "1. **Short-Term Rule**: For goals under 3 years (like a car or bike), your money should NOT be put in volatile stock markets.",
                "2. **100% Capital Safe**: 65% is allocated to Bank Recurring Deposits (RD) and Post Office Term Deposits with guaranteed compound profit and RBI/DICGC insurance up to ₹5 Lakhs.",
                "3. **Zero Loss Guarantee**: The remaining 35% is placed in high-yield liquid funds. Even if the stock market drops 30%, your car fund remains 100% safe and intact.",
            ],
            "spoken": {
                "en-IN": "For short to medium term goals like buying a car, your capital is protected by keeping 65 to 100 percent in guaranteed Bank Recurring Deposits and Post Office schemes. These have zero stock market risk and are insured by the government up to 5 lakh rupees.",
                "hi-IN": "कार जैसे 1 से 3 साल के लक्ष्यों के लिए, आपका 65 से 100 प्रतिशत पैसा बैंक आरडी और सरकारी डाकघर योजनाओं में रखा जाता है। इसमें शेयर बाजार का कोई जोखिम नहीं होता और 5 लाख रुपये तक सरकारी बीमा सुरक्षा मिलती है।",
                "kn-IN": "ಕಾರಿನಂತಹ 1 ರಿಂದ 3 ವರ್ಷಗಳ ಗುರಿಗಳಿಗೆ ನಿಮ್ಮ ಹಣವನ್ನು ಬ್ಯಾಂಕ್ ಆರ್‌ಡಿ ಮತ್ತು ಅಂಚೆ ಕಚೇರಿ ಉಳಿತಾಯದಲ್ಲಿ ಸುರಕ್ಷಿತವಾಗಿಡಲಾಗುತ್ತದೆ. ಇದಕ್ಕೆ ಷೇರು ಮಾರುಕಟ್ಟೆ ಅಪಾಯವಿಲ್ಲ ಮತ್ತು 5 ಲಕ್ಷದವರೆಗೆ ಸರ್ಕಾರಿ ವಿಮೆ ಇರುತ್ತದೆ.",
                "te-IN": "కారు వంటి 1 నుండి 3 సంవత్సరాల లక్ష్యాల కోసం, మీ డబ్బులో 65 నుండి 100 శాతాన్ని బ్యాంక్ ఆర్డీ మరియు పోస్ట్ ఆఫీస్ పథకాలలో సురక్షితంగా ఉంచుతారు. వీటికి మార్కెట్ రిస్క్ ఉండదు మరియు 5 లక్షల వరకు ప్రభుత్వ బీమా ఉంటుంది.",
            },
        },
        "save_less": {
            "title": {
                "en-IN": "💰 Flexible Budget Adjustments",
                "hi-IN": "💰 कम बचत के लिए आसान उपाय",
                "kn-IN": "💰 ಬಜೆಟ್ ಹೊಂದಾಣಿಕೆ ಪರಿಹಾರಗಳು",
                "te-IN": "💰 బడ్జెట్ సర్దుబాటు ప్రత్యామ్నాయాలు",
            },
            "points": [
                "1. **Extend Timeline**: If ₹25,000/mo is too tight, extending from 24 to 36 months lowers the requirement to ₹16,000/mo without changing your target car.",
                "2. **Two-Tier Plan**: Consider a certified pre-owned car first (e.g. ₹4 Lakh target) to start driving debt-free sooner, then upgrade 3 years later.",
                "3. **Start Small**: Even starting with ₹5,000/mo builds the savings habit and accumulates ₹60,000+ in year one.",
            ],
            "spoken": {
                "en-IN": "If the monthly saving amount feels high, you can simply extend your timeline by 6 to 12 months. This immediately lowers your monthly requirement to fit your budget comfortably without stress.",
                "hi-IN": "अगर हर महीने की बचत राशि ज्यादा लग रही है, तो आप समय सीमा को 6 या 12 महीने बढ़ा सकते हैं। इससे हर महीने की जरूरी बचत तुरंत कम हो जाएगी और आपके बजट पर कोई दबाव नहीं पड़ेगा।",
                "kn-IN": "ಮಾಸಿಕ ಉಳಿತಾಯ ಮೊತ್ತ ಹೆಚ್ಚೆನಿಸಿದರೆ, ನೀವು ಅವಧಿಯನ್ನು 6 ರಿಂದ 12 ತಿಂಗಳು ವಿಸ್ತರಿಸಬಹುದು. ಇದರಿಂದ ಪ್ರತಿ ತಿಂಗಳ ಉಳಿತಾಯ ಮೊತ್ತ ಕಡಿಮೆಯಾಗಿ ಸುಲಭವಾಗಿ ಉಳಿಸಬಹುದು.",
                "te-IN": "నెలవారీ పొదుపు మొత్తం ఎక్కువగా అనిపిస్తే, మీరు సమయాన్ని 6 నుండి 12 నెలలు పొడిగించవచ్చు. దీనివల్ల ప్రతి నెలా ఆదా చేయాల్సిన మొత్తం తగ్గి మీ బడ్జెట్‌కు అనుకూలంగా మారుతుంది.",
            },
        },
        "general": {
            "title": {
                "en-IN": "🎯 Your Goal Plan Explained in Detail",
                "hi-IN": "🎯 आपकी योजना का विस्तृत विवरण",
                "kn-IN": "🎯 ನಿಮ್ಮ ಯೋಜನೆಯ ವಿವರವಾದ ಮಾಹಿತಿ",
                "te-IN": "🎯 మీ ప్రణాళిక పూర్తి వివరాలు",
            },
            "points": [
                "1. **Clear Milestones**: Regular monthly contributions combine with guaranteed compounding to reach your goal.",
                "2. **Automated Transfers**: Setup an auto-debit on salary day so you save before you spend.",
                "3. **Emergency Protection**: Keep 3 months of basic expenses separate so you never need to break your car fund.",
            ],
            "spoken": {
                "en-IN": "Your goal plan is designed to help you buy your car completely debt-free. By automating monthly savings on salary day and utilizing safe compound interest, you reach your target smoothly.",
                "hi-IN": "आपकी योजना आपको बिना किसी कर्ज के अपनी कार खरीदने में मदद करने के लिए बनाई गई है। वेतन वाले दिन ऑटो-डेबिट सेट करके और सुरक्षित ब्याज का लाभ उठाकर आप आसानी से अपने लक्ष्य तक पहुंच जाएंगे।",
                "kn-IN": "ಯಾವುದೇ ಸಾಲವಿಲ್ಲದೆ ನಿಮ್ಮ ಕಾರು ಖರೀದಿಸಲು ಈ ಯೋಜನೆಯನ್ನು ರೂಪಿಸಲಾಗಿದೆ. ಸಂಬಳದ ದಿನವೇ ಸ್ವಯಂಚಾಲಿತ ಉಳಿತಾಯ ಮಾಡುವ ಮೂಲಕ ನಿಮ್ಮ ಗುರಿಯನ್ನು ಸುಲಭವಾಗಿ ತಲುಪಬಹುದು.",
                "te-IN": "ఎటువంటి అప్పు లేకుండా మీ కారును కొనుగోలు చేయడానికి ఈ ప్లాన్ రూపొందించబడింది. జీతం వచ్చిన రోజే ఆటోమేటిక్ పొదుపు చేయడం ద్వారా మీ లక్ష్యాన్ని సులభంగా చేరుకోవచ్చు.",
            },
        },
    }

    d = doubts.get(doubt_type, doubts["general"])
    active_lang = lang if lang in ("en-IN", "hi-IN", "kn-IN", "te-IN") else "en-IN"

    return {
        "doubt_type": doubt_type,
        "title": d["title"].get(active_lang, d["title"]["en-IN"]),
        "points": d["points"],
        "spoken": d["spoken"].get(active_lang, d["spoken"]["en-IN"]),
        "quick_doubt_chips": [
            "❓ How did you calculate this?",
            "⚡ Can I reach faster?",
            "🚗 Car Loan vs Saving?",
            "📉 What if market drops?",
            "💰 What if I save less?",
        ],
    }
