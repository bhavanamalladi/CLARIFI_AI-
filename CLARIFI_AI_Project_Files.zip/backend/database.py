"""
CLARIFI AI — Database Setup
SQLAlchemy engine + session factory + Base for all models.
Using SQLite for local-first, privacy-respecting storage.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from .config import settings

# SQLite engine — check_same_thread=False is required for FastAPI's threadpool
engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False},
    echo=settings.debug,  # Log SQL queries in debug mode
)

# Session factory — each request gets its own session via get_db()
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


class Base(DeclarativeBase):
    """Declarative base class for all ORM models."""
    pass


def get_db():
    """
    FastAPI dependency that yields a DB session and ensures it is closed
    after the request completes, even on errors.
    Usage: db: Session = Depends(get_db)
    """
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def create_tables():
    """Create all tables defined in models. Called at app startup."""
    from . import models  # noqa: F401
    Base.metadata.create_all(bind=engine)

    # Safely migrate existing users table if columns are missing
    with engine.connect() as conn:
        cursor = conn.connection.cursor()
        cursor.execute("PRAGMA table_info(users)")
        existing_cols = {row[1] for row in cursor.fetchall()}
        
        needed_cols = [
            ("email", "VARCHAR(255)"),
            ("password_hash", "VARCHAR(255)"),
            ("is_verified", "BOOLEAN DEFAULT 0"),
            ("auth_provider", "VARCHAR(50) DEFAULT 'local'"),
            ("otp_code", "VARCHAR(10)"),
            ("otp_expires_at", "DATETIME")
        ]
        for col_name, col_type in needed_cols:
            if col_name not in existing_cols:
                try:
                    cursor.execute(f"ALTER TABLE users ADD COLUMN {col_name} {col_type}")
                except Exception:
                    pass
        conn.connection.commit()
