"""
CLARIFI AI — Configuration
Loads all settings from the .env file using pydantic-settings.
Never expose these values to the browser — all API calls go through the backend.
"""

import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_FILE = os.path.join(BASE_DIR, ".env")


class Settings(BaseSettings):
    """Application settings loaded from environment / .env file."""

    # --- Gnani Vachana API (STT & TTS) ---
    gnani_api_key: str = ""

    # --- App ---
    app_host: str = "0.0.0.0"
    app_port: int = 8000
    debug: bool = True
    app_name: str = "CLARIFI AI"
    app_version: str = "1.0.0"

    # --- Database ---
    database_url: str = "sqlite:///./clarifi.db"

    # --- Gmail SMTP Settings for OTP 2FA ---
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""

    model_config = SettingsConfigDict(
        env_file=ENV_FILE,
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )


@lru_cache()
def get_settings() -> Settings:
    """Return cached settings singleton (loaded once at startup)."""
    return Settings()


# Convenient module-level alias
settings = get_settings()
